/* this is a little program to run at startup to hack the
   screen saver to tell us how many days are left till
   we get to go Home. */

/* assumes we go Home on September First */

/* of course, this is rexx. so it won't be pretty. */

/* first, find the number of days. */

today = date()
parse var today day m year
call FixMonth

if month = 5 then DaysLeftInMonth = 31 - day
if month = 6 then DaysLeftInMonth = 30 - day
if month = 7 then DaysLeftInMonth = 31 - day
if month = 8 then DaysLeftInMonth = 31 - day

if month = 5 then DaysLeft = 92 + DaysLeftInMonth
if month = 6 then DaysLeft = 32 + DaysLeftInMonth
if month = 7 then DaysLeft = 31 + DaysLeftInMonth
if month = 8 then DaysLeft = DaysLeftInMonth

if DaysLeft = 0 then newss = 'i''m Home'
else newss = DaysLeft||' days left'

/* now all we have to do is hack the file */

ini = 'C:\WINDOWS\CONTROL.INI'
c = 1
file = open(ini,'r')
do while EOF(ini) = 0
  inifile.c = read(ini)
  c = c + 1
end

c = c - 1
section = 0
'del 'ini
file = open(ini, 'a')

do d = 1 to c
  if inifile.d = '[Screen Saver.3DText]' then section = 1
  else do
    parse var inifile.d trait "=" setting
    if trait = 'Text' then do
      if section = 1 then inifile.d = 'Text='||newss
    end
  end
  call write file, inifile.d,;
end

/* that should do it */

EXIT

FixMonth:

if m = 'May' then month = 5
if m = 'Jun' then month = 6
if m = 'Jul' then month = 7
if m = 'Aug' then month = 8

RETURN
