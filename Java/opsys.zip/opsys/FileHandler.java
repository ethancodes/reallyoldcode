/** Created By: Ken Schulz on August 3, 1998
 *
 *  Reads and writes information to a file. Objects only!
 *
 */

import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.StreamCorruptedException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.Exception;

public class FileHandler
{
    protected String fileName;
    protected FileOutputStream outData;
    protected ObjectOutputStream objOut;
    protected FileInputStream inData;
    protected ObjectInputStream objIn;



/**
 * Sets link to a file
 * @parm newFileName is the file name to be linked to
 */
    public FileHandler(String newFileName)
     {
        fileName = newFileName;
        outData = null;
        objOut = null;
        inData = null;
        objIn = null;
     }

/**
 * @parm newObject sets link to an object
 */
    public void writeObject(Object object) throws IOException
     {
        if (outData == null) {
            outData = new FileOutputStream(fileName);
            objOut = new ObjectOutputStream(outData);
         }
        objOut.writeObject(object);
     }

/**
 * Returns read objects from file
 */
    public Object readObject() throws FileNotFoundException,
                                      StreamCorruptedException,
                                      ClassNotFoundException,
                                      IOException
     {
        if (inData == null) {
            inData = new FileInputStream(fileName);
            objIn = new ObjectInputStream(inData);
         }
        return objIn.readObject();
     }

/**
 * Closes open file links and connections
 */
    public void close() throws IOException
     {
        if (outData != null) {
            objOut.flush();             // Flush Buffer
            outData = null;
            objOut = null;
         }
        if (inData != null) {
            inData = null;
            objIn = null;
         }
     }
}  // END class FileHandler