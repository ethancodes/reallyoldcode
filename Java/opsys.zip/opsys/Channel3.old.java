/**
 *  Channel 3. Simulates channel 3, which handles input and output spooling,
 *  GD and PD commands, and loading.
 *
 *  @author Ethan Georgi
 *  @version 10.18.1998
 */

public class Channel3
{
  private static int cardNumber = 0;

  private static int timer;
  private static boolean busy;
  private static int taskFlag = 0;
  private static boolean dtaCards = false;
  private static int numPCBs;
  private static String outputFullBuffer = new String();
  private static String inputFullBuffer = new String();
  private static PCB pcb;

  private static Drisk refToDrisk;
  private static Memory refToMemory;
  private static MOS refToMOS;
  private static CPU refToCPU;
  private static BufferPool refToBufPool;
  private static Queue refToReadyQ;
  private static Queue Channel3Q = new Queue();
  private static Queue LoadQ = new Queue();

  /**
   *  Constructor.
   *
   *  @param d Reference to the drisk
   *  @param m Reference to memory
   *  @param z Reference to the MOS
   *  @param c Reference to the CPU
   *  @param b Reference to the butterPool
   *  @param rdyq Reference to the ReadyQ
   */
  public Channel3(Drisk d, Memory m, MOS z, CPU c, BufferPool b, Queue rdyq)
  {
    refToDrisk = d; refToMemory = m; refToMOS = z;
    refToCPU = c; refToBufPool = b;
    refToReadyQ = rdyq;
    timer = 0;
    busy = false;
    taskFlag = 0;
    numPCBs = 0;
  }

  /**
   *  Increments the clocks. All Channel 3 operations take 2 clock cycles.
   */
  public void incClock()
  {
    timer++;
    if (done())
    {
      refToCPU.setIOI(4);
      Trace.writeln("Channel 3 rose a flag. BA-DUM!");
      busy = false;
    }
  }

  /**
   *  is channel three doing anything?
   *
   *  @return true- yes it is, false- no it isn't
   */
  public boolean isBusy() { return (busy == true); }

  /**
   *  Am i done with this operation yet?
   *
   *  @return True or False, yes i am, no not yet
   */
  public boolean done() { return (timer == 2); }

  /**
   *  Massive killer interrupt routine. Does house cleaning for the task
   *  it just finished doing, and starts the next one. Priorities: 
   *  Output Spooling, GD/PD, Loading, Input Spooling
   */
  public void interruptRoutine()
  {
    refToCPU.setIOI(-4);
    if (taskFlag > 0) { Trace.write("Channel3 finished "); }
    switch (taskFlag)
    {
      case 1 : //was doing output spooling
        Trace.writeln("output spooling...");
        refToBufPool.putOUT(outputFullBuffer);
        break;
      case 2 : //was doing a GD or PD command
        Trace.writeln("GD or PD instruction...");
        refToReadyQ.enqueue(pcb);
        break;
      case 3 : //loading
        Trace.writeln("loading...");
        refToMemory.dump();
        Trace.writeln("Moving PCB to ReadyQ");
        refToReadyQ.enqueue(pcb);
        break;
      case 4 : //input spooling
        Trace.writeln("input spooling...");
        refToBufPool.putEM(new String());
        break;
    } //end of switch

    Trace.writeln("Ch3Q  has size " + Integer.toString(Channel3Q.getSize()));
    Trace.writeln("LoadQ has size " + Integer.toString(LoadQ.getSize()));

    //assign a new task. yay priority!
    if (pcb != null)
    {
      Trace.writeln("PCB is not NULL");
      if ((pcb.getNumSpooled() > 0) && refToMOS.doneeoj())
         { Trace.writeln("Channel3 is now doing output spooling..."); 
           taskFlag = 1; timer = 0; busy = true; outputSpooling(); }
      else if (!Channel3Q.isEmpty())
        { Trace.writeln("Channel3 is now doing GD or PD...");
          taskFlag = 2; timer = 0; busy = true; doGDPD(); }
      else if (!LoadQ.isEmpty())
        { Trace.writeln("Channel3 is now doing loading..."); 
          taskFlag = 3; timer = 0; busy = true; load(); }
      else if (!refToBufPool.isINEmpty() && !refToDrisk.isFull()) 
        { Trace.writeln("Channel3 is now doing input spooling...");
          taskFlag = 4; timer = 0; busy = true; inputSpooling(); }
      else { Trace.writeln("Channel3 is now doing nothing..."); }
    }
    else
    {
      Trace.writeln("PCB is NULL");
      if (!Channel3Q.isEmpty())
        { Trace.writeln("Channel3 is now doing GD or PD...");
          taskFlag = 2; timer = 0; busy = true; doGDPD(); }
      else if (!LoadQ.isEmpty())
        { Trace.writeln("Channel3 is now doing loading..."); 
          taskFlag = 3; timer = 0; busy = true; load(); }
      else if (!refToBufPool.isINEmpty() && !refToDrisk.isFull()) 
        { Trace.writeln("Channel3 is now doing input spooling...");
          taskFlag = 4; timer = 0; busy = true; inputSpooling(); }
      else { Trace.writeln("Channel3 is now doing nothing..."); }
    }
  }

  /**
   *  Handles the next process on the Channel3Q, whether it is a GD or PD
   */
  public void doGDPD()
  {
    pcb = (PCB)Channel3Q.dequeue();
    int operand = Integer.parseInt(pcb.getIR().substring(2, 4));
    int mod = operand / 10;
    Trace.writeln("GDPD MOD is " + Integer.toString(mod));
    if (pcb.getIR().substring(0, 2).equals("GD"))
    {
      String[] block = new String[10];
      int malloc;
      int where = pcb.virtualToPhysical(mod * 10);
      //first see if we have to allocate more memory...
      if (where == -1) //yes we do
      {
        refToMOS.addToMemQ(pcb);
        pcb = null;
      }
      else //no we don't
      {
        where = where / 10;
        int pageOnDrisk = pcb.getNextDataCard();
        block = refToDrisk.readBlock(pageOnDrisk);
        Trace.write("GDing into mem[" + Integer.toString(where) + "] ");
        int i;
        for (i = 0; i < 10; i++) { Trace.write(block[i]); }
        Trace.writeln(".");
        refToMemory.writeBlock(where, block);
      }
    }
    else if (pcb.getIR().substring(0, 2).equals("PD"))
    {
      int op2 = pcb.virtualToPhysical(operand);
      String[] block = refToMemory.readBlock(op2 / 10);
      Trace.writeln("Getting from memory block " + Integer.toString(op2 / 10));
      int where = refToDrisk.allocate();
      Trace.write("PDing onto drisk[" + Integer.toString(where) + "] ");
      int i;
      for (i = 0; i < 10; i++) { Trace.write(block[i]); }
      Trace.writeln(".");
      refToDrisk.writeBlock(where, block);
      pcb.putOutput(where);
    }
  }

/**
 * This bad boy handles Input Spooling
 * Checks inputFullBuffer for data cards
 * Creates a new PCB if $JOB is called
 * 
 */
   public void inputSpooling()
   {
      Trace.writeln("Channel3 inputSpooling activated.");
      inputFullBuffer = refToBufPool.getIN();
      cardNumber++;     // Increment Card Number

      int blockNumber = refToDrisk.allocate();
      String[] bufferBlock = new String[10];       // This guarantees that 1 line = 10 words
      if (inputFullBuffer.charAt(0) == '$')
      {
         if (inputFullBuffer.substring(1, 4).equals("JOB"))
         {
               // $JOB Called before $EOJ
            if (pcb == null) {
               Trace.writeln("WARNING: $JOB Called before $EOJ - "
                           + "Card Number " + cardNumber);
            }
            
            try
            {
               int timeLimit = Integer.parseInt(inputFullBuffer.substring(8, 12));
               int printLimit = Integer.parseInt(inputFullBuffer.substring(12, 16));
               pcb = new PCB(inputFullBuffer.substring(4, 8), timeLimit, printLimit, refToMOS, refToCPU);
               numPCBs++;
            }
            catch (Exception ex)
            {
               Trace.writeln("ERROR: JOB Limit Exception! - "
                           + "Card Number " + cardNumber);
               pcb = null;
            }
            dtaCards = false;
         }  // END $JOB

         else if (inputFullBuffer.substring(1, 4).equals("REM")) 
         {
               // $REM Called out of $JOB bounds
            if (pcb == null) {
               Trace.writeln("WARNING: $REM Called out of bounds - "
                           + "Card Number " + cardNumber);
            }
            else
            {  // Write comment to PCB
               pcb.addRemark(inputFullBuffer.substring(4));
            }
         }
          
         else if (inputFullBuffer.substring(1, 4).equals("DTA"))
         {
               // $DTA Called out of $JOB bounds
            if (pcb == null) {
               Trace.writeln("ERROR: $DTA Called out of bounds - "
                           + "Card Number " + cardNumber);
            }
            else
            {  // Set dtaCards to True
               dtaCards = true;
            }
         }
         else if (inputFullBuffer.substring(1, 4).equals("EOJ") || inputFullBuffer.substring(1, 4).equals("END"))
         {
               // $EOJ Called out of $JOB bounds
            if (pcb == null) {
               Trace.writeln("ERROR: $EOJ Called out of bounds - "
                           + "Card Number " + cardNumber);
            }
            else
            {  // Send pcb to loadQueue
               Trace.writeln("Putting the PCB on the LoadQ.");
               LoadQ.enqueue(pcb);
               dtaCards = false;
            }
         }
         else  // Not a valid $ command
         {
            Trace.writeln("ERROR: $" + inputFullBuffer.substring(1, 4) + " "
                        + "Not recognized - "
                        + "Card Number " + cardNumber);
            
         }
      }  // END if (bufferBlock.charAt(0) == '$')
      else if (pcb != null)
      {  // Handle data cards
         for (int i = 0, j = 0; i < inputFullBuffer.length(); i+=4, j++)
         {
            int x = 4;
            if ((inputFullBuffer.length() - i) < 4)
            {
               x = (inputFullBuffer.length() - i);
            }
            bufferBlock[j] = inputFullBuffer.substring(i, i + x);
         }

            // Load Card onto Drisk
         refToDrisk.writeBlock(blockNumber, bufferBlock);
         if (dtaCards) { pcb.dataCardLoadedAt(blockNumber); }
         else  { pcb.programCardLoadedAt(blockNumber); }
      }  // END else if (pcb != null)
      else
      {
         Trace.writeln("ERROR: Data Card out of bounds - "
                     + "Card Number " + cardNumber);
      }
   }  // END of InoutSpooling

  /**
   *  takes and emptyBuffer and fills it with something with the process
   *  says is supposed to be printed, and puts it in the bufferPool as an
   *  outputFullBufer.
   */
  public void outputSpooling()
  {
    Trace.writeln("Channel3 output spooling activated.");
    if (!refToBufPool.isEMEmpty())
    {
      int next = pcb.getNextSpooled();
      outputFullBuffer = refToBufPool.getEM();
      if (!refToDrisk.isFree(next))
      {
        String[] block = refToDrisk.readBlock(next);
        refToDrisk.deallocate(next);
        int i;
        for (i = 0; i < 10; i++)
        {
          outputFullBuffer = outputFullBuffer + block[i];
        }
        Trace.writeln("outputFullBuffer is " + outputFullBuffer);
      }
      else
      {
        outputFullBuffer = " ";
        Trace.writeln("outputFullBuffer is a hoser.");
      }
    }
  }

  /**
   *  okay, so all the cards for this job have been input Spooled, now we
   *  load them into memory.... or something.
   */
  public void load()
  {
    Trace.writeln("Load the PCB into memory.");
    if (!refToMemory.isFull())
    {
      pcb = (PCB)LoadQ.dequeue();
      int i, w;
      for (i = 0, w = 0; i < pcb.getNumProgramCards(); i++, w++)
      {
        w = refToMemory.allocate();
        int pageOnDrisk = pcb.getNextProgramCard();
        String[] block = refToDrisk.readBlock(pageOnDrisk);
        refToMemory.writeBlock(w, block);
        pcb.pageTable[i] = w;
        Trace.write("loading program card to memory block ");
        Trace.write(Integer.toString(w) + " >");
        int j;
        for (j = 0; j < 10; j++) { Trace.write(block[j]); }
        Trace.writeln(".");
      }
    } //end if not full
    else
    {
      Trace.writeln("THERE IS NO FREE MEMORY!");
    }
  }

  /**
   *  add the pcb to the channel 3 q, for gd or pd commands...
   *
   *  @param p The pcb to enqueue
   */
  public void addToCh3Q(PCB p) { Channel3Q.enqueue(p); }

  /**
   *  add the pcb to the load q for loading...
   *
   *  @param p The pcb to enqueue
   */
  public void addToLoadQ(PCB p) { LoadQ.enqueue(p); }

  /**
   *  set channel 3 busy
   */
  public void setBusy()
  {
    Trace.writeln("Kick-starting Channel 3!");

    Trace.writeln("Ch3Q  has size " + Integer.toString(Channel3Q.getSize()));
    Trace.writeln("LoadQ has size " + Integer.toString(LoadQ.getSize()));

    //assign a new task. yay priority!
    if (pcb != null)
    {
      Trace.writeln("This PCB has spooled " + Integer.toString(pcb.getNumSpooled()));
      if ((pcb.getNumSpooled() > 0) && refToMOS.doneeoj())
         { Trace.writeln("Channel3 is now doing output spooling..."); 
           taskFlag = 1; timer = 0; busy = true; outputSpooling(); }
      else if (!Channel3Q.isEmpty())
        { Trace.writeln("Channel3 is now doing GD or PD...");
          taskFlag = 2; timer = 0; busy = true; doGDPD(); }
      else if (!LoadQ.isEmpty())
        { Trace.writeln("Channel3 is now doing loading..."); 
          taskFlag = 3; timer = 0; busy = true; load(); }
      else if (!refToBufPool.isINEmpty() && !refToDrisk.isFull()) 
        { Trace.writeln("Channel3 is now doing input spooling...");
          taskFlag = 4; timer = 0; busy = true; inputSpooling(); }
      else { Trace.writeln("Channel3 is now doing nothing..."); }
    }
    else
    {
      if (!Channel3Q.isEmpty())
        { Trace.writeln("Channel3 is now doing GD or PD...");
          taskFlag = 2; timer = 0; busy = true; doGDPD(); }
      else if (!LoadQ.isEmpty())
        { Trace.writeln("Channel3 is now doing loading..."); 
          taskFlag = 3; timer = 0; busy = true; load(); }
      else if (!refToBufPool.isINEmpty() && !refToDrisk.isFull()) 
        { Trace.writeln("Channel3 is now doing input spooling...");
          taskFlag = 4; timer = 0; busy = true; inputSpooling(); }
      else { Trace.writeln("Channel3 is now doing nothing..."); }
    }
  }

  /**
   *  How many processes are there?
   *
   *  @return The number of PCBs that Channel 3 has created.
   */
  public int getNumPCBs() { return numPCBs; }

  /**
   *  What is Channel3 doing?
   *
   *  @return The task flag
   */
  public int getTaskFlag() { return taskFlag; }

} //end of class
