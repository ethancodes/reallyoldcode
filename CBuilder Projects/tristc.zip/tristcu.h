//---------------------------------------------------------------------------
#ifndef tristcuH
#define tristcuH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\MPlayer.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TImage *Image1;
	TGroupBox *GroupBox1;
	TComboBox *ComboBox1;
	TBitBtn *BitBtn1;
	TBitBtn *BitBtn2;
	TMediaPlayer *MediaPlayer1;
	void __fastcall closeprog(TObject *Sender);
	void __fastcall shoot(TObject *Sender, TMouseButton Button, TShiftState Shift,
	int X, int Y);
	void __fastcall clearpic(TObject *Sender);
	
	
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
