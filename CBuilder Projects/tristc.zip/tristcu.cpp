//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "tristcu.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::closeprog(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::shoot(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y)
{
	TIcon *dart = new TIcon();

    if (ComboBox1->Text == "Pins")
    {
      dart->LoadFromFile("pin.ico");
      Canvas->Draw(X-(dart->Width), Y-(dart->Height), (TGraphic*)dart);
      MediaPlayer1->FileName = "boink.wav";
      MediaPlayer1->Open();
      MediaPlayer1->Play();
    }
    if (ComboBox1->Text == "Needles")
    {
      dart->LoadFromFile("needle.ico");
      Canvas->Draw(X-(dart->Width), Y, (TGraphic*)dart);
      MediaPlayer1->FileName = "boink.wav";
      MediaPlayer1->Open();
      MediaPlayer1->Play();
    }
    if (ComboBox1->Text == "Fists")
    {
      dart->LoadFromFile("fist.ico");
      Canvas->Draw(X-(dart->Width/2), Y-(dart->Height/2), (TGraphic*)dart);
      MediaPlayer1->FileName = "smack.wav";
      MediaPlayer1->Open();
      MediaPlayer1->Play();
    }
    if (ComboBox1->Text == "Lightning")
    {
      dart->LoadFromFile("light.ico");
      Canvas->Draw(X-(dart->Width/2), Y-(dart->Height)+10, (TGraphic*)dart);
      MediaPlayer1->FileName = "zap.wav";
      MediaPlayer1->Open();
      MediaPlayer1->Play();
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::clearpic(TObject *Sender)
{
	Image1->Refresh();
}
//---------------------------------------------------------------------------
