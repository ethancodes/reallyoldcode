//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#include <io.h>
#pragma hdrstop

#include "hacku.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::hack(TObject *Sender)
{
  FILE *stream;
  int handle;
  AnsiString filename;
  char *buf;
  int i, j;
  unsigned char nibble;

  //get me a filename to open
  filename = Edit1->Text;

  /* create a file */
  stream = fopen(filename.c_str(), "rb");

  /* obtain the file handle associated with the stream */
  handle = fileno(stream);
  buf = (char *) malloc(filelength(handle));
  fread(buf, filelength(handle), 1, stream);
  for (i = 0, j = 1; i <= filelength(handle); i++)
  {
    if ((i % 128) == 0)
    {
      j++;
    }
    if ((int)buf[i] != 0)
    {
      Image1->Canvas->Pixels[(i % 128) + 1][j] = (TColor)buf[i];
    }
  }
  /* close the file */
  fclose(stream);
  Image1->Width = 800;
  Image1->Height = 450;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::closeprog(TObject *Sender)
{
	Close();	
}
//---------------------------------------------------------------------------