#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi - Programming Assignment #5 - September 19, 1997
//Take in n numbers and average them - n is user defined

int main()
{
  int x = 1, numofnums;   //the number of numbers
  float num, sum = 0, ave;

  clrscr();

  cout << "How many numbers would you like to find the average of? ";
  cin >> numofnums;

  while (x <= numofnums)
  {
    cout << "Enter value " << x << ": ";
    cin >> num;

    sum += num;
    x++;
  }

  ave = sum / numofnums;

  cout << setiosflags(ios::fixed) << setprecision(2);
  cout << "These " << numofnums << " values have an average of " << ave;

  return 0;
}
