#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi - Programming Assignment #6 - September 28, 1997
//Depreciation

int main()
{
  int value = 28000, dep = 4000, years = 7, accumulated = 0, i;

  clrscr();

  cout << "                  Depreciation Schedule\n";
  cout << "Year  Depreciation  End-of-Year Value  Accumulated Depreciation\n";
  cout << "---------------------------------------------------------------\n";
  for (i = 1; i <= years; i++)
  {
    value -= dep;   //value = value - dep
    accumulated += dep;	  //accumulated = accumulated + dep
    cout << setw(3) << i;
    cout << setw(10) << dep;
    cout << setw(18) << value;
    cout << setw(20) << accumulated << "\n";
  }

  return 0;
}

