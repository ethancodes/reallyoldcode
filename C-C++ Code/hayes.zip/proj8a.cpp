#include <iostream.h>
#include <iomanip.h>
#include <conio.h>
#include <math.h>

class Coord
{
  friend void conv_pol(float, float, Coord&);
  private:
    float x;
    float y;
  public:
    Coord(float, float);
    void showdata(void);
};

Coord::Coord(float defaultx = 0.0, float defaulty = 0.0)
{
  x = defaultx;
  y = defaulty;
}

void Coord::showdata(void)
{
  cout << "(" << x << ", " << y << ")";

  return;
}

//friend prototype
void conv_pol(float, float, Coord&);

const double pi = (2 * asin(1));

int main()
{
  Coord p1(3.0, 4.0), p2(-10.0, -5.0);
  float radius, degrees;

  clrscr();
  cout << setiosflags(ios::fixed | ios::showpoint);
  cout << setprecision(3);

  cout << "P1 is at ";
  p1.showdata();
  cout << "\n";

  cout << "P2 is at ";
  p2.showdata();
  cout << "\n";

  cout << "\n";
  cout << "Enter the radius for the first point: ";
  cin >> radius;
  cout << "Enter the angle of the first point in degrees: ";
  cin >> degrees;

  conv_pol(radius, degrees, p1);
  cout << "P1 is at ";
  p1.showdata();
  cout << "\n";
  
  cout << "\n";
  cout << "Enter the radius for the second point: ";
  cin >> radius;
  cout << "Enter the angle of the second point in degrees: ";
  cin >> degrees;

  conv_pol(radius, degrees, p2);
  cout << "P2 is at ";
  p2.showdata();
  cout << "\n";

  return 0;
}

void conv_pol(float r, float theta, Coord& p)
{
  //convert theta from degrees to radians
  theta = (theta / 180.0) * pi;

  p.x = r * cos(theta);
  p.y = r * sin(theta);

  return;
}
