#include <iostream.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>

//Ethan Georgi
//Mad Max: Beyond Palindrome

int main()
{
  char p1[101], p2[101], p3[101];
  char ch;
  int i, j, palin;

  clrscr();

  cout << "Please enter a phrase up to 100 characters.\n";
  cin.getline(p1, 101);

  for (i = 0, j = 0; i <= (strlen(p1)-1); i++)
  {
    ch = p1[i];
    if (isalpha(ch))
    {
      p2[j] = toupper(ch);
      j++;   //this isn't microsoft...
    }
  }
  p2[j] = '\0';

  for (i = 0, j = (strlen(p2)-1); i <= (strlen(p2)-1); i++, j--)
  {
    p3[j] = p2[i];
  }
  p3[i] = '\0';

  //p2 contains the input phrase in uppercase letters
  //p3 contains p2 backwards

  palin = strcmp(p2, p3);
  switch (palin)
  {
    case 0  : cout << "\n" << p1 << " is a palindrome!\n";
              break;
    default : cout << "\n" << p1 << " is not a palindrome.\n";
              break;
  }

  return 0;
}