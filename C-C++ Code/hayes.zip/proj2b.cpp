#include <iostream.h>
#include <conio.h>
#include <math.h>
#include <iomanip.h>

// Ethan Georgi - Programming Assignment #2 - September 7
// Calculate interest

int main()
{
  //Variables
  float Amount,
        A = 10000.0,  //The initial investment
        I = 0.1;      //The interest rate
  int N = 4;          //The number of years of savings

  clrscr();

  Amount = A * (pow( (1 + I),N) );

  cout << setiosflags(ios::fixed) << setprecision(2);
  cout << "After " << N << " years, at " << (I*100) << "% interest, ";
  cout << "$" << A << " amounts to $" << Amount;

  return 0;
}
        
