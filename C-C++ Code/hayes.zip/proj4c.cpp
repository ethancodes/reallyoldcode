#include <iostream.h>
#include <iomanip.h>
#include <conio.h>
#include <math.h>

//Ethan Georgi - Programming Assignment #4 - September 18
//Area, Circumference, or Diameter of a circle

int main()
{
  float radius;
  char which;

  cout << setiosflags(ios::fixed) << setprecision(3);

  clrscr();

  cout << "Enter the radius and A for area, D for diameter,\n";
  cout << "or C for circumference. (Ex. 10.5 a, 19.034 c)\n> ";
  cin >> radius >> which;

  switch (which)
  {
    case 'A' :
    case 'a' : cout << "A circle with a radius of " << radius;
    				cout << " will have an area of " << (radius * radius * 3.14159);
               break;
    case 'D' :
    case 'd' : cout << "A circle with a radius of " << radius;
    				cout << " will have a diameter of " << (radius * 2);
               break;
    case 'C' :
    case 'c' : cout << "A circle with a radius of " << radius;
    				cout << " will have a circumference of ";
               cout << (2 * radius * 3.14159);
               break;
    default  : cout << "Invalid code: " << which << "! Must be C D or A";
  }

  return 0;
}
