#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <conio.h>

//Ethan Georgi

class Person
{
  protected:
    char *name;
    int idnum;
    char gender;
  public:
    Person(char *n = "Person", int id = 1, char gen = 'X');
    void setup(char *n, int id, char gen);
    void showperson();
};

Person::Person(char *n, int id, char gen)
{
  name = n;
  idnum = id;
  gender = gen;
}

void Person::setup(char *n, int id, char gen)
{
  strcpy(name, n);
  idnum = id;
  gender = gen;
  return;
}

void Person::showperson()
{
  cout << name << "\n" << "#" << idnum << "\n";
  if (gender == 'F')
  {
    cout << "Female\n";
  }
  else
  {
    cout << "Male\n\n";
  }
  return;
}

class Employee : public Person
{
  friend float PayCheck(Employee&, int);
  protected:
    float HourlyRate;
  public:
    Employee(char *n = "Employee", int id = 10, char gen = 'x', float rate = 5.25) : 
			Person(n, id, gen), HourlyRate(rate) {};
    void setup(char *n, int id, char gen, float rate);
    virtual void showperson();
};    

void Employee::setup(char *n, int id, char gen, float rate)
{
  strcpy(name, n);
  idnum = id;
  gender = gen;
  HourlyRate = rate;
  return;
}

void Employee::showperson()
{
  cout << name << "\n" << "#" << idnum << "\n";
  if (gender == 'F')
  {
    cout << "Female\n";
  }
  else
  {
    cout << "Male\n";
  }
  cout << setiosflags(ios::fixed | ios::showpoint) << setprecision(2);
  cout << "$" << HourlyRate << "\n\n";
  return;
}

float PayCheck(Employee& e, int h)
{
  int overtime;
  
  if (h > 40)
  {
    overtime = h - 40;
    return ((e.HourlyRate * 40) + (1.5 * e.HourlyRate * overtime));
  }
  else
  {
    return (e.HourlyRate * h);
  }
}

int main()
{
  Employee Worker1,
           Worker2("Charlie Brown", 2345, 'M', 12.5),
           Worker3("Mary Smith", 6079, 'F', 15);
  int w2hrs, w3hrs;

  clrscr();

  Worker1.showperson();
  Worker2.showperson();
  Worker3.showperson();  

  cout << "Enter Worker Two's hours: ";
  cin >> w2hrs;
  cout << "Enter Worker Three's hours: ";
  cin >> w3hrs;
  cout << "Worker Two's paycheck is for " << PayCheck(Worker2, w2hrs) << "\n";
  cout << "Worker Three's paycheck is for " << PayCheck(Worker3, w3hrs) << "\n";

  return 0;
}