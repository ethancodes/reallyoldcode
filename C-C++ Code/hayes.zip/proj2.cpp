#include <iostream.h>
#include <conio.h>
#include <iomanip.h>

// Ethan Georgi - Programming Assignment #2 - September 6
// Coonvert an input temperature in Fahrenheit to Celcius

int main()
{
  //Variables
  float ftemp, ctemp;

  clrscr();

  //Get the temperature in degrees to convert
  cout << "Enter the temperature in degrees Fahrenheit to convert";
  cout << " to Celcius: ";
  cin >> ftemp;

  //Calculate the temperature in Celcius
  ctemp = (ftemp-32) / 1.8;

  cout << ftemp << " degrees Fahrenheit is equal to ";
  cout << setiosflags(ios::fixed) << setprecision(2) << ctemp;
  cout << " degrees Celcius.\n";

  return 0;
}

