#include <iostream.h>
#include <iomanip.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

//Ethan Georgi - Programming Assignment #7 - October 7 1997
//New York State Lotto

void play(int n);

int main()
{
  //Variables
  int numberofplays;

  clrscr();
  //Get input
  cout << "How many plays do you want? ";
  cin >> numberofplays;

  //Generate random #s
  srand(time(NULL));			//NULL has to be in caps- i tested it
  play(numberofplays);

  return 0;
}

void play(int n)
{
  //Local variables
  int x, y;

  //First loop: how many plays of 6 #s
  for (x = 1; x <= n; x++)
  {
    cout << "Play " << x << " -";
    //Inner loop: 6 times
    for (y = 1; y <= 6; y++)
    {
      cout << setw(3);
      cout << 1 + (rand() % 54);
    }
    cout << "\n";
  }

  return;
}