#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi - Programming Assignment #6 - October 1, 1997
//Volume and Areas of cylinders

float volume (float r, float h);
void areas (float r, float h, float &sarea, float &barea);

float pi = 3.14159;

int main()
{
  float radius, height, surfaceArea = 0.0, baseArea = 0.0;

  clrscr();

  cout << "Enter the radius of the cylinder: ";
  cin >> radius;
  cout << "Enter the height of the cylinder: ";
  cin >> height;

  cout << setiosflags(ios::fixed | ios::showpoint) << setprecision(3);
  cout << "A cylinder with a radius of " << radius << " and a height ";
  cout << "of " << height << "\nhas a volume of " << volume(radius, height);
  cout << ".\nThe base of the cylinder has an area of ";
  areas(radius, height, surfaceArea, baseArea);
  cout << baseArea << ".\nThe surface area of the entire cylinder is ";
  cout << surfaceArea << ".\n";

  return 0;
}

float volume (float r, float h)
{
  //volume of a cylinder = pi * r^2 * h
  return (pi * r * r * h);
}

void areas (float r, float h, float &sarea, float &barea)
{
  //area of base = pi * r^2
  barea = (pi * r * r);
  //surface area of a cylinder
  //  = (area of base * 2) + (height * circumference of base) (2 * pi * r)
  sarea = (barea * 2) + (h  * (2 * pi * r));

  return;
}
