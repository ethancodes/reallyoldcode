#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi - Programming Assignment #5 - September 19, 1997
//Number line on crack

int main()
{
  int x = 0;

  clrscr();

  while (x < 10)
  {
    //this is the way i had it. this shouldn't work. it should put
    //the 1 in the 1 column, instead of the second, and so on.
    cout << setw(x) << x++ << "\n";
    //first set of output
  }
  x = 0;
  while (x < 10)
  {
    //this is the way it should work logically. when x is 0 it will
    //put it in the 1 column, when x is 1 it will put it in the 2
    //column. however this doesn't work. it throws everything off
    //by one. 0 is in the 2 column.
    cout << setw(x+1) << x++ << "\n";
    //second set of output
  }

  return 0;
}