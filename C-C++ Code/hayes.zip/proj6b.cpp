#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi - Programming Assignment #6 - September 28, 1997
//More interest problems...

int main()
{
  float initial = 1000.00, interest = 0.08, total;
  int years = 10, i;

  clrscr();
  total = initial;
  cout << setiosflags(ios::fixed | ios::showpoint) << setprecision(2);

  for (i = 1; i <= years; i++)
  {
    total = total + (interest * total);
    cout << "After " << i << " years the investment is worth " << total << "\n";
  }

  return 0;
}

