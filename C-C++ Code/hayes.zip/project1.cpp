#include <iostream.h>
#include <conio.h>

//            Ethan Georgi - Project One - September 2 1997
//            Write your name as output, and some academic quotation

int main()
{
  //Clear the screen...
  clrscr();

  //Print my name to the screen...
  cout << "Ethan Georgi\n\n";

  //Print some academic quotation...
  cout << "Never let school interfere with your education.\n";
  cout << "I want to know God's thoughts, the rest is just details.\n";
  cout << "No more homework, no more books, no more of teacher's ";
  cout << "dirty looks!\n";

  //Just for the author...
  return 0;
}
