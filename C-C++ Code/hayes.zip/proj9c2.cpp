#include <iostream.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>

//Ethan Georgi
//The RIGHT way to do palindromes

int main()
{
  char p[101];
  char c1, c2;
  int i, j, palin = 1;

  clrscr();

  cout << "Enter a phrase up to 100 characters.\n";
  cin.getline(p, 101);

  i = 0;
  j = strlen(p)-1;

  while ((i < j) && (palin == 1))
  {
    while (!(isalpha(p[i])))
    {
      i++;
    }
    c1 = toupper(p[i]);

    while (!(isalpha(p[j])))
    {
      j--;
    }
    c2 = toupper(p[j]);

    palin = (c1 == c2);
    i++;
    j--;
  }

  switch (palin)
  {
    case 1  : cout << "\n" << p << " is a palindrome!\n";
              break;
    default : cout << "\n" << p << " is not a palindrome!\n";
              break;
  }

  return 0;
}