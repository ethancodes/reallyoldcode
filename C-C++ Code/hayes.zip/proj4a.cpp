#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi - Programming Assignment #4 - September 17, 1997
//Convert Celcius to Fahrenheit and back

int main()
{
  //Variables
  float temp, convert;
  char corf;

  clrscr();

  cout << "Enter the temperature and (F)ahrenheit or (C)elcius.\n";
  cout << "For Example: 98.6 F or 100 C \n> ";
  cin >> temp >> corf;

  if ((corf == 'f') || (corf == 'F'))
  {
    convert = (temp - 32) / 1.8;
    cout << setiosflags(ios::fixed) << setprecision(3);
    cout << temp << " degrees Fahrenheit is " << convert;
    cout << " degrees Celcius.";
  }
  else if ((corf == 'c') || (corf == 'C'))
  {
    convert = (temp * 1.8) + 32;
    cout << setiosflags(ios::fixed) << setprecision(3);
    cout << temp << " degrees Celcius is " << convert;
    cout << " degrees Fahrenheit.";
  }
  else
  {
    cout << corf << " is not a valid unit of measurement.";
  }

  return 0;
}

