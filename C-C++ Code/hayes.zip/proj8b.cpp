#include <iostream.h>
#include <iomanip.h>
#include <conio.h>
#include <math.h>

//Ethan Georgi - Programming Assignment #8
//Rectangle and Polar Coordinates

float pi = (2 * asin(1));

//forward declaration
class Pol_coord;

class Rec_coord
{
  friend void convert(int, float, float, Rec_coord&, Pol_coord&);
  private:
    float xval;
    float yval;
  public:
    Rec_coord();
    void showpoint();
};

Rec_coord::Rec_coord()
{
  xval = 1.0;
  yval = 1.0;
}

void Rec_coord::showpoint()
{
  cout << "(" << xval << "," << yval << ")";

  return;
}

class Pol_coord
{
  friend void convert(int, float, float, Rec_coord&, Pol_coord&);
  private:
    float dist;
    float theta;
  public:
    Pol_coord();
    void showpoint();
};

Pol_coord::Pol_coord()
{
  dist = 1.0;
  theta = 45.0;
}

void Pol_coord::showpoint()
{
  cout << "Radius of " << dist << ", Theta of " << theta;

  return;
}

void convert(int dir, float val1, float val2, Rec_coord& recref, Pol_coord& polref)
{
  if (!dir)
  {
    //if dir is ZER0 then rectangle --> polar
    polref.dist = sqrt((val1*val1) + (val2*val2));
    if (val1 > 0)
    {
      polref.theta = (atan(val2/val1)) * (180/pi);
    }
    if (val1 < 0)
    {
      polref.theta = ((atan(val2/val1)) + pi) * (180/pi);
    }
    if (val1 == 0)
    {
      if (val2 > 0)
      {
        polref.theta = 90.0;
      }
      if (val2 < 0)
      {
        polref.theta = 270.0;
      }
    }
  }
  if (dir)
  {
    //if dir is NOT ZER0 then polar --> rectangle
    recref.xval = val1 * cos((val2 * (pi/180)));
    recref.yval = val1 * sin((val2 * (pi/180)));
  }

  return;
}

int main()
{
  Rec_coord r;
  Pol_coord p;
  float first, second;
  int RorP;
  char RP;

  clrscr();

  cout << "Enter R if you're giving rectangular coordinates...\n";
  cout << "...or P if you're giving polar coordinates: ";
  cin >> RP;

  switch (RP)
  {
    case 'r' :
    case 'R' : RorP = 0;
               break;
    case 'p' :
    case 'P' : RorP = 1;
               break;
  }
  
  if (RorP)
  {
    cout << "Enter the radius: ";
    cin >> first;
    cout << "Enter theta in degrees: ";
    cin >> second;
  }
  if (!RorP)
  {
    cout << "Enter the x value: ";
    cin >> first;
    cout << "Enter the y value: ";
    cin >> second;
  }
  
  convert(RorP, first, second, r, p);

  cout << setiosflags(ios::fixed | ios::showpoint);
  cout << setprecision(3);

  if (RorP)
  {
    cout << "The point is at ";
    r.showpoint();
    cout << "\n";
  }
  if (!RorP)
  {
    p.showpoint();
    cout << "\n";
  }

  return 0;
}
