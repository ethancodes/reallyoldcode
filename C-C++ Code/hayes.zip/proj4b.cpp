#include <iostream.h>
#include <iomanip.h>
#include <conio.h>
#include <math.h>

//Ethan Georgi - Programming Assignment #4 - September 18, 1997
//Quadratic equations with real and complex roots

int main()
{
  //You guessed it. . .
  float a, b, c;
  float discrim, root1, complex, root2;
  clrscr();

  cout << "Enter a: ";
  cin >> a;
  cout << "Enter b: ";
  cin >> b;
  cout << "Enter c: ";
  cin >> c;

  cout << setiosflags(ios::fixed) << setprecision(2);

  if (!a)  //if a = 0 then we've got a straight line with one real root
  {
    cout << "This is not a quadratic expression!\n";
  }
  else
  {
    //now let's find out if it has real or imaginary roots
    discrim = (b*b - (4 * a * c));
    if (discrim < 0)
    {  //negative? imaginary roots
      root1 = (-b) / (2 * a);
      complex = sqrt(-discrim) / (2 * a);
      cout << "The two imaginary roots are ";
      cout << root1 << "+" << complex << "i ";
      cout << "and " << root1 << "-" << complex << "i";
    }
    else
    {  //positive? real roots
      root1 = ((-b) + sqrt(discrim)) / (2 * a);
      root2 = ((-b) - sqrt(discrim)) / (2 * a);
      if (root1 == root2)
      {
        cout << "The only real root is " << root1;
      }
      else
      {
        cout << "The two real roots are " << root1;
        cout << " and " << root2;
      }
    }
  } //else a != 0

  return 0;
}
