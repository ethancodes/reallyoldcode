#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi

struct Employee
{
  int number;
  char name[20];
  float rate;
  int hours;
};

int main()
{
  Employee emprec[6];
  int x;
  float total = 0.0;

  clrscr();

  for (x = 0; x <= 5; x++)
  {
    cout << "Enter employee number: ";
    cin >> emprec[x].number;
    cout << "Enter employee name: ";
    cin >> emprec[x].name;
    cout << "Enter employee rate: ";
    cin >> emprec[x].rate;
    cout << "Enter employee hours: ";
    cin >> emprec[x].hours;
    cout << endl;
  }
  
  cout << "Payroll Report\n";
  cout << "--------------\n\n";
  cout << "   NAME             NUMBER   GROSS PAY\n";
  cout << "--------------------------------------\n";

  for (x = 0; x <= 5; x++)
  {
    cout << setw(15) << emprec[x].name << setw(10) << emprec[x].number;
    if (emprec[x].hours > 40)
    {
      cout << setw(7) << setprecision(2) << setiosflags(ios::fixed | ios::showpoint)
           << "$" << ((emprec[x].rate * 40) + ((emprec[x].hours - 40) * emprec[x].rate * 1.5));
      total += ((emprec[x].rate * 40) + ((emprec[x].hours - 40) * emprec[x].rate * 1.5));
    }
    else
    {
      cout << setw(7) << setprecision(2) << setiosflags(ios::fixed | ios::showpoint)
           << "$" << emprec[x].rate * emprec[x].hours;
      total += emprec[x].rate * emprec[x].hours;
    }
    cout << endl;
  }

  cout << "TOTAL" << setw(27) << setprecision(2) << setiosflags(ios::fixed | ios::showpoint)
       << "$" << total;

  return 0;
}
