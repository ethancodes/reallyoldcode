#include <iostream.h>
#include <iomanip.h>
#include <conio.h>
#include <math.h>

// Ethan Georgi - Programming Assignment #3 - September 14 1997
// The Fourth Root

int main()
{
  //Variables
  float number;   //The user-entered number

  clrscr();

  //Prompt the (ab)user for input
  cout << "Enter a number to find the fourth root of: ";
  cin >> number;

  //Output
  cout << setiosflags(ios::fixed | ios::showpoint) << setprecision(4);
  cout << "The fourth root of " << number << " is ";
  cout << pow(number, 0.25);

  //One day i'm gonna fail because i forget this next line...
  return 0;
}
