#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi - Programming Assignment #7 - October 10 1997
//class Rectangle

class Rectangle
{
  private:
    float length;
    float width;
  public:
    Rectangle(float l = 0, float w = 0);
    float perimeter();
    float area();
    void getData();
    void showData();

};

//Rectangle constructor
Rectangle::Rectangle(float l, float w)
{
  length = l;
  width = w;
}

//Rectangle.perimeter()
float Rectangle::perimeter()
{
  return ((2*length) + (2*width));
}

//Rectangle.area()
float Rectangle::area()
{
  return (length * width);
}

//Rectangle.getData()
void Rectangle::getData()
{
  cout << "What is the length of this rectangle? ";
  cin >> length;
  cout << "What is the width of this rectangle? ";
  cin >> width;
  cout << "\n";
}

//Rectangle.showData()
void Rectangle::showData()
{
  cout << "The rectangle is " << length << " by " << width << "\n";
  cout << "and has a perimeter of " << perimeter() << "\n";
  cout << "and an area of " << area() << "\n";
}

int main()
{
  Rectangle rect1, rect2;

  clrscr();

  cout << "First rectangle:\n";
  rect1.getData();
  cout << "Second rectangle:\n";
  rect2.getData();

  cout << setiosflags(ios::fixed | ios::showpoint) << setprecision(3);

  cout << "First rectangle:\n";
  rect1.showData();

  cout << "Second rectangle:\n";
  rect2.showData();

  return 0;
}
