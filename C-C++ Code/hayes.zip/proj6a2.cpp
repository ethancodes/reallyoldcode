#include <iostream.h>
#include <iomanip.h>
#include <conio.h>

//Ethan Georgi - Programming Assignment #6 - October 1
//money makes the world go round

void totamt(int q, int d, int n, int p);

int main()
{
  int quarters, dimes, nickels, pennies;

  clrscr();

  cout << "Enter the number of quarters: ";
  cin >> quarters;
  cout << "Enter the number of dimes: ";
  cin >> dimes;
  cout << "Enter the number of nickels: ";
  cin >> nickels;
  cout << "Enter the number of pennies: ";
  cin >> pennies;

  totamt(quarters, dimes, nickels, pennies);

  return 0;
}

void totamt(int q, int d, int n, int p)
{
  float total;

  total = q / 4.0;
  total += d / 10.0;
  total += n / 20.0;
  total += p / 100.0;

  cout << setiosflags(ios::fixed | ios::showpoint) << setprecision(2);
  cout << q << " quartes, " << d << " dimes, " << n << " nickels, and ";
  cout << p << " pennies, is worth $" << total << "\n";

  return;
}



