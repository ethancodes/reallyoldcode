#include <iostream.h>
#include <iomanip.h>
#include <conio.h>
#include <math.h>

// Ethan Georgi - Programming Assignment #3 - September 14 1997
// More interest calculations
// Year 2000 Compliant

int main()
{
  //Variables
  float a, x, r;
  int n;

  clrscr();

  //Prompt the user for input values...
  cout << "Enter the initial investment: ";
  cin >> x;
  cout << "Enter the interest rate (for example, 6%): ";
  cin >> r;
  cout << "Enter the number of years for interest to accumulate: ";
  cin >> n;

  //Calculate the answer...
  a = x * (pow((1.0 + r/100.0),n));

  cout << setiosflags(ios::fixed | ios::showpoint) << setprecision(2);
  /* i know you said for decimal places for these problems but four
     decimal places when dealing with money is wrong... */
  cout << "$" << x << " invested for " << n << " years at ";
  cout << r << "% would yield $" << a;

  return 0;
}
