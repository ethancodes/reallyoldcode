#include <iostream.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

//Ethan Georgi

int main()
{
  int array[1000];
  int i, highcount = 0, lowcount = 0;

  srand(time(NULL));

  //fill the array with random values from 1 to 100
  for (i = 0; i <= 999; i++)
  {
    array[i] = 1 + (rand() % 100);
  }

  //now traverse the array and compare to 50
  for (i = 0; i <= 999; i++)
  {
    if (array[i] < 51)
    {
      lowcount++;
    }
    else
    {
      highcount++;
    }
  }

  clrscr();
  cout << "There were " << highcount << " values over 50.\n";
  cout << "There were " << lowcount << " values 50 and under.\n";

  return 0;
}
