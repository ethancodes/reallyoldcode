//HACK the Castlevania files

#include <graphics.h>
#include <iostream.h>
#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include <io.h>

int main()
{
  FILE *stream;
  int handle;
  char filename[50];
  char *buf;
  int gdriver = DETECT, gmode;
  int i, j, cutoff = 32;
  unsigned char nibble;

  //get me a filename to open
  cout << "File to open? ";
  cin >> filename;

  /* create a file */
  stream = fopen(filename, "rb");

  if (stream == NULL)
  {
    cout << "No file.\n";
  }
  else
  {
    /* obtain the file handle associated with the stream */
    handle = fileno(stream);

    buf = (char *) malloc(filelength(handle));

    fread(buf, filelength(handle), 1, stream);
  }

  initgraph(&gdriver, &gmode, "D:\\borland\\bc50\\bgi");

  if (graphresult() < 0)
  {
    cout << "SHIT!\n";
  }
  else
  {
    for (i = 0, j = 1; i <= filelength(handle); i++)
    {
      if ((i % cutoff) == 0)
      {
        j++;
      }
      putpixel((i%cutoff) + 1, j, (int)buf[i]);
      putpixel((i%cutoff) + 2, j, (int)buf[i]);
      putpixel((i%cutoff) + 3, j, (int)buf[i]);
      putpixel((i%cutoff) + 4, j, (int)buf[i]);
    }
  }
  /* close the file */
  fclose(stream);
  closegraph();
  return 0;
}