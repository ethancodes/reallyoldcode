#include <graphics.h>
#include <iostream.h>

int main()
{
  int driver = DETECT, mode, junk, i;

  initgraph(&driver, &mode, "D:\\borland\\bc50\\bgi");
  for (i = 1; i <= 15; i++)
  {
    putpixel(i,i,i);
  }
  cin >> junk;

  closegraph();
  return 0;
}