#include    "eiffel.h"
/*------------------------------------------------------------------*/

CHARACTER    *ELSA [] = {
(CHARACTER *) "---.---.---",
(CHARACTER *) "--.--.--",
(CHARACTER *) "..",
(CHARACTER *) ".",
(CHARACTER *) "rw.rw.rw",
(CHARACTER *) "true",
(CHARACTER *) "false",
(CHARACTER *) "Sorry - You don�t have list permission\n",
(CHARACTER *) " Use -h for help\n\n",
(CHARACTER *) "-r",
(CHARACTER *) "-l",
(CHARACTER *) "-h",
(CHARACTER *) "-a",
(CHARACTER *) "  -h : print this help text\n",
(CHARACTER *) "  -r : process subclusters recursively\n",
(CHARACTER *) "  -l : list projects only - don\'t remove them\n",
(CHARACTER *) "  -a : don\'t ask before removal\n",
(CHARACTER *) ".pdl",
(CHARACTER *) "cc.out",
(CHARACTER *) "cc.err",
(CHARACTER *) "ecc.err",
(CHARACTER *) "etrace",
(CHARACTER *) "eiffel.err",
(CHARACTER *) ".pdb",
(CHARACTER *) ".p",
(CHARACTER *) ".op",
(CHARACTER *) " Remove : ",
(CHARACTER *) " ? (Y/N) : ",
(CHARACTER *) "  -- Cannot remove cluster \"",
(CHARACTER *) "\" - permission denied.\n",
(CHARACTER *) 0
};
/*------------------------------------------------------------------*/

