/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H3.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_boolean_ref;
extern  ECDESC        EECD_boolean_ref;
ECDESC                ECD_boolean;
ECDESC                EECD_boolean;
/*------------------------------------------------------------------*/

BOOLEAN               E67649539 ();
BOOLEAN               E68059139 ();
BOOLEAN               E68263939 ();
BOOLEAN               E68395011 ();
BOOLEAN               E68567043 ();
BOOLEAN               E68575235 ();
BOOLEAN               E68583427 ();
/*------------------------------------------------------------------*/

BOOLEAN       E67649539 (_cf, _a0)

RTF           *_cf;
BOOLEAN       _a0;

{
#ifndef EDCR67649539
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68059139 (_cf, _a0, _a1)

RTF           *_cf;
BOOLEAN       _a0;
BOOLEAN       _a1;

{
#ifndef EDCR68059139
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68263939 (_cf, _a0, _a1)

RTF           *_cf;
BOOLEAN       _a0;
BOOLEAN       _a1;

{
#ifndef EDCR68263939
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68395011 (_cf, _a0, _a1)

RTF           *_cf;
BOOLEAN       _a0;
BOOLEAN       _a1;

{
#ifndef EDCR68395011
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68567043 (_cf, _a0, _a1)

RTF           *_cf;
BOOLEAN       _a0;
BOOLEAN       _a1;

{
#ifndef EDCR68567043
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68575235 (_cf, _a0, _a1)

RTF           *_cf;
BOOLEAN       _a0;
BOOLEAN       _a1;

{
#ifndef EDCR68575235
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68583427 (_cf, _a0, _a1)

RTF           *_cf;
BOOLEAN       _a0;
BOOLEAN       _a1;

{
#ifndef EDCR68583427
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void    ECR3 (obj)

ECA_boolean  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST3 (d)

INTEGER d;

{
    ECA_boolean  p;
    ECDESC  *cd = &ECD_boolean, *ecd = &EECD_boolean;

    cd->f1          = (INTEGER) 3;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_boolean);
    cd->f12         = "boolean";
    cd->f6          = false;
    cd->f13         = ECR3;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " b";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eitem)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "item";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_boolean_ref;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_boolean;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

