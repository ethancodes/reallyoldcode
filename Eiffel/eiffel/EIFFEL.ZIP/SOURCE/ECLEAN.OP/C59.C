/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H59.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_comparable;
extern  ECDESC        EECD_comparable;
extern  ECDESC        ECD_collection;
extern  ECDESC        EECD_collection;
extern  ECDESC        ECD_twoway_iter;
extern  ECDESC        EECD_twoway_iter;
extern  ECDESC        ECD_twoway_traversable;
extern  ECDESC        EECD_twoway_traversable;
extern  ECDESC        ECD_g;
extern  ECDESC        EECD_g;
ECDESC                ECD_sorted_collection;
ECDESC                EECD_sorted_collection;
/*------------------------------------------------------------------*/

extern  void          E67125291 ();
extern  void          E72704051 ();
extern  BOOLEAN       E72679475 ();
extern  void          E73269291 ();
extern  void          E73293867 ();
extern  void          E72712243 ();
/*------------------------------------------------------------------*/

OBJREF                E72687675 ();
void                  E72843323 ();
OBJREF                E72695867 ();
void                  E72851515 ();
/*------------------------------------------------------------------*/

OBJREF        E72687675 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72687675
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_twoway_iter);
    E67125291 (&_mf, _o [0], _a0);
    E72843323 (&_mf, _a0, _a1, _o [0]);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E72695867 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72695867
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_twoway_iter);
    E67125291 (&_mf, _o [0], _a0);
    E72851515 (&_mf, _a0, _a1, _o [0]);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E72843323 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR72843323
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72704051 (&_mf, _a0, _a1, _a2);
    if (E72679475 (&_mf, _a0, _a2))
    {
       E73269291 (&_mf, _a2);
    }
    else
    {
       E73293867 (&_mf, _a2);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72851515 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR72851515
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72712243 (&_mf, _a0, _a1, _a2);
    if (E72679475 (&_mf, _a0, _a2))
    {
       E73269291 (&_mf, _a2);
    }
    else
    {
       E73293867 (&_mf, _a2);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void    ECR59 (obj)

ECA_sorted_collection  *obj;

{

    obj->Efound_item = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST59 (d)

INTEGER d;

{
    ECA_sorted_collection  p;
    ECDESC  *cd = &ECD_sorted_collection, *ecd = &EECD_sorted_collection;

    cd->f1          = (INTEGER) 59;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_sorted_collection);
    cd->f12         = "sorted_collection";
    cd->f6          = false;
    cd->f13         = ECR59;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ibobi";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 5) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecount)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Efound)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Efound_item)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Eis_unique)) - ((CHARACTER *) &p));
    (cd->f21) [4]   = (INTEGER) (((CHARACTER *) &(p.En_iter)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 5) * sizeof (char *));
    (cd->f22) [0]   = (char *) "count";
    (cd->f22) [1]   = (char *) "found";
    (cd->f22) [2]   = (char *) "found_item";
    (cd->f22) [3]   = (char *) "is_unique";
    (cd->f22) [4]   = (char *) "n_iter";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Efound_item)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 3) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_collection;
    (cd->f8) [1]    = &ECD_twoway_traversable;
    (cd->f8) [2]    = (ECDESC *) 0;
    cd->f9          = &EECD_sorted_collection;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

