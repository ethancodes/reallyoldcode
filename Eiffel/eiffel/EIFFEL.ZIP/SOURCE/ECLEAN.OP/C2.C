/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H2.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_character_ref;
extern  ECDESC        EECD_character_ref;
ECDESC                ECD_character;
ECDESC                EECD_character;
/*------------------------------------------------------------------*/

extern  CHARACTER     RTC7_to_lower ();
extern  INTEGER       RTC7_to_integer ();
extern  CHARACTER     RTC7_to_upper ();
/*------------------------------------------------------------------*/

BOOLEAN               E67977218 ();
INTEGER               E69378050 ();
INTEGER               E69476354 ();
/*------------------------------------------------------------------*/

BOOLEAN       E67977218 (_cf, _a0, _a1)

RTF           *_cf;
CHARACTER     _a0;
CHARACTER     _a1;

{
#ifndef EDCR67977218
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

CHARACTER     E68812802 (_cf, _a0)

RTF           *_cf;
CHARACTER     _a0;

{
#ifndef EDCR68812802
    CHARACTER  _res;


    ++RTMM_stop;
    _res = RTC7_to_lower (_a0);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69378050 (_cf, _a0, _a1)

RTF           *_cf;
CHARACTER     _a0;
CHARACTER     _a1;

{
#ifndef EDCR69378050
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = E69476354 (&_mf, _a0) - E69476354 (&_mf, _a1);
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69476354 (_cf, _a0)

RTF           *_cf;
CHARACTER     _a0;

{
#ifndef EDCR69476354
    INTEGER  _res;


    ++RTMM_stop;
    _res = RTC7_to_integer (_a0);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

CHARACTER     E69484546 (_cf, _a0)

RTF           *_cf;
CHARACTER     _a0;

{
#ifndef EDCR69484546
    CHARACTER  _res;


    ++RTMM_stop;
    _res = RTC7_to_upper (_a0);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void    ECR2 (obj)

ECA_character  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST2 (d)

INTEGER d;

{
    ECA_character  p;
    ECDESC  *cd = &ECD_character, *ecd = &EECD_character;

    cd->f1          = (INTEGER) 2;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_character);
    cd->f12         = "character";
    cd->f6          = false;
    cd->f13         = ECR2;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " c";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eitem)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "item";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_character_ref;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_character;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

