/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H29.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
ECDESC                ECD_numeric;
ECDESC                EECD_numeric;
/*------------------------------------------------------------------*/

extern  OBJREF        (*FE69402653()) ();
extern  OBJREF        (*FE67903517()) ();
extern  OBJREF        (*FE69394461()) ();
extern  OBJREF        (*FE67887133()) ();
/*------------------------------------------------------------------*/

OBJREF                E67182621 ();
OBJREF                E67190813 ();
OBJREF                E68034589 ();
/*------------------------------------------------------------------*/

OBJREF        E67182621 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67182621
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = _a0;
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67190813 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67190813
    OBJREF              _o [4];
    RTF                 _mf;
    OBJREF (*_fpt0 )();

    _o [0] = _o [1] = _o [2] = _o [3] = VOIDREF;

    RTF_sl(4, _o, _cf);
    _fpt0 = FE69402653(_a0);
    _o [0] = ((_o [1] = (*_fpt0)(&_mf, _a0)) , (*FE67903517(_o [1])) (&_mf, _o [1], _a0));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68034589 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR68034589
    register INTEGER    _i0;
    OBJREF              _o [4];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = _o [1] = _o [2] = _o [3] = VOIDREF;

    RTF_sl(4, _o, _cf);
    _o [1] = (*FE69394461(_a0))(&_mf, _a0);
    _o [2] = _a0;
    _i0 = _a1;
    while (_i0 != ((INTEGER) 0))
    {
       if (_i0 % ((INTEGER) 2) == ((INTEGER) 1))
       {
          _o [1] = (*FE67887133(_o [1]))(&_mf, _o [1], _o [2]);
       }
       _i0 /= ((INTEGER) 2);
       _o [2] = (*FE67887133(_o [2]))(&_mf, _o [2], _o [2]);
    }
    _o [0] = _o [1];
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void    ECR29 (obj)

ECA_numeric  *obj;

{
}
/*------------------------------------------------------------------*/

void    ST29 (d)

INTEGER d;

{
    ECA_numeric  p;
    ECDESC  *cd = &ECD_numeric, *ecd = &EECD_numeric;

    cd->f1          = (INTEGER) 29;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_numeric);
    cd->f12         = "numeric";
    cd->f6          = false;
    cd->f13         = ECR29;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ";
    (cd->f21)       = (INTEGER *) 0;
    (cd->f22)       = (char **) 0;
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_numeric;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

