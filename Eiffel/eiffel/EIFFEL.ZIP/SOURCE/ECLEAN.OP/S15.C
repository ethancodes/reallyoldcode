/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "H2.h"
#include             "H15.h"
/*------------------------------------------------------------------*/

extern  INTEGER       E69476354 ();
extern  INTEGER       E69476367 ();
/*------------------------------------------------------------------*/

EPI        FE69476367 (Current)

OBJREF    Current;

{
    register int cnr;
    static   int lcnr = -1;
    static   EPI lres;


    cnr = (int) (ECNR (Current));

    if (cnr == lcnr)
        return lres;

    if (cnr)
        lcnr = cnr;
    else
        RTC4_raise ((CHARACTER *) "character_ref.to_integer", (CHARACTER *) "", VOID_CALL_TARGET, VOIDREF);

    if (cnr == 15)
        return (lres = E69476367);

    return (lres = E69476354);
}
/*------------------------------------------------------------------*/

