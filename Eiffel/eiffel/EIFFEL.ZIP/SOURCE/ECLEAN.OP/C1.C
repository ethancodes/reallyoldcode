/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H1.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer_ref;
extern  ECDESC        EECD_integer_ref;
ECDESC                ECD_integer;
ECDESC                EECD_integer;
/*------------------------------------------------------------------*/

extern  INTEGER       RTC6_power ();
/*------------------------------------------------------------------*/

INTEGER               E67182593 ();
INTEGER               E67190785 ();
INTEGER               E67887105 ();
INTEGER               E67895297 ();
INTEGER               E67903489 ();
INTEGER               E67936257 ();
INTEGER               E67944449 ();
BOOLEAN               E67977217 ();
INTEGER               E68591617 ();
INTEGER               E69378049 ();
INTEGER               E69386241 ();
INTEGER               E69394433 ();
INTEGER               E69402625 ();
/*------------------------------------------------------------------*/

INTEGER       E67182593 (_cf, _a0)

RTF           *_cf;
INTEGER       _a0;

{
#ifndef EDCR67182593
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = _a0;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E67190785 (_cf, _a0)

RTF           *_cf;
INTEGER       _a0;

{
#ifndef EDCR67190785
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E67887105 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR67887105
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E67895297 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR67895297
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E67903489 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR67903489
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E67936257 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR67936257
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E67944449 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR67944449
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = _a0 / _a1;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E67977217 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR67977217
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E68034561 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR68034561
    INTEGER  _res;


    ++RTMM_stop;
    _res = RTC6_power (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E68591617 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR68591617
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69378049 (_cf, _a0, _a1)

RTF           *_cf;
INTEGER       _a0;
INTEGER       _a1;

{
#ifndef EDCR69378049
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = _a0 - _a1;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69386241 (_cf, _a0)

RTF           *_cf;
INTEGER       _a0;

{
#ifndef EDCR69386241
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    if (_a0 < ((INTEGER) 0))
    {
       _i0 = -_a0;
    }
    else
    {
       _i0 = _a0;
    }
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69394433 (_cf, _a0)

RTF           *_cf;
INTEGER       _a0;

{
#ifndef EDCR69394433
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = ((INTEGER) 1);
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69402625 (_cf, _a0)

RTF           *_cf;
INTEGER       _a0;

{
#ifndef EDCR69402625
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = ((INTEGER) 0);
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void    ECR1 (obj)

ECA_integer  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST1 (d)

INTEGER d;

{
    ECA_integer  p;
    ECDESC  *cd = &ECD_integer, *ecd = &EECD_integer;

    cd->f1          = (INTEGER) 1;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_integer);
    cd->f12         = "integer";
    cd->f6          = false;
    cd->f13         = ECR1;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " i";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eitem)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "item";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_integer_ref;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_integer;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

