/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H26.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_comparable;
extern  ECDESC        EECD_comparable;
extern  ECDESC        ECD_hashable;
extern  ECDESC        EECD_hashable;
extern  ECDESC        ECD_numeric;
extern  ECDESC        EECD_numeric;
ECDESC                ECD_integer_ref;
ECDESC                EECD_integer_ref;
/*------------------------------------------------------------------*/

void                  E67125274 ();
OBJREF                E67182618 ();
OBJREF                E67190810 ();
OBJREF                E67887130 ();
OBJREF                E67895322 ();
OBJREF                E67903514 ();
OBJREF                E67936282 ();
OBJREF                E67944474 ();
BOOLEAN               E67977242 ();
OBJREF                E68034586 ();
OBJREF                E68591642 ();
INTEGER               E69378074 ();
INTEGER               E69386266 ();
OBJREF                E69394458 ();
OBJREF                E69402650 ();
BOOLEAN               E69566490 ();
/*------------------------------------------------------------------*/

void          E67125274 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR67125274
/* LEAF */


    EA26(_a0)->Eitem = _a1;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67182618 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67182618
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], EA26(_a0)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67190810 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67190810
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], -EA26(_a0)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67887130 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67887130
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], EA26(_a0)->Eitem * EA26(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67895322 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67895322
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], EA26(_a0)->Eitem + EA26(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67903514 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67903514
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], EA26(_a0)->Eitem - EA26(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67936282 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67936282
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], EA26(_a0)->Eitem / EA26(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67944474 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67944474
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], EA26(_a0)->Eitem / EA26(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E67977242 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67977242
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = EA26(_a0)->Eitem < EA26(_a1)->Eitem;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68034586 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR68034586
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], RTC6_power (EA26(_a0)->Eitem, _a1));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68591642 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68591642
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], EA26(_a0)->Eitem % EA26(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69378074 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69378074
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = EA26(_a0)->Eitem - EA26(_a1)->Eitem;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69386266 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69386266
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    if (EA26(_a0)->Eitem < ((INTEGER) 0))
    {
       _i0 = -EA26(_a0)->Eitem;
    }
    else
    {
       _i0 = EA26(_a0)->Eitem;
    }
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69394458 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69394458
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], ((INTEGER) 1));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69402650 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69402650
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_integer_ref);
    E67125274 (&_mf, _o [0], ((INTEGER) 0));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E69566490 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69566490
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = EA26(_a1)->Eitem != ((INTEGER) 0);
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void    ECR26 (obj)

ECA_integer_ref  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST26 (d)

INTEGER d;

{
    ECA_integer_ref  p;
    ECDESC  *cd = &ECD_integer_ref, *ecd = &EECD_integer_ref;

    cd->f1          = (INTEGER) 26;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_integer_ref);
    cd->f12         = "integer_ref";
    cd->f6          = false;
    cd->f13         = ECR26;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " i";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eitem)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "item";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 4) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_comparable;
    (cd->f8) [1]    = &ECD_hashable;
    (cd->f8) [2]    = &ECD_numeric;
    (cd->f8) [3]    = (ECDESC *) 0;
    cd->f9          = &EECD_integer_ref;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

