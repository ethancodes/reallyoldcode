/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H73.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_character;
extern  ECDESC        EECD_character;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
ECDESC                ECD__i_es3_spec;
ECDESC                EECD__i_es3_spec;
/*------------------------------------------------------------------*/

extern  BOOLEAN       RTC0_is_equal ();
extern  void          RTC0_copy ();
extern  void          RTC0_fill_with ();
extern  void          RTC0_puts ();
extern  void          RTC0_resize ();
extern  void          RTC0_move ();
extern  void          RTC0_sv_lit ();
extern  POINTER       RTC0_gets ();
extern  void          RTC0_put ();
extern  void          RTC0_item ();
extern  void          RTC0_clear ();
extern  void          RTC0_resize_and_copy ();
extern  POINTER       RTC0_at ();
extern  BOOLEAN       RTC0_all_cleared ();
/*------------------------------------------------------------------*/

void                  E67125321 ();
void                  E69877833 ();
INTEGER               E69001289 ();
void                  E70279241 ();
void                  E69836873 ();
void                  E70271049 ();
/*------------------------------------------------------------------*/

void          E67125321 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR67125321
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69877833 (&_mf, _a0, _a1);
    EA73(_a0)->Ecount = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_make (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E67125321 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

BOOLEAN       E68821065 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68821065
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC0_is_equal (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       _i_es3_spec_is_equal (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    return E68821065 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

INTEGER       E69001289 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69001289
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    E70279241 (&_mf, _a0, _a1);
    _i0 = EA73(_a0)->Eexchg;
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       _i_es3_spec_item (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    return E69001289 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69632073 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69632073


    ++RTMM_stop;
    RTC0_copy (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_copy (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    E69632073 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69673033 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
#ifndef EDCR69673033


    ++RTMM_stop;
    RTC0_fill_with (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_fill_with (_a0, _a1, _a2)

OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69673033 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69795913 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69795913


    ++RTMM_stop;
    RTC0_puts (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_puts (_a0, _a1, _a2)

OBJREF        _a0;
POINTER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69795913 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69836873 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69836873
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA73(_a0)->Eexchg = _a1;
    E70271049 (&_mf, _a0, _a2);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_put (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69836873 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69877833 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69877833


    ++RTMM_stop;
    RTC0_resize (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_resize (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E69877833 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69918793 (_cf, _a0, _a1, _a2, _a3)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;
INTEGER       _a3;

{
#ifndef EDCR69918793


    ++RTMM_stop;
    RTC0_move (_a0, _a1, _a2, _a3);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_move (_a0, _a1, _a2, _a3)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;
INTEGER       _a3;

{
    RTF    _df;

    E69918793 (&_df,  _a0,  _a1,  _a2,  _a3);
}
/*------------------------------------------------------------------*/

void          E69984329 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69984329


    ++RTMM_stop;
    RTC0_sv_lit (_a0);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_sv_lit (_a0)

OBJREF        _a0;

{
    RTF    _df;

    E69984329 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

POINTER       E70099017 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70099017
    POINTER  _res;


    ++RTMM_stop;
    _res = RTC0_gets (_a0, _a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       _i_es3_spec_gets (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    return E70099017 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E70271049 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70271049


    ++RTMM_stop;
    RTC0_put (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_rt_put (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E70271049 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E70279241 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70279241


    ++RTMM_stop;
    RTC0_item (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_rt_item (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E70279241 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E70500425 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70500425


    ++RTMM_stop;
    RTC0_clear (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_clear (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E70500425 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E70541385 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70541385


    ++RTMM_stop;
    RTC0_resize_and_copy (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _i_es3_spec_resize_and_copy (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E70541385 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

POINTER       E70631497 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70631497
    POINTER  _res;


    ++RTMM_stop;
    _res = RTC0_at (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       _i_es3_spec_at (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    return E70631497 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

BOOLEAN       E70656073 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70656073
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC0_all_cleared (_a0);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       _i_es3_spec_all_cleared (_a0)

OBJREF        _a0;

{
    RTF    _df;

    return E70656073 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void    ECR73 (obj)

ECA__i_es3_spec  *obj;

{

    obj->Estore = (POINTER) 0;
}
/*------------------------------------------------------------------*/

void    ST73 (d)

INTEGER d;

{
    ECA__i_es3_spec  p;
    ECDESC  *cd = &ECD__i_es3_spec, *ecd = &EECD__i_es3_spec;

    cd->f1          = (INTEGER) 73;
    cd->f2          = d;
    cd->f3          = sizeof (ECA__i_es3_spec);
    cd->f12         = "_i_es3_spec";
    cd->f6          = false;
    cd->f13         = ECR73;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " iibp";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 4) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecount)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Eexchg)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Elit)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Estore)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 4) * sizeof (char *));
    (cd->f22) [0]   = (char *) "count";
    (cd->f22) [1]   = (char *) "exchg";
    (cd->f22) [2]   = (char *) "lit";
    (cd->f22) [3]   = (char *) "store";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD__i_es3_spec;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

