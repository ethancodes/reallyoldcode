/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H33.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_real;
extern  ECDESC        EECD_real;
extern  ECDESC        ECD_comparable;
extern  ECDESC        EECD_comparable;
extern  ECDESC        ECD_numeric;
extern  ECDESC        EECD_numeric;
ECDESC                ECD_real_ref;
ECDESC                EECD_real_ref;
/*------------------------------------------------------------------*/

extern  INTEGER       E69378052 ();
/*------------------------------------------------------------------*/

void                  E67125281 ();
OBJREF                E67182625 ();
OBJREF                E67190817 ();
OBJREF                E67887137 ();
OBJREF                E67895329 ();
OBJREF                E67903521 ();
OBJREF                E67936289 ();
BOOLEAN               E67977249 ();
OBJREF                E68034593 ();
INTEGER               E69378081 ();
OBJREF                E69394465 ();
OBJREF                E69402657 ();
BOOLEAN               E69566497 ();
/*------------------------------------------------------------------*/

void          E67125281 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
REAL          _a1;

{
#ifndef EDCR67125281
/* LEAF */


    EA33(_a0)->Eitem = _a1;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67182625 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67182625
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], EA33(_a0)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67190817 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67190817
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], -EA33(_a0)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67887137 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67887137
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], EA33(_a0)->Eitem * EA33(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67895329 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67895329
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], EA33(_a0)->Eitem + EA33(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67903521 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67903521
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], EA33(_a0)->Eitem - EA33(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67936289 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67936289
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], EA33(_a0)->Eitem / EA33(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E67977249 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67977249
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = EA33(_a0)->Eitem < EA33(_a1)->Eitem;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68034593 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR68034593
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], RTC9_power (EA33(_a0)->Eitem, _a1));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69378081 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69378081
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = E69378052 (&_mf, EA33(_a0)->Eitem, EA33(_a1)->Eitem);
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69394465 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69394465
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], ((REAL) 1.0));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69402657 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69402657
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_real_ref);
    E67125281 (&_mf, _o [0], ((REAL) 0.0));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E69566497 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69566497
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = EA33(_a1)->Eitem != ((REAL) 0.0);
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void    ECR33 (obj)

ECA_real_ref  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST33 (d)

INTEGER d;

{
    ECA_real_ref  p;
    ECDESC  *cd = &ECD_real_ref, *ecd = &EECD_real_ref;

    cd->f1          = (INTEGER) 33;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_real_ref);
    cd->f12         = "real_ref";
    cd->f6          = false;
    cd->f13         = ECR33;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " r";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eitem)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "item";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 3) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_comparable;
    (cd->f8) [1]    = &ECD_numeric;
    (cd->f8) [2]    = (ECDESC *) 0;
    cd->f9          = &EECD_real_ref;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

