/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H72.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_character;
extern  ECDESC        EECD_character;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
ECDESC                ECD__c_es3_spec;
ECDESC                EECD__c_es3_spec;
/*------------------------------------------------------------------*/

extern  BOOLEAN       RTC0_is_equal ();
extern  void          RTC0_copy ();
extern  void          RTC0_fill_with ();
extern  void          RTC0_puts ();
extern  void          RTC0_resize ();
extern  void          RTC0_move ();
extern  void          RTC0_sv_lit ();
extern  POINTER       RTC0_gets ();
extern  void          RTC0_put ();
extern  void          RTC0_item ();
extern  void          RTC0_clear ();
extern  void          RTC0_resize_and_copy ();
extern  POINTER       RTC0_at ();
extern  BOOLEAN       RTC0_all_cleared ();
/*------------------------------------------------------------------*/

void                  E67125320 ();
void                  E69877832 ();
CHARACTER             E69001288 ();
void                  E70279240 ();
void                  E69836872 ();
void                  E70271048 ();
/*------------------------------------------------------------------*/

void          E67125320 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR67125320
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69877832 (&_mf, _a0, _a1);
    EA72(_a0)->Ecount = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_make (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E67125320 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

BOOLEAN       E68821064 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68821064
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC0_is_equal (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       _c_es3_spec_is_equal (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    return E68821064 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

CHARACTER     E69001288 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69001288
    CHARACTER           _c0;
    RTF                 _mf;

    _c0 = '\0';

    RTF_sl(0, (OBJREF *) 0, _cf);
    E70279240 (&_mf, _a0, _a1);
    _c0 = EA72(_a0)->Eexchg;
    RTF_return;
    return _c0;
#endif
}
/*------------------------------------------------------------------*/

CHARACTER     _c_es3_spec_item (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    return E69001288 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69632072 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69632072


    ++RTMM_stop;
    RTC0_copy (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_copy (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    E69632072 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69673032 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
#ifndef EDCR69673032


    ++RTMM_stop;
    RTC0_fill_with (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_fill_with (_a0, _a1, _a2)

OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69673032 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69795912 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69795912


    ++RTMM_stop;
    RTC0_puts (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_puts (_a0, _a1, _a2)

OBJREF        _a0;
POINTER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69795912 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69836872 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
#ifndef EDCR69836872
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA72(_a0)->Eexchg = _a1;
    E70271048 (&_mf, _a0, _a2);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_put (_a0, _a1, _a2)

OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69836872 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69877832 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69877832


    ++RTMM_stop;
    RTC0_resize (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_resize (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E69877832 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69918792 (_cf, _a0, _a1, _a2, _a3)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;
INTEGER       _a3;

{
#ifndef EDCR69918792


    ++RTMM_stop;
    RTC0_move (_a0, _a1, _a2, _a3);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_move (_a0, _a1, _a2, _a3)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;
INTEGER       _a3;

{
    RTF    _df;

    E69918792 (&_df,  _a0,  _a1,  _a2,  _a3);
}
/*------------------------------------------------------------------*/

void          E69984328 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69984328


    ++RTMM_stop;
    RTC0_sv_lit (_a0);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_sv_lit (_a0)

OBJREF        _a0;

{
    RTF    _df;

    E69984328 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

POINTER       E70099016 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70099016
    POINTER  _res;


    ++RTMM_stop;
    _res = RTC0_gets (_a0, _a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       _c_es3_spec_gets (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    return E70099016 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E70271048 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70271048


    ++RTMM_stop;
    RTC0_put (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_rt_put (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E70271048 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E70279240 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70279240


    ++RTMM_stop;
    RTC0_item (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_rt_item (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E70279240 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E70500424 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70500424


    ++RTMM_stop;
    RTC0_clear (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_clear (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E70500424 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E70541384 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70541384


    ++RTMM_stop;
    RTC0_resize_and_copy (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          _c_es3_spec_resize_and_copy (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E70541384 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

POINTER       E70631496 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70631496
    POINTER  _res;


    ++RTMM_stop;
    _res = RTC0_at (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       _c_es3_spec_at (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    return E70631496 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

BOOLEAN       E70656072 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70656072
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC0_all_cleared (_a0);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       _c_es3_spec_all_cleared (_a0)

OBJREF        _a0;

{
    RTF    _df;

    return E70656072 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void    ECR72 (obj)

ECA__c_es3_spec  *obj;

{

    obj->Estore = (POINTER) 0;
}
/*------------------------------------------------------------------*/

void    ST72 (d)

INTEGER d;

{
    ECA__c_es3_spec  p;
    ECDESC  *cd = &ECD__c_es3_spec, *ecd = &EECD__c_es3_spec;

    cd->f1          = (INTEGER) 72;
    cd->f2          = d;
    cd->f3          = sizeof (ECA__c_es3_spec);
    cd->f12         = "_c_es3_spec";
    cd->f6          = false;
    cd->f13         = ECR72;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " icbp";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 4) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecount)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Eexchg)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Elit)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Estore)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 4) * sizeof (char *));
    (cd->f22) [0]   = (char *) "count";
    (cd->f22) [1]   = (char *) "exchg";
    (cd->f22) [2]   = (char *) "lit";
    (cd->f22) [3]   = (char *) "store";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD__c_es3_spec;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

