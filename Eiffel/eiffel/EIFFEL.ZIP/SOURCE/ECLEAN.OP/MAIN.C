extern  void    eiffel_start ();
extern  int     eiffel_run ();
/*------------------------------------------------------------------*/

main (argc, argv, envp)

int     argc;
char    **argv;
char    **envp;

{
    int     result;

    eiffel_start (argc, argv, envp);
    result = eiffel_run ();
    exit (result);
}
/*------------------------------------------------------------------*/

