/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H32.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_general;
extern  ECDESC        EECD_general;
ECDESC                ECD_platform;
ECDESC                EECD_platform;
/*------------------------------------------------------------------*/

void    ECR32 (obj)

ECA_platform  *obj;

{
}
/*------------------------------------------------------------------*/

void    ST32 (d)

INTEGER d;

{
    ECA_platform  p;
    ECDESC  *cd = &ECD_platform, *ecd = &EECD_platform;

    cd->f1          = (INTEGER) 32;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_platform);
    cd->f12         = "platform";
    cd->f6          = false;
    cd->f13         = ECR32;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ";
    (cd->f21)       = (INTEGER *) 0;
    (cd->f22)       = (char **) 0;
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_general;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_platform;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

