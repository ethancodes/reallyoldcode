/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "H1.h"
#include             "H2.h"
#include             "H4.h"
#include             "H15.h"
#include             "H23.h"
#include             "H26.h"
#include             "H33.h"
#include             "H34.h"
/*------------------------------------------------------------------*/

extern  BOOLEAN       E67977217 ();
extern  BOOLEAN       E67977218 ();
extern  BOOLEAN       E67977220 ();
extern  BOOLEAN       E67977231 ();
extern  BOOLEAN       E67977239 ();
extern  BOOLEAN       E67977242 ();
extern  BOOLEAN       E67977249 ();
extern  BOOLEAN       E67977250 ();
extern  INTEGER       E69378049 ();
extern  INTEGER       E69378050 ();
extern  INTEGER       E69378052 ();
extern  INTEGER       E69378063 ();
extern  INTEGER       E69378064 ();
extern  INTEGER       E69378074 ();
extern  INTEGER       E69378081 ();
extern  INTEGER       E69378082 ();
/*------------------------------------------------------------------*/

EPB        FE67977232 (Current)

OBJREF    Current;

{
    register int cnr;
    static   int lcnr = -1;
    static   EPB lres;


    cnr = (int) (ECNR (Current));

    if (cnr == lcnr)
        return lres;

    if (cnr)
        lcnr = cnr;
    else
        RTC4_raise ((CHARACTER *) "comparable.<", (CHARACTER *) "", VOID_CALL_TARGET, VOIDREF);

    if ((cnr < 2) || (cnr > 34))
        return (lres = E67977217);
    if (cnr == 2)
        return (lres = E67977218);
    else
    if (cnr == 4)
        return (lres = E67977220);
    else
    if (cnr == 15)
        return (lres = E67977231);
    else
    if (cnr == 23)
        return (lres = E67977239);
    else
    if (cnr == 26)
        return (lres = E67977242);
    else
    if (cnr == 33)
        return (lres = E67977249);
    else
    if (cnr == 34)
        return (lres = E67977250);

    return (lres = E67977217);
}
/*------------------------------------------------------------------*/

EPI        FE69378064 (Current)

OBJREF    Current;

{
    register int cnr;
    static   int lcnr = -1;
    static   EPI lres;


    cnr = (int) (ECNR (Current));

    if (cnr == lcnr)
        return lres;

    if (cnr)
        lcnr = cnr;
    else
        RTC4_raise ((CHARACTER *) "comparable.compare", (CHARACTER *) "", VOID_CALL_TARGET, VOIDREF);

    if ((cnr < 2) || (cnr > 34))
        return (lres = E69378049);
    if (cnr == 2)
        return (lres = E69378050);
    else
    if (cnr == 4)
        return (lres = E69378052);
    else
    if (cnr == 15)
        return (lres = E69378063);
    else
    if (cnr == 23)
        return (lres = E69378064);
    else
    if (cnr == 26)
        return (lres = E69378074);
    else
    if (cnr == 33)
        return (lres = E69378081);
    else
    if (cnr == 34)
        return (lres = E69378082);

    return (lres = E69378049);
}
/*------------------------------------------------------------------*/

