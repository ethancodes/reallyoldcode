/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H13.h"
#include             "H72.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_string;
extern  ECDESC        EECD_string;
extern  ECDESC        ECD__c_es3_spec;
extern  ECDESC        EECD__c_es3_spec;
ECDESC                ECD_bit_n;
ECDESC                EECD_bit_n;
/*------------------------------------------------------------------*/

extern  BOOLEAN       E68821064 ();
extern  void          E67125320 ();
extern  void          E69632072 ();
extern  OBJREF        RTC3_and ();
extern  OBJREF        RTC3_or ();
extern  OBJREF        RTC3_xor ();
extern  OBJREF        RTC3_implies ();
extern  OBJREF        RTC3_not ();
extern  void          RTC3_put ();
extern  BOOLEAN       RTC3_item ();
extern  OBJREF        RTC3_string ();
extern  POINTER       E70066210 ();
extern  void          RTC3_fill ();
/*------------------------------------------------------------------*/

OBJREF                E67649549 ();
OBJREF                E70246413 ();
OBJREF                E68059149 ();
OBJREF                E70213645 ();
OBJREF                E68263949 ();
OBJREF                E70238221 ();
OBJREF                E68395021 ();
OBJREF                E70221837 ();
OBJREF                E68567053 ();
OBJREF                E70230029 ();
BOOLEAN               E68821005 ();
BOOLEAN               E69001229 ();
BOOLEAN               E70279181 ();
void                  E69632013 ();
void                  E69836813 ();
void                  E70270989 ();
OBJREF                E70287373 ();
OBJREF                E70295565 ();
void                  E70311949 ();
void                  E70344717 ();
/*------------------------------------------------------------------*/

OBJREF        E67649549 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67649549
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC3_make ((INTEGER) 0);
    _o [0] = RTC11_assign (&EECD_bit_n, ((E70246413 (&_mf, _a0, EA13(_a0)->Especial, EA13(_a0)->Ecount))));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68059149 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68059149
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC3_make ((INTEGER) 0);
    _o [0] = RTC11_assign (&EECD_bit_n, ((E70213645 (&_mf, _a0, EA13(_a0)->Especial, EA13(_a0)->Ecount, EA13(_a1)->Especial, EA13(_a1)->Ecount))));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68263949 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68263949
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC3_make ((INTEGER) 0);
    _o [0] = RTC11_assign (&EECD_bit_n, ((E70238221 (&_mf, _a0, EA13(_a0)->Especial, EA13(_a0)->Ecount, EA13(_a1)->Especial, EA13(_a1)->Ecount))));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68395021 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68395021
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC3_make ((INTEGER) 0);
    _o [0] = RTC11_assign (&EECD_bit_n, ((E70221837 (&_mf, _a0, EA13(_a0)->Especial, EA13(_a0)->Ecount, EA13(_a1)->Especial, EA13(_a1)->Ecount))));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68567053 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68567053
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC3_make ((INTEGER) 0);
    _o [0] = RTC11_assign (&EECD_bit_n, ((E70230029 (&_mf, _a0, EA13(_a0)->Especial, EA13(_a0)->Ecount, EA13(_a1)->Especial, EA13(_a1)->Ecount))));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68821005 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68821005
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = EA13(_a0)->Ecount == EA13(_a1)->Ecount && E68821064 (&_mf, EA13(_a0)->Especial, EA13(_a1)->Especial);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E69001229 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69001229
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E70279181 (&_mf, _a0, EA13(_a0)->Especial, _a1);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E69632013 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (EA13(_a0)->Especial == (VOIDREF))
    {
       EA13(_a0)->Especial = RTMM_create (&ECD__c_es3_spec);
       E67125320 (&_mf, EA13(_a0)->Especial, ((INTEGER) 0));
    }
    E69632072 (&_mf, EA13(_a0)->Especial, EA13(_a1)->Especial);
    EA13(_a0)->Ecount = EA13(_a1)->Ecount;
    RTF_return;
}
/*------------------------------------------------------------------*/

void          bit_n_copy (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    E69632013 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69836813 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
BOOLEAN       _a1;
INTEGER       _a2;

{
#ifndef EDCR69836813
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E70270989 (&_mf, _a0, EA13(_a0)->Especial, _a1, _a2);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70213645 (_cf, _a0, _a1, _a2, _a3, _a4)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;
OBJREF        _a3;
INTEGER       _a4;

{
#ifndef EDCR70213645
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC3_and (_a1, _a2, _a3, _a4);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70221837 (_cf, _a0, _a1, _a2, _a3, _a4)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;
OBJREF        _a3;
INTEGER       _a4;

{
#ifndef EDCR70221837
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC3_or (_a1, _a2, _a3, _a4);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70230029 (_cf, _a0, _a1, _a2, _a3, _a4)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;
OBJREF        _a3;
INTEGER       _a4;

{
#ifndef EDCR70230029
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC3_xor (_a1, _a2, _a3, _a4);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70238221 (_cf, _a0, _a1, _a2, _a3, _a4)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;
OBJREF        _a3;
INTEGER       _a4;

{
#ifndef EDCR70238221
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC3_implies (_a1, _a2, _a3, _a4);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70246413 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;

{
#ifndef EDCR70246413
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC3_not (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E70270989 (_cf, _a0, _a1, _a2, _a3)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
BOOLEAN       _a2;
INTEGER       _a3;

{
#ifndef EDCR70270989


    ++RTMM_stop;
    RTC3_put (_a1, _a2, _a3);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70279181 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;

{
#ifndef EDCR70279181
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC3_item (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70287373 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70287373
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = E70295565 (&_mf, _a0, EA13(_a0)->Especial, EA13(_a0)->Ecount);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70295565 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;

{
#ifndef EDCR70295565
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC3_string (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E70311949 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70311949
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    E70344717 (&_mf, _a0, EA13(_a0)->Especial, E70066210 (&_mf, _a1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E70344717 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
POINTER       _a2;

{
#ifndef EDCR70344717


    ++RTMM_stop;
    RTC3_fill (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void    ECR13 (obj)

ECA_bit_n  *obj;

{

    obj->Especial = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST13 (d)

INTEGER d;

{
    ECA_bit_n  p;
    ECDESC  *cd = &ECD_bit_n, *ecd = &EECD_bit_n;

    cd->f1          = (INTEGER) 13;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_bit_n);
    cd->f12         = "bit_n";
    cd->f6          = false;
    cd->f13         = ECR13;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " io";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecount)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Especial)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 2) * sizeof (char *));
    (cd->f22) [0]   = (char *) "count";
    (cd->f22) [1]   = (char *) "special";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Especial)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_bit_n;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

