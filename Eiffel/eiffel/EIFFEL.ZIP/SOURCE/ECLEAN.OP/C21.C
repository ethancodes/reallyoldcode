/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H21.h"
#include             "H51.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_fsys_dat;
extern  ECDESC        EECD_fsys_dat;
extern  ECDESC        ECD_string;
extern  ECDESC        EECD_string;
extern  ECDESC        ECD_sorted_list;
extern  ECDESC        EECD_sorted_list;
ECDESC                ECD_file_system;
ECDESC                EECD_file_system;
/*------------------------------------------------------------------*/

extern  BOOLEAN       *VE68993067 ();
/*------------------------------------------------------------------*/

extern  POINTER       E70066210 ();
extern  OBJREF        RTC2_c_create ();
extern  POINTER       RTFS_current_cluster ();
extern  BOOLEAN       E70025250 ();
extern  void          RTFS_add_cluster ();
extern  void          RTFS_remove_cluster ();
extern  void          RTFS_change_cluster ();
extern  BOOLEAN       RTFS_cluster_exists ();
extern  void          E67125271 ();
extern  REAL          RTFS_cluster_time ();
extern  POINTER       RTFS_cluster_perm ();
extern  POINTER       RTFS_my_cluster_perm ();
extern  BOOLEAN       RTFS_has_listperm ();
extern  BOOLEAN       RTFS_has_modperm ();
extern  OBJREF        E68796440 ();
extern  void          E67125299 ();
extern  void          E71630899 ();
extern  void          RTFS_change_cluster_perm ();
extern  OBJREF        E68943923 ();
extern  OBJREF        E69001267 ();
extern  void          E69099563 ();
extern  void          RTFS_add_file ();
extern  void          RTFS_remove_file ();
extern  void          RTFS_rename_file ();
extern  void          RTFS_copy_file ();
extern  BOOLEAN       RTFS_same ();
extern  POINTER       RTFM_identify ();
extern  BOOLEAN       RTFS_file_exists ();
extern  REAL          RTFS_file_time ();
extern  POINTER       RTFS_file_perm ();
extern  POINTER       RTFS_my_file_perm ();
extern  BOOLEAN       RTFS_has_readperm ();
extern  BOOLEAN       RTFS_has_writeperm ();
extern  BOOLEAN       RTFS_has_execperm ();
extern  INTEGER       RTFS_file_count ();
extern  void          RTFS_change_file_perm ();
extern  INTEGER       RTFM_open ();
extern  POINTER       RTFS_temp_file ();
extern  POINTER       RTFS_path_suffix ();
extern  POINTER       RTFS_path_prefix ();
extern  POINTER       RTFS_concat_paths ();
extern  POINTER       RTFS_absolute_path ();
extern  BOOLEAN       RTFS_same_path ();
extern  BOOLEAN       RTFM_in_use ();
extern  void          RTFS_open_cluster ();
extern  POINTER       RTFS_read_cluster ();
extern  void          RTFS_close_cluster ();
extern  void          RTFS_stat_start ();
extern  void          RTFS_stat_end ();
/*------------------------------------------------------------------*/

void                  E67125269 ();
BOOLEAN               E68624405 ();
BOOLEAN               E71008277 ();
OBJREF                E68976661 ();
POINTER               E70787093 ();
OBJREF                E70778901 ();
OBJREF                E68984853 ();
OBJREF                E71065621 ();
void                  E69058581 ();
void                  E71106581 ();
OBJREF                E69107733 ();
BOOLEAN               E69115925 ();
BOOLEAN               E71016469 ();
void                  E69124117 ();
void                  E70901781 ();
OBJREF                E69189653 ();
POINTER               E71573525 ();
BOOLEAN               E69230613 ();
BOOLEAN               E70918165 ();
void                  E69296149 ();
void                  E70885397 ();
OBJREF                E70795285 ();
void                  E70803477 ();
void                  E70860821 ();
OBJREF                E70852629 ();
POINTER               E71532565 ();
INTEGER               E70869013 ();
OBJREF                E71024661 ();
INTEGER               E70877205 ();
OBJREF                E70926357 ();
OBJREF                E70950933 ();
POINTER               E71524373 ();
REAL                  E70959125 ();
REAL                  E70967317 ();
OBJREF                E70975509 ();
POINTER               E70983701 ();
OBJREF                E70991893 ();
POINTER               E71000085 ();
void                  E71639061 ();
POINTER               E71647253 ();
void                  E71655445 ();
void                  E71032853 ();
void                  E71057429 ();
OBJREF                E71352341 ();
void                  E71073813 ();
void                  E71098389 ();
BOOLEAN               E71090197 ();
BOOLEAN               E71598101 ();
void                  E71114773 ();
void                  E71172117 ();
BOOLEAN               E71155733 ();
BOOLEAN               E71344149 ();
void                  E71180309 ();
void                  E71237653 ();
BOOLEAN               E71221269 ();
BOOLEAN               E71417877 ();
BOOLEAN               E71245845 ();
BOOLEAN               E71303189 ();
BOOLEAN               E71294997 ();
BOOLEAN               E71409685 ();
OBJREF                E71311381 ();
POINTER               E71335957 ();
REAL                  E71360533 ();
REAL                  E71368725 ();
OBJREF                E71376917 ();
POINTER               E71385109 ();
OBJREF                E71393301 ();
POINTER               E71401493 ();
BOOLEAN               E71426069 ();
BOOLEAN               E71434261 ();
INTEGER               E71442453 ();
INTEGER               E71450645 ();
void                  E71458837 ();
void                  E71467029 ();
INTEGER               E71475221 ();
INTEGER               E71491605 ();
OBJREF                E71499797 ();
POINTER               E71507989 ();
OBJREF                E71540757 ();
POINTER               E71565333 ();
BOOLEAN               E71581717 ();
BOOLEAN               E71589909 ();
/*------------------------------------------------------------------*/

void          E67125269 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67125269
/* LEAF */


#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68624405 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68624405
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = E71008277 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68976661 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68976661
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E70787093 (&_mf, _a0));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68984853 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68984853
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = E71065621 (&_mf, _a0, _a1, true);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E69058581 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69058581
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    E71106581 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69107733 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69107733
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = E71065621 (&_mf, _a0, _a1, false);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E69115925 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69115925
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = E71016469 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E69124117 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69124117
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    E70901781 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69189653 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69189653
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71573525 (&_mf, _a0, E70066210 (&_mf, _a1)));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E69230613 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69230613
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = E70918165 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E69296149 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69296149
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    E70885397 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70778901 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR70778901
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC2_c_create (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       E70787093 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70787093
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_current_cluster ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70795285 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70795285
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = ELS8461;
    if (!E69230613 (&_mf, _a0, _o [0]))
    {
       _o [0] = VOIDREF;
    }
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E70803477 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR70803477
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    E70860821 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70852629 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70852629
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71532565 (&_mf, _a0, E70066210 (&_mf, _a1)));
    if (E70025250 (&_mf, _o [0]))
    {
       _o [0] = ELS8378;
    }
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E70860821 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR70860821


    ++RTMM_stop;
    RTFS_add_cluster (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E70869013 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70869013
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = EA51(E71024661 (&_mf, _a0, _a1, true))->Ecount;
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E70877205 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70877205
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = EA51(E71024661 (&_mf, _a0, _a1, false))->Ecount;
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void          E70885397 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR70885397


    ++RTMM_stop;
    RTFS_remove_cluster (_a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E70901781 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR70901781


    ++RTMM_stop;
    RTFS_change_cluster (_a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70918165 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR70918165
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_cluster_exists (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70926357 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70926357
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [2] = E70950933 (&_mf, _a0, _a1);
    _o [1] = E69189653 (&_mf, _a0, _a1);
    _o [0] = RTMM_create (&ECD_fsys_dat);
    E67125271 (&_mf, _o [0], _o [2], _o [1], _a0, false);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70950933 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70950933
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71524373 (&_mf, _a0, E70066210 (&_mf, _a1)));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

REAL          E70959125 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70959125
    REAL                _r0;
    OBJREF              _o [1];
    RTF                 _mf;

    _r0 = 0.0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _r0 = E70967317 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _r0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E70967317 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR70967317
    REAL  _res;


    ++RTMM_stop;
    _res = RTFS_cluster_time (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70975509 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70975509
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E70983701 (&_mf, _a0, E70066210 (&_mf, _a1)));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

POINTER       E70983701 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR70983701
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_cluster_perm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70991893 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR70991893
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71000085 (&_mf, _a0, E70066210 (&_mf, _a1)));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71000085 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71000085
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_my_cluster_perm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71008277 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71008277
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_has_listperm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71016469 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71016469
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_has_modperm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E71024661 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
BOOLEAN       _a2;

{
#ifndef EDCR71024661
    OBJREF              _o [4];
    int                 *_env;
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = _o [3] = VOIDREF;

    RTF_sl(4, _o, _cf);
 
    RTsjp ((char *) (&(_o [0])));
    RTsjp ((char *) (&(_o [1])));
    RTsjp ((char *) (&(_o [2])));
    RTsjp ((char *) (&(_o [3])));
 
start :
    _env = RTC4_push ();
    RTF_sg;
    if (setjmp (_env))
        goto rescue;

    _o [2] = E68796440 (&_mf, _a0, _o [3] = E68976661 (&_mf, _a0));
    E69124117 (&_mf, _a0, _a1);
    _o [0] = RTMM_create (&ECD_sorted_list);
    E67125299 (&_mf, _o [0], true);
    E71639061 (&_mf, _a0, ((POINTER) ELSP8378), _a2);
    _o [1] = E70778901 (&_mf, _a0, E71647253 (&_mf, _a0));
    while (_o [1] != (VOIDREF))
    {
       E71630899 (&_mf, _o [0], _o [1]);
       _o [1] = E70778901 (&_mf, _a0, E71647253 (&_mf, _a0));
    }
    E71655445 (&_mf, _a0);
    E69124117 (&_mf, _a0, _o [2]);
    RTF_return;
    RTC4_pop ();
    return _o [0];

rescue:
    RTC4_pop ();
    RTF_restore;
    E69124117 (&_mf, _a0, _o [2]);
    RTF_return;
    RTC4_fail ();
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E71032853 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR71032853
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    E71057429 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E71057429 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR71057429


    ++RTMM_stop;
    RTFS_change_cluster_perm (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E71065621 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
BOOLEAN       _a2;

{
#ifndef EDCR71065621
    OBJREF              _o [7];
    int                 *_env;
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = _o [3] = _o [4] = _o [5] = VOIDREF;
    _o [6] = VOIDREF;

    RTF_sl(7, _o, _cf);
 
    RTsjp ((char *) (&(_o [0])));
    RTsjp ((char *) (&(_o [1])));
    RTsjp ((char *) (&(_o [2])));
    RTsjp ((char *) (&(_o [3])));
    RTsjp ((char *) (&(_o [4])));
    RTsjp ((char *) (&(_o [5])));
    RTsjp ((char *) (&(_o [6])));
 
start :
    _env = RTC4_push ();
    RTF_sg;
    if (setjmp (_env))
        goto rescue;

    _o [0] = RTMM_create (&ECD_sorted_list);
    E67125299 (&_mf, _o [0], false);
    _o [4] = E71024661 (&_mf, _a0, _a1, _a2);
    _o [5] = E68796440 (&_mf, _a0, _o [6] = E68976661 (&_mf, _a0));
    E69124117 (&_mf, _a0, _a1);
    _o [1] = E68943923 (&_mf, _o [4]);
    while (!(*VE68993067(_o [1])))
    {
       _o [2] = E69001267 (&_mf, _o [4], _o [1]);
       if (_a2)
       {
          _o [3] = E71352341 (&_mf, _a0, _o [2]);
       }
       else
       {
          _o [3] = E70926357 (&_mf, _a0, _o [2]);
       }
       E71630899 (&_mf, _o [0], _o [3]);
       E69099563 (&_mf, _o [1]);
    }
    E69124117 (&_mf, _a0, _o [5]);
    RTF_return;
    RTC4_pop ();
    return _o [0];

rescue:
    RTC4_pop ();
    RTF_restore;
    E69124117 (&_mf, _a0, _o [5]);
    RTF_return;
    RTC4_fail ();
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E71073813 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR71073813
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    E71098389 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71090197 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71090197
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = E71598101 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E71098389 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR71098389


    ++RTMM_stop;
    RTFS_add_file (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E71106581 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71106581


    ++RTMM_stop;
    RTFS_remove_file (_a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E71114773 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR71114773
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    E71172117 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71155733 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71155733
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = E71344149 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E71172117 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR71172117


    ++RTMM_stop;
    RTFS_rename_file (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E71180309 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR71180309
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    E71237653 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71221269 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71221269
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = E71417877 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E71237653 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR71237653


    ++RTMM_stop;
    RTFS_copy_file (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71245845 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR71245845
    BOOLEAN             _b0;
    OBJREF              _o [2];
    RTF                 _mf;

    _b0 = false;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _b0 = E71303189 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71294997 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71294997
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = E71409685 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71303189 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR71303189
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_same (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E71311381 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR71311381
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71335957 (&_mf, _a0, _a1));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71335957 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR71335957
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFM_identify (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71344149 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71344149
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_file_exists (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E71352341 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71352341
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [2] = E70950933 (&_mf, _a0, _a1);
    _o [1] = E69189653 (&_mf, _a0, _a1);
    _o [0] = RTMM_create (&ECD_fsys_dat);
    E67125271 (&_mf, _o [0], _o [2], _o [1], _a0, true);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

REAL          E71360533 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71360533
    REAL                _r0;
    OBJREF              _o [1];
    RTF                 _mf;

    _r0 = 0.0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _r0 = E71368725 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _r0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E71368725 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71368725
    REAL  _res;


    ++RTMM_stop;
    _res = RTFS_file_time (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E71376917 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71376917
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71385109 (&_mf, _a0, E70066210 (&_mf, _a1)));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71385109 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71385109
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_file_perm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E71393301 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71393301
    OBJREF              _o [3];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71401493 (&_mf, _a0, E70066210 (&_mf, _a1)));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71401493 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71401493
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_my_file_perm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71409685 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71409685
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_has_readperm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71417877 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71417877
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_has_writeperm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71426069 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71426069
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = E71434261 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71434261 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71434261
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_has_execperm (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E71442453 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71442453
    register INTEGER    _i0;
    OBJREF              _o [1];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _i0 = E71450645 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E71450645 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71450645
    INTEGER  _res;


    ++RTMM_stop;
    _res = RTFS_file_count (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E71458837 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR71458837
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    E71467029 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E71467029 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR71467029


    ++RTMM_stop;
    RTFS_change_file_perm (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E71475221 (_cf, _a0, _a1, _a2, _a3)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;
BOOLEAN       _a3;

{
#ifndef EDCR71475221
    register INTEGER    _i0;
    OBJREF              _o [2];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _i0 = E71491605 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2), _a3);
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E71491605 (_cf, _a0, _a1, _a2, _a3)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;
BOOLEAN       _a3;

{
#ifndef EDCR71491605
    INTEGER  _res;


    ++RTMM_stop;
    _res = RTFM_open (_a1, _a2, _a3);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E71499797 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR71499797
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71507989 (&_mf, _a0));
    if (!E71155733 (&_mf, _a0, _o [0]))
    {
       E71073813 (&_mf, _a0, _o [0], _o [1] = ELS8730);
    }
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71507989 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR71507989
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_temp_file ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71524373 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71524373
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_path_suffix (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71532565 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71532565
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_path_prefix (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E71540757 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR71540757
    OBJREF              _o [4];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = _o [3] = VOIDREF;

    RTF_sl(4, _o, _cf);
    _o [0] = E70778901 (&_mf, _a0, E71565333 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2)));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71565333 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR71565333
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_concat_paths (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71573525 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71573525
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_absolute_path (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71581717 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR71581717
    BOOLEAN             _b0;
    OBJREF              _o [2];
    RTF                 _mf;

    _b0 = false;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _b0 = E71589909 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71589909 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR71589909
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFS_same_path (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E71598101 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR71598101
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTFM_in_use (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E71639061 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
BOOLEAN       _a2;

{
#ifndef EDCR71639061


    ++RTMM_stop;
    RTFS_open_cluster (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

POINTER       E71647253 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR71647253
    POINTER  _res;


    ++RTMM_stop;
    _res = RTFS_read_cluster ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E71655445 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR71655445


    ++RTMM_stop;
    RTFS_close_cluster ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72040469 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR72040469


    ++RTMM_stop;
    RTFS_stat_start (_a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72056853 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72056853


    ++RTMM_stop;
    RTFS_stat_end ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void    ECR21 (obj)

ECA_file_system  *obj;

{
}
/*------------------------------------------------------------------*/

void    ST21 (d)

INTEGER d;

{
    ECA_file_system  p;
    ECDESC  *cd = &ECD_file_system, *ecd = &EECD_file_system;

    cd->f1          = (INTEGER) 21;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_file_system);
    cd->f12         = "file_system";
    cd->f6          = false;
    cd->f13         = ECR21;
    cd->f14         = E67125269;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ";
    (cd->f21)       = (INTEGER *) 0;
    (cd->f22)       = (char **) 0;
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_file_system;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

