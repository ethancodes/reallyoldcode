/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H14.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
ECDESC                ECD_boolean_ref;
ECDESC                EECD_boolean_ref;
/*------------------------------------------------------------------*/

void                  E67125262 ();
OBJREF                E67649550 ();
OBJREF                E68059150 ();
OBJREF                E68263950 ();
OBJREF                E68395022 ();
OBJREF                E68567054 ();
OBJREF                E68575246 ();
OBJREF                E68583438 ();
/*------------------------------------------------------------------*/

void          E67125262 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
BOOLEAN       _a1;

{
#ifndef EDCR67125262
/* LEAF */


    EA14(_a0)->Eitem = _a1;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E67649550 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67649550
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_boolean_ref);
    E67125262 (&_mf, _o [0], !EA14(_a0)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68059150 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68059150
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_boolean_ref);
    E67125262 (&_mf, _o [0], EA14(_a0)->Eitem & EA14(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68263950 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68263950
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_boolean_ref);
    E67125262 (&_mf, _o [0], !EA14(_a0)->Eitem || EA14(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68395022 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68395022
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_boolean_ref);
    E67125262 (&_mf, _o [0], EA14(_a0)->Eitem | EA14(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68567054 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68567054
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_boolean_ref);
    E67125262 (&_mf, _o [0], EA14(_a0)->Eitem ^ EA14(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68575246 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68575246
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_boolean_ref);
    E67125262 (&_mf, _o [0], EA14(_a0)->Eitem || EA14(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68583438 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68583438
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_boolean_ref);
    E67125262 (&_mf, _o [0], EA14(_a0)->Eitem && EA14(_a1)->Eitem);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void    ECR14 (obj)

ECA_boolean_ref  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST14 (d)

INTEGER d;

{
    ECA_boolean_ref  p;
    ECDESC  *cd = &ECD_boolean_ref, *ecd = &EECD_boolean_ref;

    cd->f1          = (INTEGER) 14;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_boolean_ref);
    cd->f12         = "boolean_ref";
    cd->f6          = false;
    cd->f13         = ECR14;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " b";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eitem)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "item";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_boolean_ref;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

