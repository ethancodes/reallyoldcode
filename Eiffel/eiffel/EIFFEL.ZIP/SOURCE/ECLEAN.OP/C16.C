/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H16.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_part_comparable;
extern  ECDESC        EECD_part_comparable;
ECDESC                ECD_comparable;
ECDESC                EECD_comparable;
/*------------------------------------------------------------------*/

extern  BOOLEAN       (*FE67977232()) ();
/*------------------------------------------------------------------*/

BOOLEAN               E67985424 ();
INTEGER               E69378064 ();
OBJREF                E73490448 ();
OBJREF                E73515024 ();
/*------------------------------------------------------------------*/

BOOLEAN       E67985424 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67985424
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = !((*FE67977232(_a1))(&_mf, _a1, _a0));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69378064 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69378064
    register INTEGER    _i0;
    OBJREF              _o [1];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    if ((*FE67977232(_a0))(&_mf, _a0, _a1))
    {
       _i0 = ((INTEGER) -1);
    }
    else
    {
       if ((*FE67977232(_a1))(&_mf, _a1, _a0))
       {
          _i0 = ((INTEGER) 1);
       }
    }
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73490448 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73490448
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    if ((*FE67977232(_a0))(&_mf, _a0, _a1))
    {
       _o [0] = _a0;
    }
    else
    {
       _o [0] = _a1;
    }
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73515024 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73515024
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    if ((*FE67977232(_a1))(&_mf, _a1, _a0))
    {
       _o [0] = _a0;
    }
    else
    {
       _o [0] = _a1;
    }
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void    ECR16 (obj)

ECA_comparable  *obj;

{
}
/*------------------------------------------------------------------*/

void    ST16 (d)

INTEGER d;

{
    ECA_comparable  p;
    ECDESC  *cd = &ECD_comparable, *ecd = &EECD_comparable;

    cd->f1          = (INTEGER) 16;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_comparable);
    cd->f12         = "comparable";
    cd->f6          = false;
    cd->f13         = ECR16;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ";
    (cd->f21)       = (INTEGER *) 0;
    (cd->f22)       = (char **) 0;
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_part_comparable;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_comparable;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

