/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H5.h"
#include             "H6.h"
#include             "H8.h"
#include             "H51.h"
#include             "H67.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_array;
extern  ECDESC        EECD_array;
extern  ECDESC        ECD__i_array;
extern  ECDESC        EECD__i_array;
extern  ECDESC        ECD__c_array;
extern  ECDESC        EECD__c_array;
extern  ECDESC        ECD_comparable;
extern  ECDESC        EECD_comparable;
extern  ECDESC        ECD_iterator;
extern  ECDESC        EECD_iterator;
extern  ECDESC        ECD_sorted_collection;
extern  ECDESC        EECD_sorted_collection;
extern  ECDESC        ECD_twi_iter;
extern  ECDESC        EECD_twi_iter;
extern  ECDESC        ECD_g;
extern  ECDESC        EECD_g;
ECDESC                ECD_sorted_list;
ECDESC                EECD_sorted_list;
/*------------------------------------------------------------------*/

extern  BOOLEAN       *VE68993067 ();
/*------------------------------------------------------------------*/

extern  INTEGER       (*FE69378064()) ();
extern  BOOLEAN       (*FE67977232()) ();
/*------------------------------------------------------------------*/

extern  void          E67125253 ();
extern  void          E67125256 ();
extern  void          E67125254 ();
extern  void          E69836808 ();
extern  void          E69836806 ();
extern  void          E69099563 ();
extern  void          E72990763 ();
extern  void          E67125291 ();
extern  void          E72826944 ();
extern  OBJREF        E69001221 ();
extern  INTEGER       E69001222 ();
extern  void          E69836805 ();
extern  CHARACTER     E69001224 ();
extern  void          E72998936 ();
extern  OBJREF        E68796440 ();
extern  void          E73039939 ();
extern  void          E72843323 ();
extern  void          E72851515 ();
extern  INTEGER       E68960262 ();
extern  INTEGER       E68960261 ();
extern  void          E69877765 ();
extern  void          E69877768 ();
extern  void          E69877766 ();
/*------------------------------------------------------------------*/

void                  E67125299 ();
BOOLEAN               E68821043 ();
OBJREF                E68943923 ();
OBJREF                E69001267 ();
void                  E69181491 ();
INTEGER               E72867891 ();
INTEGER               E72949811 ();
void                  E72958003 ();
void                  E72966195 ();
void                  E69632051 ();
void                  E71254067 ();
void                  E71630899 ();
INTEGER               E72908851 ();
void                  E72925235 ();
void                  E72933427 ();
void                  E72646707 ();
void                  E72654899 ();
void                  E72663091 ();
void                  E72671283 ();
INTEGER               E73048115 ();
BOOLEAN               E72679475 ();
OBJREF                E72687667 ();
OBJREF                E72695859 ();
void                  E72704051 ();
void                  E72712243 ();
void                  E73056307 ();
void                  E73064499 ();
/*------------------------------------------------------------------*/

void          E67125299 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
BOOLEAN       _a1;

{
#ifndef EDCR67125299
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    EA51(_a0)->Eis_unique = _a1;
    EA51(_a0)->Efound = false;
    EA51(_a0)->Ecount = ((INTEGER) 0);
    EA51(_a0)->Eroot = ((INTEGER) 0);
    EA51(_a0)->Efree = ((INTEGER) 1);
    EA51(_a0)->Eitems = RTMM_create (&ECD_array);
    E67125253 (&_mf, EA51(_a0)->Eitems, ((INTEGER) 0), ((INTEGER) 16));
    EA51(_a0)->Ecolor = RTMM_create (&ECD__c_array);
    E67125256 (&_mf, EA51(_a0)->Ecolor, ((INTEGER) 0), ((INTEGER) 16));
    EA51(_a0)->Eparent = RTMM_create (&ECD__i_array);
    E67125254 (&_mf, EA51(_a0)->Eparent, ((INTEGER) 0), ((INTEGER) 16));
    EA51(_a0)->Eleft = RTMM_create (&ECD__i_array);
    E67125254 (&_mf, EA51(_a0)->Eleft, ((INTEGER) 0), ((INTEGER) 16));
    EA51(_a0)->Eright = RTMM_create (&ECD__i_array);
    E67125254 (&_mf, EA51(_a0)->Eright, ((INTEGER) 0), ((INTEGER) 16));
    ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER) 0)] = ((CHARACTER) 'b');
    _i0 = ((INTEGER) 1);
    while (_i0 != ((INTEGER) 16))
    {
       ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0] = ((INTEGER) 1) + _i0;
       _i0 += ((INTEGER) 1);
    }
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0] = ((INTEGER) 0);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68821043 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68821043
    BOOLEAN             _b0;
    OBJREF              _o [2];
    int                 *_env;
    RTF                 _mf;

    _b0 = false;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
 
    RTsjp ((char *) (&_b0));
    RTsjp ((char *) (&(_o [0])));
    RTsjp ((char *) (&(_o [1])));
 
start :
    _env = RTC4_push ();
    RTF_sg;
    if (setjmp (_env))
        goto rescue;

    if (_a1 != (VOIDREF))
    {
       _o [0] = E68943923 (&_mf, _a0);
       _o [1] = E68943923 (&_mf, _a1);
       while ((!(*VE68993067(_o [0])) && !(*VE68993067(_o [1]))) && E69001267 (&_mf, _a0, _o [0]) == E69001267 (&_mf, _a0, _o [1]))
       {
          E69099563 (&_mf, _o [0]);
          E69099563 (&_mf, _o [1]);
       }
       _b0 = (*VE68993067(_o [0])) && (*VE68993067(_o [1]));
    }
    RTF_return;
    RTC4_pop ();
    return _b0;

rescue:
    RTC4_pop ();
    RTF_restore;
    if (_o [0] != (VOIDREF))
    {
       E72990763 (&_mf, _o [0]);
    }
    if (_o [1] != (VOIDREF))
    {
       E72990763 (&_mf, _o [1]);
    }
    RTF_return;
    RTC4_fail ();
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68943923 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68943923
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_twi_iter);
    E67125291 (&_mf, _o [0], _a0);
    E72826944 (&_mf, _a0, _o [0]);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69001267 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69001267
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _o [1] = RTC11_reverse_assign (&ECD_twi_iter, ((_a1)));
    _o [0] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[EA67(_o [1])->Ecursor];
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E69181491 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69181491
    register INTEGER    _i0, _i1, _i2, _i3;
    OBJREF              _o [1];
    RTF                 _mf;

    _i0 = _i1 = _i2 = _i3 = 0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _i3 = E72867891 (&_mf, _a0, _a1);
    if (_i3 != ((INTEGER) 0))
    {
       if (((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i3] == ((INTEGER) 0) || ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i3] == ((INTEGER) 0))
       {
          _i0 = _i3;
       }
       else
       {
          _i0 = E72949811 (&_mf, _a0, _i3);
       }
       if (((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0] != ((INTEGER) 0))
       {
          _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0];
       }
       else
       {
          _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0];
       }
       _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0];
       ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i2] = _i1;
       if (_i1 == ((INTEGER) 0))
       {
          EA51(_a0)->Eroot = _i2;
       }
       else
       {
          if (_i0 == ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1])
          {
             ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1] = _i2;
          }
          else
          {
             ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1] = _i2;
          }
       }
       if (_i0 != _i3)
       {
          ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i3] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i0];
       }
       if (((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i0] == ((CHARACTER) 'b'))
       {
          E72958003 (&_mf, _a0, _i2);
       }
       EA51(_a0)->Ecount -= ((INTEGER) 1);
       E72966195 (&_mf, _a0, _i0);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69632051 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69632051
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72998936 (&_mf, _a0, _a1);
    EA51(_a0)->Eitems = E68796440 (&_mf, _a0, EA51(_a1)->Eitems);
    EA51(_a0)->Ecolor = E68796440 (&_mf, _a0, EA51(_a1)->Ecolor);
    EA51(_a0)->Eparent = E68796440 (&_mf, _a0, EA51(_a1)->Eparent);
    EA51(_a0)->Eleft = E68796440 (&_mf, _a0, EA51(_a1)->Eleft);
    EA51(_a0)->Eright = E68796440 (&_mf, _a0, EA51(_a1)->Eright);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E71254067 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71254067
    register INTEGER    _i0;
    OBJREF              _o [1];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC11_reverse_assign (&ECD_twi_iter, ((_a1)));
    if (EA51(_a0)->Eroot != ((INTEGER) 0))
    {
       _i0 = EA51(_a0)->Eroot;
       while (((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0] != ((INTEGER) 0))
       {
          _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0];
       }
    }
    E73039939 (&_mf, _o [0], _i0);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E71630899 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR71630899
    register INTEGER    _i0, _i1, _i2, _i3, _i4;
    BOOLEAN             _b0;
    OBJREF              _o [2];
    RTF                 _mf;

    _i0 = _i1 = _i2 = _i3 = _i4 = 0;
    _b0 = false;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _i3 = EA51(_a0)->Eroot;
    while (!_b0 && _i3 != ((INTEGER) 0))
    {
       _i4 = (*FE69378064(_a1))(&_mf, _a1, _o [0] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i3]);
       if (EA51(_a0)->Eis_unique && _i4 == ((INTEGER) 0))
       {
          _b0 = true;
       }
       else
       {
          _i1 = _i3;
          if (_i4 < ((INTEGER) 0))
          {
             _i3 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i3];
          }
          else
          {
             _i3 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i3];
          }
       }
    }
    if (_i3 == ((INTEGER) 0))
    {
       _i3 = E72908851 (&_mf, _a0, _a1);
       ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i3] = _i1;
       ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i3] = ((CHARACTER) 'r');
       if (_i1 == ((INTEGER) 0))
       {
          EA51(_a0)->Eroot = _i3;
       }
       else
       {
          if ((*FE67977232(_a1))(&_mf, _a1, _o [0] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i1]))
          {
             ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1] = _i3;
          }
          else
          {
             ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1] = _i3;
          }
       }
       EA51(_a0)->Ecount += ((INTEGER) 1);
       while (_i3 != EA51(_a0)->Eroot && ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i3]] != ((CHARACTER) 'b'))
       {
          _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i3];
          _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i1];
          if (_i1 == ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0])
          {
             _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0];
             if (_i2 != ((INTEGER) 0) && ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] == ((CHARACTER) 'r'))
             {
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1] = ((CHARACTER) 'b');
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER) 'b');
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i0] = ((CHARACTER) 'r');
                _i3 = _i0;
             }
             else
             {
                if (_i3 == ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1])
                {
                   _i3 = _i1;
                   E72925235 (&_mf, _a0, _i3);
                   _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i3];
                   _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i1];
                }
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1] = ((CHARACTER) 'b');
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i0] = ((CHARACTER) 'r');
                E72933427 (&_mf, _a0, _i0);
             }
          }
          else
          {
             _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0];
             if (_i2 != ((INTEGER) 0) && ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] == ((CHARACTER) 'r'))
             {
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1] = ((CHARACTER) 'b');
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER) 'b');
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i0] = ((CHARACTER) 'r');
                _i3 = _i0;
             }
             else
             {
                if (_i3 == ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1])
                {
                   _i3 = _i1;
                   E72933427 (&_mf, _a0, _i3);
                   _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i3];
                   _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i1];
                }
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1] = ((CHARACTER) 'b');
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i0] = ((CHARACTER) 'r');
                E72925235 (&_mf, _a0, _i0);
             }
          }
       }
    }
    ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[EA51(_a0)->Eroot] = ((CHARACTER) 'b');
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72646707 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72646707
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = E72867891 (&_mf, _a0, _a1);
    if (_i0 == ((INTEGER) 0))
    {
       EA51(_a0)->Efound = false;
    }
    else
    {
       EA51(_a0)->Efound = true;
       EA51(_a0)->Efound_item = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i0];
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72654899 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72654899
    register INTEGER    _i0;
    OBJREF              _o [1];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC11_reverse_assign (&ECD_twi_iter, ((_a1)));
    if (EA51(_a0)->Eroot != ((INTEGER) 0))
    {
       _i0 = EA51(_a0)->Eroot;
       while (((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0] != ((INTEGER) 0))
       {
          _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0];
       }
    }
    E73039939 (&_mf, _o [0], _i0);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72663091 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72663091
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC11_reverse_assign (&ECD_twi_iter, ((_a1)));
    E73039939 (&_mf, _o [0], E72949811 (&_mf, _a0, EA67(_o [0])->Ecursor));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72671283 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72671283
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC11_reverse_assign (&ECD_twi_iter, ((_a1)));
    E73039939 (&_mf, _o [0], E73048115 (&_mf, _a0, EA67(_o [0])->Ecursor));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E72679475 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72679475
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTC11_reverse_assign (&ECD_twi_iter, ((_a1)));
    _b0 = EA67(_o [0])->Ecursor != ((INTEGER) 0);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E72687667 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72687667
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_twi_iter);
    E67125291 (&_mf, _o [0], _a0);
    E72843323 (&_mf, _a0, _a1, _o [0]);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E72695859 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72695859
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_twi_iter);
    E67125291 (&_mf, _o [0], _a0);
    E72851515 (&_mf, _a0, _a1, _o [0]);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E72704051 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR72704051
    register INTEGER    _i0, _i1;
    BOOLEAN             _b0;
    OBJREF              _o [2];
    RTF                 _mf;

    _i0 = _i1 = 0;
    _b0 = false;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _i1 = EA51(_a0)->Eroot;
    while (!_b0 && _i1 != ((INTEGER) 0))
    {
       _i0 = (*FE69378064(_a1))(&_mf, _a1, _o [0] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i1]);
       if (_i0 == ((INTEGER) 0))
       {
          _b0 = true;
       }
       else
       {
          if (_i0 < ((INTEGER) 0))
          {
             if (((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1] != ((INTEGER) 0))
             {
                _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1];
             }
             else
             {
                _b0 = true;
             }
          }
          else
          {
             if (((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1] != ((INTEGER) 0))
             {
                _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1];
             }
             else
             {
                _i1 = E72949811 (&_mf, _a0, _i1);
                _b0 = true;
             }
          }
       }
    }
    E73039939 (&_mf, _a2, _i1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72712243 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR72712243
    register INTEGER    _i0, _i1;
    BOOLEAN             _b0;
    OBJREF              _o [2];
    RTF                 _mf;

    _i0 = _i1 = 0;
    _b0 = false;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _i1 = EA51(_a0)->Eroot;
    while (!_b0 && _i1 != ((INTEGER) 0))
    {
       _i0 = (*FE69378064(_a1))(&_mf, _a1, _o [0] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i1]);
       if (_i0 == ((INTEGER) 0))
       {
          _b0 = true;
       }
       else
       {
          if (_i0 < ((INTEGER) 0))
          {
             if (((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1] != ((INTEGER) 0))
             {
                _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1];
             }
             else
             {
                _i1 = E73048115 (&_mf, _a0, _i1);
                _b0 = true;
             }
          }
          else
          {
             if (((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1] != ((INTEGER) 0))
             {
                _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1];
             }
             else
             {
                _b0 = true;
             }
          }
       }
    }
    E73039939 (&_mf, _a2, _i1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E72867891 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72867891
    register INTEGER    _i0, _i1;
    BOOLEAN             _b0;
    OBJREF              _o [2];
    RTF                 _mf;

    _i0 = _i1 = 0;
    _b0 = false;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _i0 = EA51(_a0)->Eroot;
    while (!_b0 && _i0 != ((INTEGER) 0))
    {
       _i1 = (*FE69378064(_a1))(&_mf, _a1, _o [0] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i0]);
       if (_i1 == ((INTEGER) 0))
       {
          _b0 = true;
       }
       else
       {
          if (_i1 < ((INTEGER) 0))
          {
             _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0];
          }
          else
          {
             _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0];
          }
       }
    }
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E72908851 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72908851
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    if (EA51(_a0)->Ecount == E68960262 (&_mf, EA51(_a0)->Eparent) - ((INTEGER) 1))
    {
       E73056307 (&_mf, _a0);
    }
    _i0 = EA51(_a0)->Efree;
    EA51(_a0)->Efree = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[EA51(_a0)->Efree];
    ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i0] = _a1;
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0] = ((INTEGER) 0);
    ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0] = ((INTEGER) 0);
    ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0] = ((INTEGER) 0);
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void          E72925235 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR72925235
    register INTEGER    _i0, _i1;
    RTF                 _mf;

    _i0 = _i1 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_a1];
    _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0];
    ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_a1] = _i1;
    if (_i1 != ((INTEGER) 0))
    {
       ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i1] = _a1;
    }
    _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_a1];
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0] = _i1;
    if (_i1 == ((INTEGER) 0))
    {
       EA51(_a0)->Eroot = _i0;
    }
    else
    {
       if (_a1 == ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1])
       {
          ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1] = _i0;
       }
       else
       {
          ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1] = _i0;
       }
    }
    ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0] = _a1;
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_a1] = _i0;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72933427 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR72933427
    register INTEGER    _i0, _i1;
    RTF                 _mf;

    _i0 = _i1 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_a1];
    _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0];
    ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_a1] = _i1;
    if (_i1 != ((INTEGER) 0))
    {
       ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i1] = _a1;
    }
    _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_a1];
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0] = _i1;
    if (_i1 == ((INTEGER) 0))
    {
       EA51(_a0)->Eroot = _i0;
    }
    else
    {
       if (_a1 == ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1])
       {
          ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1] = _i0;
       }
       else
       {
          ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1] = _i0;
       }
    }
    ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0] = _a1;
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_a1] = _i0;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E72949811 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR72949811
    register INTEGER    _i0, _i1;
    RTF                 _mf;

    _i0 = _i1 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i1 = _a1;
    if (((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1] != ((INTEGER) 0))
    {
       _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1];
       while (((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0] != ((INTEGER) 0))
       {
          _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0];
       }
    }
    else
    {
       _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i1];
       while (_i0 != ((INTEGER) 0) && _i1 != ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i0])
       {
          _i1 = _i0;
          _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0];
       }
    }
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void          E72958003 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR72958003
    register INTEGER    _i0, _i1, _i2;
    RTF                 _mf;

    _i0 = _i1 = _i2 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = _a1;
    while (_i0 != EA51(_a0)->Eroot && ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i0] != ((CHARACTER) 'r'))
    {
       _i1 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0];
       if (_i0 == ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1])
       {
          _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1];
          if (((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] == ((CHARACTER) 'r'))
          {
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER) 'b');
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1] = ((CHARACTER) 'r');
             E72925235 (&_mf, _a0, _i1);
             _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1];
          }
          if (((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2]] == ((CHARACTER) 'b') && ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2]] == ((CHARACTER) 'b'))
          {
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER) 'r');
             _i0 = _i1;
          }
          else
          {
             if (((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2]] == ((CHARACTER) 'b'))
             {
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2]] = ((CHARACTER) 'b');
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER) 'r');
                E72933427 (&_mf, _a0, _i2);
                _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i1];
             }
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1];
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1] = ((CHARACTER) 'b');
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2]] = ((CHARACTER) 'b');
             E72925235 (&_mf, _a0, _i1);
             _i0 = EA51(_a0)->Eroot;
          }
       }
       else
       {
          _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1];
          if (((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] == ((CHARACTER) 'r'))
          {
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER) 'b');
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1] = ((CHARACTER) 'r');
             E72933427 (&_mf, _a0, _i1);
             _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1];
          }
          if (((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2]] == ((CHARACTER) 'b') && ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2]] == ((CHARACTER) 'b'))
          {
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER) 'r');
             _i0 = _i1;
          }
          else
          {
             if (((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2]] == ((CHARACTER) 'b'))
             {
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2]] = ((CHARACTER) 'b');
                ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER) 'r');
                E72925235 (&_mf, _a0, _i2);
                _i2 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1];
             }
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2] = ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1];
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i1] = ((CHARACTER) 'b');
             ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2]] = ((CHARACTER) 'b');
             E72933427 (&_mf, _a0, _i1);
             _i0 = EA51(_a0)->Eroot;
          }
       }
    }
    ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i0] = ((CHARACTER) 'b');
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72966195 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR72966195
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_a1] = EA51(_a0)->Efree;
    EA51(_a0)->Efree = _a1;
    if (EA51(_a0)->Ecount <= E68960262 (&_mf, EA51(_a0)->Eparent) / ((INTEGER) 4) && E68960262 (&_mf, EA51(_a0)->Eparent) > ((INTEGER) 17))
    {
       E73064499 (&_mf, _a0);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E73048115 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR73048115
    register INTEGER    _i0, _i1;
    RTF                 _mf;

    _i0 = _i1 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i1 = _a1;
    if (((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1] != ((INTEGER) 0))
    {
       _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i1];
       while (((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0] != ((INTEGER) 0))
       {
          _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0];
       }
    }
    else
    {
       _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i1];
       while (_i0 != ((INTEGER) 0) && _i1 != ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i0])
       {
          _i1 = _i0;
          _i0 = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0];
       }
    }
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void          E73056307 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73056307
    register INTEGER    _i0, _i1;
    RTF                 _mf;

    _i0 = _i1 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i1 = E68960261 (&_mf, EA51(_a0)->Eitems) - ((INTEGER) 1);
    E69877765 (&_mf, EA51(_a0)->Eitems, ((INTEGER) 0), ((INTEGER) 2) * _i1);
    E69877768 (&_mf, EA51(_a0)->Ecolor, ((INTEGER) 0), ((INTEGER) 2) * _i1);
    E69877766 (&_mf, EA51(_a0)->Eparent, ((INTEGER) 0), ((INTEGER) 2) * _i1);
    E69877766 (&_mf, EA51(_a0)->Eleft, ((INTEGER) 0), ((INTEGER) 2) * _i1);
    E69877766 (&_mf, EA51(_a0)->Eright, ((INTEGER) 0), ((INTEGER) 2) * _i1);
    _i0 = ((INTEGER) 1) + _i1;
    while (_i0 != ((INTEGER) 2) * _i1)
    {
       ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0] = ((INTEGER) 1) + _i0;
       _i0 += ((INTEGER) 1);
    }
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i0] = ((INTEGER) 0);
    EA51(_a0)->Efree = ((INTEGER) 1) + _i1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E73064499 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73064499
    register INTEGER    _i0, _i1, _i2;
    OBJREF              _o [6];
    RTF                 _mf;

    _i0 = _i1 = _i2 = 0;
    _o [0] = _o [1] = _o [2] = _o [3] = _o [4] = _o [5] = VOIDREF;

    RTF_sl(6, _o, _cf);
    _i1 = E68960262 (&_mf, EA51(_a0)->Eparent) / ((INTEGER) 2);
    _o [0] = RTMM_create (&ECD_array);
    E67125253 (&_mf, _o [0], ((INTEGER) 0), _i1);
    _o [2] = RTMM_create (&ECD__c_array);
    E67125256 (&_mf, _o [2], ((INTEGER) 0), _i1);
    _o [1] = RTMM_create (&ECD__i_array);
    E67125254 (&_mf, _o [1], ((INTEGER) 0), _i1);
    _o [3] = RTMM_create (&ECD__i_array);
    E67125254 (&_mf, _o [3], ((INTEGER) 0), _i1);
    _o [4] = RTMM_create (&ECD__i_array);
    E67125254 (&_mf, _o [4], ((INTEGER) 0), _i1);
    ((CHARACTER *)(EA8(_o [2])->Estore))[((INTEGER) 0)] = ((CHARACTER) 'b');
    EA51(_a0)->Efree = ((INTEGER) 1);
    _i0 = ((INTEGER) 1);
    _i2 = EA51(_a0)->Eroot;
    ((OBJREF *)(EA5(_o [0])->Estore))[EA51(_a0)->Efree] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i2];
    ((CHARACTER *)(EA8(_o [2])->Estore))[EA51(_a0)->Efree] = ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2];
    ((INTEGER *)(EA6(_o [1])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i2];
    ((INTEGER *)(EA6(_o [3])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2];
    ((INTEGER *)(EA6(_o [4])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2];
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2]] = EA51(_a0)->Efree;
    ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2]] = EA51(_a0)->Efree;
    EA51(_a0)->Efree += ((INTEGER) 1);
    while (_i0 != EA51(_a0)->Efree)
    {
       _i2 = ((INTEGER *)(EA6(_o [3])->Estore))[_i0];
       if (_i2 != ((INTEGER) 0))
       {
          ((OBJREF *)(EA5(_o [0])->Estore))[EA51(_a0)->Efree] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i2];
          ((CHARACTER *)(EA8(_o [2])->Estore))[EA51(_a0)->Efree] = ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2];
          ((INTEGER *)(EA6(_o [1])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i2];
          ((INTEGER *)(EA6(_o [3])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2];
          ((INTEGER *)(EA6(_o [4])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2];
          ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2]] = EA51(_a0)->Efree;
          ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2]] = EA51(_a0)->Efree;
          ((INTEGER *)(EA6(_o [3])->Estore))[_i0] = EA51(_a0)->Efree;
          EA51(_a0)->Efree += ((INTEGER) 1);
       }
       _i2 = ((INTEGER *)(EA6(_o [4])->Estore))[_i0];
       if (_i2 != ((INTEGER) 0))
       {
          ((OBJREF *)(EA5(_o [0])->Estore))[EA51(_a0)->Efree] = ((OBJREF *)(EA5(EA51(_a0)->Eitems)->Estore))[_i2];
          ((CHARACTER *)(EA8(_o [2])->Estore))[EA51(_a0)->Efree] = ((CHARACTER *)(EA8(EA51(_a0)->Ecolor)->Estore))[_i2];
          ((INTEGER *)(EA6(_o [1])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[_i2];
          ((INTEGER *)(EA6(_o [3])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2];
          ((INTEGER *)(EA6(_o [4])->Estore))[EA51(_a0)->Efree] = ((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2];
          ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eleft)->Estore))[_i2]] = EA51(_a0)->Efree;
          ((INTEGER *)(EA6(EA51(_a0)->Eparent)->Estore))[((INTEGER *)(EA6(EA51(_a0)->Eright)->Estore))[_i2]] = EA51(_a0)->Efree;
          ((INTEGER *)(EA6(_o [4])->Estore))[_i0] = EA51(_a0)->Efree;
          EA51(_a0)->Efree += ((INTEGER) 1);
       }
       _i0 += ((INTEGER) 1);
    }
    _i0 = EA51(_a0)->Efree;
    while (_i0 != _i1)
    {
       ((INTEGER *)(EA6(_o [1])->Estore))[_i0] = ((INTEGER) 1) + _i0;
       _i0 += ((INTEGER) 1);
    }
    EA51(_a0)->Eitems = _o [0];
    EA51(_a0)->Ecolor = _o [2];
    EA51(_a0)->Eparent = _o [1];
    EA51(_a0)->Eleft = _o [3];
    EA51(_a0)->Eright = _o [4];
    EA51(_a0)->Eroot = ((INTEGER) 1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void    ECR51 (obj)

ECA_sorted_list  *obj;

{

    obj->Ecolor = VOIDREF;
    obj->Efound_item = VOIDREF;
    obj->Eitems = VOIDREF;
    obj->Eleft = VOIDREF;
    obj->Eparent = VOIDREF;
    obj->Eright = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST51 (d)

INTEGER d;

{
    ECA_sorted_list  p;
    ECDESC  *cd = &ECD_sorted_list, *ecd = &EECD_sorted_list;

    cd->f1          = (INTEGER) 51;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_sorted_list);
    cd->f12         = "sorted_list";
    cd->f6          = false;
    cd->f13         = ECR51;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " oiboibooiooi";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 12) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecolor)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Ecount)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Efound)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Efound_item)) - ((CHARACTER *) &p));
    (cd->f21) [4]   = (INTEGER) (((CHARACTER *) &(p.Efree)) - ((CHARACTER *) &p));
    (cd->f21) [5]   = (INTEGER) (((CHARACTER *) &(p.Eis_unique)) - ((CHARACTER *) &p));
    (cd->f21) [6]   = (INTEGER) (((CHARACTER *) &(p.Eitems)) - ((CHARACTER *) &p));
    (cd->f21) [7]   = (INTEGER) (((CHARACTER *) &(p.Eleft)) - ((CHARACTER *) &p));
    (cd->f21) [8]   = (INTEGER) (((CHARACTER *) &(p.En_iter)) - ((CHARACTER *) &p));
    (cd->f21) [9]   = (INTEGER) (((CHARACTER *) &(p.Eparent)) - ((CHARACTER *) &p));
    (cd->f21) [10]   = (INTEGER) (((CHARACTER *) &(p.Eright)) - ((CHARACTER *) &p));
    (cd->f21) [11]   = (INTEGER) (((CHARACTER *) &(p.Eroot)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 12) * sizeof (char *));
    (cd->f22) [0]   = (char *) "color";
    (cd->f22) [1]   = (char *) "count";
    (cd->f22) [2]   = (char *) "found";
    (cd->f22) [3]   = (char *) "found_item";
    (cd->f22) [4]   = (char *) "free";
    (cd->f22) [5]   = (char *) "is_unique";
    (cd->f22) [6]   = (char *) "items";
    (cd->f22) [7]   = (char *) "left";
    (cd->f22) [8]   = (char *) "n_iter";
    (cd->f22) [9]   = (char *) "parent";
    (cd->f22) [10]   = (char *) "right";
    (cd->f22) [11]   = (char *) "root";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 7) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Ecolor)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) (((CHARACTER *) &(p.Efound_item)) - ((CHARACTER *) &p));
    (cd->f5) [2]    = (INTEGER) (((CHARACTER *) &(p.Eitems)) - ((CHARACTER *) &p));
    (cd->f5) [3]    = (INTEGER) (((CHARACTER *) &(p.Eleft)) - ((CHARACTER *) &p));
    (cd->f5) [4]    = (INTEGER) (((CHARACTER *) &(p.Eparent)) - ((CHARACTER *) &p));
    (cd->f5) [5]    = (INTEGER) (((CHARACTER *) &(p.Eright)) - ((CHARACTER *) &p));
    (cd->f5) [6]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_sorted_collection;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_sorted_list;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

