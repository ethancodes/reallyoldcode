/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H43.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_traversable;
extern  ECDESC        EECD_traversable;
ECDESC                ECD_iterator;
ECDESC                EECD_iterator;
/*------------------------------------------------------------------*/

extern  OBJREF        *VE73261099 ();
extern  BOOLEAN       *VE73310251 ();
extern  BOOLEAN       *VE68993067 ();
/*------------------------------------------------------------------*/

extern  void          E72663091 ();
extern  void          E71254067 ();
extern  BOOLEAN       E72679475 ();
extern  void          E73326656 ();
extern  void          E73334848 ();
/*------------------------------------------------------------------*/

void                  E67125291 ();
void                  E69099563 ();
BOOLEAN               E72679467 ();
void                  E73293867 ();
void                  E71254059 ();
void                  E73269291 ();
void                  E72990763 ();
/*------------------------------------------------------------------*/

void          E67125291 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67125291
/* LEAF */


    *VE73261099(_a0) = _a1;
    *VE73310251(_a0) = false;
#endif
}
/*------------------------------------------------------------------*/

void          E69099563 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69099563
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72663091 (&_mf, *VE73261099(_a0), _a0);
    if (!E72679467 (&_mf, _a0))
    {
       E73293867 (&_mf, _a0);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E71254059 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR71254059
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E71254067 (&_mf, *VE73261099(_a0), _a0);
    E73269291 (&_mf, _a0);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E72679467 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72679467
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E72679475 (&_mf, *VE73261099(_a0), _a0);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E72990763 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72990763
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (!(*VE68993067(_a0)))
    {
       E73293867 (&_mf, _a0);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E73269291 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73269291
    RTF                 _mf;
    BOOLEAN *_vpt0;
    BOOLEAN *_vpt1;


    RTF_sl(0, (OBJREF *) 0, _cf);
    _vpt0 = VE68993067(_a0);
    _vpt1 = VE73310251(_a0);
    (*_vpt0) = !E72679467 (&_mf, _a0);
    if (!((*_vpt0)) && !((*_vpt1)))
    {
       E73326656 (&_mf, *VE73261099(_a0));
       (*_vpt1) = true;
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E73293867 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73293867
    RTF                 _mf;
    BOOLEAN *_vpt0;


    RTF_sl(0, (OBJREF *) 0, _cf);
    _vpt0 = VE73310251(_a0);
    *VE68993067(_a0) = true;
    if ((*_vpt0))
    {
       (*_vpt0) = false;
       E73334848 (&_mf, *VE73261099(_a0));
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void    ECR43 (obj)

ECA_iterator  *obj;

{

    obj->Epartner = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST43 (d)

INTEGER d;

{
    ECA_iterator  p;
    ECDESC  *cd = &ECD_iterator, *ecd = &EECD_iterator;

    cd->f1          = (INTEGER) 43;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_iterator);
    cd->f12         = "iterator";
    cd->f6          = false;
    cd->f13         = ECR43;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " bbo";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 3) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Efinished)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Elogged_in)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Epartner)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 3) * sizeof (char *));
    (cd->f22) [0]   = (char *) "finished";
    (cd->f22) [1]   = (char *) "logged_in";
    (cd->f22) [2]   = (char *) "partner";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Epartner)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_iterator;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

