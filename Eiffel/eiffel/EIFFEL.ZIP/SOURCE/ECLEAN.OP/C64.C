/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H64.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_iterator;
extern  ECDESC        EECD_iterator;
ECDESC                ECD_traversable;
ECDESC                EECD_traversable;
/*------------------------------------------------------------------*/

extern  INTEGER       *VE74121280 ();
/*------------------------------------------------------------------*/

extern  void          E67125291 ();
extern  void          E71254067 ();
extern  BOOLEAN       E72679475 ();
extern  void          E73269291 ();
extern  void          E73293867 ();
/*------------------------------------------------------------------*/

OBJREF                E68943936 ();
void                  E72826944 ();
void                  E73326656 ();
void                  E73334848 ();
BOOLEAN               E74113088 ();
/*------------------------------------------------------------------*/

OBJREF        E68943936 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68943936
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_iterator);
    E67125291 (&_mf, _o [0], _a0);
    E72826944 (&_mf, _a0, _o [0]);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E72826944 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72826944
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E71254067 (&_mf, _a0, _a1);
    if (E72679475 (&_mf, _a0, _a1))
    {
       E73269291 (&_mf, _a1);
    }
    else
    {
       E73293867 (&_mf, _a1);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E73326656 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73326656
/* LEAF */


    (*VE74121280(_a0)) += ((INTEGER) 1);
#endif
}
/*------------------------------------------------------------------*/

void          E73334848 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73334848
/* LEAF */


    (*VE74121280(_a0)) -= ((INTEGER) 1);
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E74113088 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR74113088
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = (*VE74121280(_a0)) > ((INTEGER) 0);
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void    ECR64 (obj)

ECA_traversable  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST64 (d)

INTEGER d;

{
    ECA_traversable  p;
    ECDESC  *cd = &ECD_traversable, *ecd = &EECD_traversable;

    cd->f1          = (INTEGER) 64;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_traversable);
    cd->f12         = "traversable";
    cd->f6          = false;
    cd->f13         = ECR64;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " i";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.En_iter)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "n_iter";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_traversable;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

