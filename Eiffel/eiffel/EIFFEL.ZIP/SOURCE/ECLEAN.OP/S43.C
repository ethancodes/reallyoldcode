/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "H43.h"
#include             "H65.h"
#include             "H67.h"
/*------------------------------------------------------------------*/

/*------------------------------------------------------------------*/

BOOLEAN       *VE68993067 (Current)

OBJREF    Current;

{
    register int    cnr;
    static   OBJREF lobj = (OBJREF) 0;
    static   BOOLEAN *lres;

    cnr = (int) (ECNR (Current));

    if (Current == lobj)
        return lres;

    if (cnr)
        lobj = Current;
    else
        RTC4_raise ((CHARACTER *) "iterator.finished", (CHARACTER *) "", VOID_CALL_TARGET, VOIDREF);

    if ((cnr < 65) || (cnr > 67))
        return (lres = &(EA43(Current)->Efinished));
    if (cnr == 65)
        return (lres = &(EA65(Current)->Efinished));
    else
    if (cnr == 67)
        return (lres = &(EA67(Current)->Efinished));

    return (lres = &(EA43(Current)->Efinished));
}
/*------------------------------------------------------------------*/

OBJREF        *VE73261099 (Current)

OBJREF    Current;

{
    register int    cnr;
    static   OBJREF lobj = (OBJREF) 0;
    static   OBJREF *lres;

    cnr = (int) (ECNR (Current));

    if (Current == lobj)
        return lres;

    if (cnr)
        lobj = Current;
    else
        RTC4_raise ((CHARACTER *) "iterator.partner", (CHARACTER *) "", VOID_CALL_TARGET, VOIDREF);

    if ((cnr < 65) || (cnr > 67))
        return (lres = &(EA43(Current)->Epartner));
    if (cnr == 65)
        return (lres = &(EA65(Current)->Epartner));
    else
    if (cnr == 67)
        return (lres = &(EA67(Current)->Epartner));

    return (lres = &(EA43(Current)->Epartner));
}
/*------------------------------------------------------------------*/

BOOLEAN       *VE73310251 (Current)

OBJREF    Current;

{
    register int    cnr;
    static   OBJREF lobj = (OBJREF) 0;
    static   BOOLEAN *lres;

    cnr = (int) (ECNR (Current));

    if (Current == lobj)
        return lres;

    if (cnr)
        lobj = Current;
    else
        RTC4_raise ((CHARACTER *) "iterator.logged_in", (CHARACTER *) "", VOID_CALL_TARGET, VOIDREF);

    if ((cnr < 65) || (cnr > 67))
        return (lres = &(EA43(Current)->Elogged_in));
    if (cnr == 65)
        return (lres = &(EA65(Current)->Elogged_in));
    else
    if (cnr == 67)
        return (lres = &(EA67(Current)->Elogged_in));

    return (lres = &(EA43(Current)->Elogged_in));
}
/*------------------------------------------------------------------*/

