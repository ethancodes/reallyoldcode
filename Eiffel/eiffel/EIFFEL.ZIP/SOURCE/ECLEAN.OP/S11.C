/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "H1.h"
#include             "H2.h"
#include             "H3.h"
#include             "H4.h"
#include             "H5.h"
#include             "H6.h"
#include             "H8.h"
#include             "H10.h"
#include             "H11.h"
#include             "H12.h"
#include             "H13.h"
#include             "H14.h"
#include             "H15.h"
#include             "H17.h"
#include             "H18.h"
#include             "H21.h"
#include             "H23.h"
#include             "H26.h"
#include             "H33.h"
#include             "H34.h"
#include             "H43.h"
#include             "H51.h"
#include             "H65.h"
#include             "H67.h"
#include             "H72.h"
#include             "H73.h"
/*------------------------------------------------------------------*/

extern  void          E69632005 ();
extern  void          E69632006 ();
extern  void          E69632008 ();
extern  void          E69632013 ();
extern  void          E69632018 ();
extern  void          E69632024 ();
extern  void          E69632034 ();
extern  void          E69632051 ();
extern  void          E69632072 ();
extern  void          E69632073 ();
/*------------------------------------------------------------------*/

EPV        FE69632011 (Current)

OBJREF    Current;

{
    register int cnr;
    static   int lcnr = -1;
    static   EPV lres;


    cnr = (int) (ECNR (Current));

    if (cnr == lcnr)
        return lres;

    if (cnr)
        lcnr = cnr;
    else
        RTC4_raise ((CHARACTER *) "any.copy", (CHARACTER *) "", VOID_CALL_TARGET, VOIDREF);

    if ((cnr < 5) || (cnr > 73))
        return (lres = E69632024);
    if (cnr == 5)
        return (lres = E69632005);
    else
    if (cnr == 6)
        return (lres = E69632006);
    else
    if (cnr == 8)
        return (lres = E69632008);
    else
    if (cnr == 13)
        return (lres = E69632013);
    else
    if (cnr == 18)
        return (lres = E69632018);
    else
    if (cnr == 34)
        return (lres = E69632034);
    else
    if (cnr == 51)
        return (lres = E69632051);
    else
    if (cnr == 72)
        return (lres = E69632072);
    else
    if (cnr == 73)
        return (lres = E69632073);

    return (lres = E69632024);
}
/*------------------------------------------------------------------*/

