/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H24.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
ECDESC                ECD_general;
ECDESC                EECD_general;
/*------------------------------------------------------------------*/

extern  void          (*FE69632011()) ();
extern  BOOLEAN       (*FE68821016()) ();
extern  BOOLEAN       (*FE68821003()) ();
extern  void          (*FE69632024()) ();
/*------------------------------------------------------------------*/

extern  BOOLEAN       RTC11_hea ();
extern  BOOLEAN       RTC11_is_eequal ();
extern  BOOLEAN       RTC11_is_equal ();
extern  BOOLEAN       RTC11_same_dynamic_type ();
extern  void          RTC11_ecopy ();
extern  void          RTC11_copy ();
extern  OBJREF        RTC11_clone ();
extern  BOOLEAN       RTC11_deep_is_equal ();
extern  OBJREF        RTC11_deep_clone ();
extern  BOOLEAN       RTC11_conforms_to ();
/*------------------------------------------------------------------*/

OBJREF                E68796440 ();
OBJREF                E73678872 ();
BOOLEAN               E68821016 ();
BOOLEAN               E73555992 ();
BOOLEAN               E73572376 ();
BOOLEAN               E73564184 ();
BOOLEAN               E73580568 ();
void                  E69632024 ();
OBJREF                E73637912 ();
void                  E73629720 ();
void                  E73646104 ();
OBJREF                E69705752 ();
void                  E72998936 ();
BOOLEAN               E73605144 ();
BOOLEAN               E73613336 ();
BOOLEAN               E73662488 ();
BOOLEAN               E73719832 ();
BOOLEAN               E73695256 ();
void                  E73728024 ();
OBJREF                E73736216 ();
OBJREF                E73752600 ();
void                  E73801752 ();
/*------------------------------------------------------------------*/

static  OBJREF        Eoonce [2];
static  BOOLEAN       Eonce [2];
/*------------------------------------------------------------------*/

OBJREF        E68796440 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68796440
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    if (_a1 != (VOIDREF))
    {
       _o [0] = E73678872 (&_mf, _a0, _a1);
       (*FE69632011(_o [0]))(&_mf, _o [0], _a1);
    }
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68821016 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68821016
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    if (E73555992 (&_mf, _a0))
    {
       _b0 = E73564184 (&_mf, _a0, _a1, ((POINTER) (E73572376)));
    }
    else
    {
       _b0 = E73580568 (&_mf, _a0, _a1);
    }
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E69632024 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69632024
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (E73555992 (&_mf, _a0))
    {
       E73629720 (&_mf, _a0, _a1, ((POINTER) (E73637912)));
    }
    else
    {
       E73646104 (&_mf, _a0, _a1);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69705752 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69705752
/* LEAF */

    if (Eonce [0])
        return Eoonce [0];
    Eonce [0] = true;

    Eoonce [0] = VOIDREF;  RTMM_protect ((OBJREF *) (Eoonce + 0), (INTEGER) 1);

    return Eoonce [0];
#endif
}
/*------------------------------------------------------------------*/

void          E72998936 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72998936
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (E73555992 (&_mf, _a0))
    {
       E73629720 (&_mf, _a0, _a1, ((POINTER) (E73637912)));
    }
    else
    {
       E73646104 (&_mf, _a0, _a1);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73555992 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73555992
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC11_hea (_a0);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73564184 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
POINTER       _a2;

{
#ifndef EDCR73564184
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC11_is_eequal (_a0, _a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73572376 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73572376
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = (*FE68821016(_a0))(&_mf, _a0, _a1);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73580568 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73580568
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC11_is_equal (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73596952 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR73596952
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC11_same_dynamic_type (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73605144 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73605144
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    if (E73555992 (&_mf, _a0))
    {
       _b0 = E73564184 (&_mf, _a0, _a1, ((POINTER) (E73613336)));
    }
    else
    {
       _b0 = E73580568 (&_mf, _a0, _a1);
    }
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73613336 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73613336
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E73605144 (&_mf, _a0, _a1);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E73629720 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
POINTER       _a2;

{
#ifndef EDCR73629720


    ++RTMM_stop;
    RTC11_ecopy (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73637912 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73637912
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = E68796440 (&_mf, _a0, _a0);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E73646104 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73646104


    ++RTMM_stop;
    RTC11_copy (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73662488 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR73662488
    BOOLEAN             _b0;
    OBJREF              _o [1];
    RTF                 _mf;

    _b0 = false;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _b0 = _a1 == (VOIDREF) & _a2 == (VOIDREF) || _a1 != (VOIDREF) & _a2 != (VOIDREF) && ((*FE68821003(_a1))(&_mf, _a1, _a2));
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73678872 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73678872
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC11_clone (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73695256 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73695256
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC11_deep_is_equal (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73719832 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR73719832
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = _a1 == (VOIDREF) & _a2 == (VOIDREF) || _a1 != (VOIDREF) & _a2 != (VOIDREF) && E73695256 (&_mf, _a1, _a2);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E73728024 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73728024
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    (*FE69632024(_a0))(&_mf, _a0, _o [0] = E73736216 (&_mf, _a0, _a1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73736216 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73736216
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    if (_a1 != (VOIDREF))
    {
       _o [0] = E73752600 (&_mf, _a0, _a1);
    }
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73752600 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73752600
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC11_deep_clone (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E73777176 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR73777176
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC11_conforms_to (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E73801752 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73801752
/* LEAF */

    if (Eonce [1])
        return ;
    Eonce [1] = true;


#endif
}
/*------------------------------------------------------------------*/

void    ECR24 (obj)

ECA_general  *obj;

{
}
/*------------------------------------------------------------------*/

void    ST24 (d)

INTEGER d;

{
    ECA_general  p;
    ECDESC  *cd = &ECD_general, *ecd = &EECD_general;

    cd->f1          = (INTEGER) 24;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_general);
    cd->f12         = "general";
    cd->f6          = false;
    cd->f13         = ECR24;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ";
    (cd->f21)       = (INTEGER *) 0;
    (cd->f22)       = (char **) 0;
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) 0;
    cd->f9          = &EECD_general;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

