/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H4.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_real_ref;
extern  ECDESC        EECD_real_ref;
ECDESC                ECD_real;
ECDESC                EECD_real;
/*------------------------------------------------------------------*/

extern  REAL          RTC9_power ();
/*------------------------------------------------------------------*/

REAL                  E67182596 ();
REAL                  E67190788 ();
REAL                  E67887108 ();
REAL                  E67895300 ();
REAL                  E67903492 ();
REAL                  E67936260 ();
BOOLEAN               E67977220 ();
INTEGER               E69378052 ();
REAL                  E69394436 ();
REAL                  E69402628 ();
BOOLEAN               E69566468 ();
/*------------------------------------------------------------------*/

REAL          E67182596 (_cf, _a0)

RTF           *_cf;
REAL          _a0;

{
#ifndef EDCR67182596
    REAL                _r0;
/* LEAF */

    _r0 = 0.0;

    _r0 = _a0;
    return _r0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E67190788 (_cf, _a0)

RTF           *_cf;
REAL          _a0;

{
#ifndef EDCR67190788
    REAL                _r0;
/* LEAF */

    _r0 = 0.0;

    return _r0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E67887108 (_cf, _a0, _a1)

RTF           *_cf;
REAL          _a0;
REAL          _a1;

{
#ifndef EDCR67887108
    REAL                _r0;
/* LEAF */

    _r0 = 0.0;

    return _r0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E67895300 (_cf, _a0, _a1)

RTF           *_cf;
REAL          _a0;
REAL          _a1;

{
#ifndef EDCR67895300
    REAL                _r0;
/* LEAF */

    _r0 = 0.0;

    return _r0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E67903492 (_cf, _a0, _a1)

RTF           *_cf;
REAL          _a0;
REAL          _a1;

{
#ifndef EDCR67903492
    REAL                _r0;
/* LEAF */

    _r0 = 0.0;

    return _r0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E67936260 (_cf, _a0, _a1)

RTF           *_cf;
REAL          _a0;
REAL          _a1;

{
#ifndef EDCR67936260
    REAL                _r0;
/* LEAF */

    _r0 = 0.0;

    return _r0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E67977220 (_cf, _a0, _a1)

RTF           *_cf;
REAL          _a0;
REAL          _a1;

{
#ifndef EDCR67977220
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    return _b0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E68034564 (_cf, _a0, _a1)

RTF           *_cf;
REAL          _a0;
INTEGER       _a1;

{
#ifndef EDCR68034564
    REAL  _res;


    ++RTMM_stop;
    _res = RTC9_power (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69378052 (_cf, _a0, _a1)

RTF           *_cf;
REAL          _a0;
REAL          _a1;

{
#ifndef EDCR69378052
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    if (_a0 < _a1)
    {
       _i0 = ((INTEGER) -1);
    }
    else
    {
       if (_a0 > _a1)
       {
          _i0 = ((INTEGER) 1);
       }
    }
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E69394436 (_cf, _a0)

RTF           *_cf;
REAL          _a0;

{
#ifndef EDCR69394436
    REAL                _r0;
/* LEAF */

    _r0 = 0.0;

    _r0 = ((REAL) 1.0);
    return _r0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E69402628 (_cf, _a0)

RTF           *_cf;
REAL          _a0;

{
#ifndef EDCR69402628
    REAL                _r0;
/* LEAF */

    _r0 = 0.0;

    _r0 = ((REAL) 0.0);
    return _r0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E69566468 (_cf, _a0, _a1)

RTF           *_cf;
REAL          _a0;
REAL          _a1;

{
#ifndef EDCR69566468
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = _a1 != ((REAL) 0.0);
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void    ECR4 (obj)

ECA_real  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST4 (d)

INTEGER d;

{
    ECA_real  p;
    ECDESC  *cd = &ECD_real, *ecd = &EECD_real;

    cd->f1          = (INTEGER) 4;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_real);
    cd->f12         = "real";
    cd->f6          = false;
    cd->f13         = ECR4;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " r";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eitem)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "item";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_real_ref;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_real;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

