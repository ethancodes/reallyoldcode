/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H6.h"
#include             "H73.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD__i_es3_spec;
extern  ECDESC        EECD__i_es3_spec;
ECDESC                ECD__i_array;
ECDESC                EECD__i_array;
/*------------------------------------------------------------------*/

extern  void          E67125321 ();
extern  POINTER       E70631497 ();
extern  BOOLEAN       E68821065 ();
extern  INTEGER       E69001289 ();
extern  void          E70500425 ();
extern  void          E69632073 ();
extern  void          E69836873 ();
extern  void          E70541385 ();
extern  void          E69918793 ();
extern  BOOLEAN       E70656073 ();
/*------------------------------------------------------------------*/

void                  E67125254 ();
BOOLEAN               E68820998 ();
INTEGER               E68960262 ();
INTEGER               E69001222 ();
void                  E69181446 ();
INTEGER               E73973766 ();
void                  E69918726 ();
void                  E69632006 ();
void                  E69836806 ();
void                  E69877766 ();
void                  E69894150 ();
BOOLEAN               E70025222 ();
INTEGER               E70057990 ();
POINTER               E70066182 ();
INTEGER               E70492166 ();
BOOLEAN               E70656006 ();
void                  E73949190 ();
void                  E73981958 ();
void                  E73990150 ();
void                  E74006534 ();
OBJREF                E74055686 ();
/*------------------------------------------------------------------*/

void          E67125254 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA6(_a0)->Especial = RTMM_create (&ECD__i_es3_spec);
    E67125321 (&_mf, EA6(_a0)->Especial, ((INTEGER) 1) + (_a2 - _a1));
    EA6(_a0)->Elower = _a1;
    EA6(_a0)->Estore = E70631497 (&_mf, EA6(_a0)->Especial, _a1);
    RTF_return;
}
/*------------------------------------------------------------------*/

void          _i_array_make (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E67125254 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

BOOLEAN       E68820998 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68820998
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = EA6(_a0)->Elower == EA6(_a1)->Elower && E68821065 (&_mf, EA6(_a0)->Especial, EA6(_a1)->Especial);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E68960262 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68960262
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = EA73(EA6(_a0)->Especial)->Ecount;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69001222 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69001222
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = ((INTEGER *)(EA73(EA6(_a0)->Especial)->Estore))[_a1 - EA6(_a0)->Elower];
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void          E69181446 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69181446
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    if (_a1 < E73973766 (&_mf, _a0))
    {
       E69918726 (&_mf, _a0, ((INTEGER) 1) + _a1, E73973766 (&_mf, _a0), -((INTEGER) 1));
    }
    else
    {
       _i0 = E68960262 (&_mf, _a0) - ((INTEGER) 1);
       E70500425 (&_mf, EA6(_a0)->Especial, _i0, _i0);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69632006 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69632006
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (EA6(_a0)->Especial == (VOIDREF))
    {
       EA6(_a0)->Especial = RTMM_create (&ECD__i_es3_spec);
       E67125321 (&_mf, EA6(_a0)->Especial, ((INTEGER) 0));
    }
    E69632073 (&_mf, EA6(_a0)->Especial, EA6(_a1)->Especial);
    EA6(_a0)->Elower = EA6(_a1)->Elower;
    EA6(_a0)->Estore = E70631497 (&_mf, EA6(_a0)->Especial, EA6(_a0)->Elower);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69836806 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69836806
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    ((INTEGER *)(EA73(EA6(_a0)->Especial)->Estore))[_a2 - EA6(_a0)->Elower] = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69877766 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69877766
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = ((INTEGER) 1) + (_a2 - _a1);
    E70541385 (&_mf, EA6(_a0)->Especial, _i0, EA6(_a0)->Elower - _a1);
    EA6(_a0)->Estore = E70631497 (&_mf, EA6(_a0)->Especial, _a1);
    EA6(_a0)->Elower = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69894150 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69894150
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (_a2 < E73973766 (&_mf, _a0) - ((INTEGER) 1))
    {
       E69918726 (&_mf, _a0, ((INTEGER) 1) + _a2, E73973766 (&_mf, _a0) - ((INTEGER) 1), ((INTEGER) 1));
    }
    ((INTEGER *)(EA6(_a0)->Estore))[((INTEGER) 1) + _a2] = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69918726 (_cf, _a0, _a1, _a2, _a3)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;
INTEGER       _a3;

{
#ifndef EDCR69918726
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69918793 (&_mf, EA6(_a0)->Especial, _a1 - EA6(_a0)->Elower, _a2 - EA6(_a0)->Elower, _a3);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70025222 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70025222
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E68960262 (&_mf, _a0) == ((INTEGER) 0);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E70057990 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70057990
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = ((INTEGER *)(EA73(EA6(_a0)->Especial)->Estore))[_a1 - EA6(_a0)->Elower];
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

POINTER       E70066182 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
    POINTER             _p0;
/* LEAF */

    _p0 = (POINTER) 0;

    _p0 = EA73(EA6(_a0)->Especial)->Estore;
    return _p0;
}
/*------------------------------------------------------------------*/

POINTER       _i_array_to_external (_a0)

OBJREF        _a0;

{
    RTF    _df;

    return E70066182 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

INTEGER       E70492166 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70492166
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = EA73(EA6(_a0)->Especial)->Ecount;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70656006 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70656006
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E70656073 (&_mf, EA6(_a0)->Especial);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E73949190 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR73949190
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA6(_a0)->Elower = _a1;
    EA6(_a0)->Estore = E70631497 (&_mf, EA6(_a0)->Especial, _a1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E73973766 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73973766
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = (EA73(EA6(_a0)->Especial)->Ecount + EA6(_a0)->Elower) - ((INTEGER) 1);
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void          E73981958 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73981958
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E70500425 (&_mf, EA6(_a0)->Especial, ((INTEGER) 0), E68960262 (&_mf, _a0) - ((INTEGER) 1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E73990150 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73990150
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69877766 (&_mf, _a0, EA6(_a0)->Elower, EA6(_a0)->Elower - ((INTEGER) 1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E74006534 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR74006534
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (_a2 < EA6(_a0)->Elower)
    {
       E69877766 (&_mf, _a0, _a2, E73973766 (&_mf, _a0));
    }
    else
    {
       if (_a2 > E73973766 (&_mf, _a0))
       {
          E69877766 (&_mf, _a0, EA6(_a0)->Elower, _a2);
       }
    }
    ((INTEGER *)(EA6(_a0)->Estore))[_a2] = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E74055686 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    EA6(_a0)->Estore = E70631497 (&_mf, EA6(_a0)->Especial, EA6(_a0)->Elower);
    _o [0] = EA6(_a0)->Especial;
    RTF_return;
    return _o [0];
}
/*------------------------------------------------------------------*/

OBJREF        _i_array_ra_es3_spec (_a0)

OBJREF        _a0;

{
    RTF    _df;

    return E74055686 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void    ECR6 (obj)

ECA__i_array  *obj;

{

    obj->Especial = VOIDREF;
    obj->Estore = (POINTER) 0;
}
/*------------------------------------------------------------------*/

void    ST6 (d)

INTEGER d;

{
    ECA__i_array  p;
    ECDESC  *cd = &ECD__i_array, *ecd = &EECD__i_array;

    cd->f1          = (INTEGER) 6;
    cd->f2          = d;
    cd->f3          = sizeof (ECA__i_array);
    cd->f12         = "_i_array";
    cd->f6          = false;
    cd->f13         = ECR6;
    cd->f14         = RT_null;
    cd->f15         = E74055686;
    cd->f20         = (char *) " iop";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 3) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Elower)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Especial)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Estore)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 3) * sizeof (char *));
    (cd->f22) [0]   = (char *) "lower";
    (cd->f22) [1]   = (char *) "special";
    (cd->f22) [2]   = (char *) "store";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Especial)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD__i_array;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

