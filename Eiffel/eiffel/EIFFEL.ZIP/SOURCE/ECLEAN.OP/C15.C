/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H15.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_character;
extern  ECDESC        EECD_character;
extern  ECDESC        ECD_comparable;
extern  ECDESC        EECD_comparable;
ECDESC                ECD_character_ref;
ECDESC                EECD_character_ref;
/*------------------------------------------------------------------*/

extern  INTEGER       (*FE69476367()) ();
/*------------------------------------------------------------------*/

extern  CHARACTER     E68812802 ();
extern  INTEGER       E69476354 ();
extern  CHARACTER     E69484546 ();
/*------------------------------------------------------------------*/

void                  E67125263 ();
BOOLEAN               E67977231 ();
OBJREF                E68812815 ();
INTEGER               E69378063 ();
INTEGER               E69476367 ();
OBJREF                E69484559 ();
/*------------------------------------------------------------------*/

void          E67125263 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;

{
#ifndef EDCR67125263
/* LEAF */


    EA15(_a0)->Eitem = _a1;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E67977231 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67977231
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = EA15(_a0)->Eitem < EA15(_a1)->Eitem;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68812815 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68812815
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_character_ref);
    E67125263 (&_mf, _o [0], E68812802 (&_mf, EA15(_a0)->Eitem));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69378063 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69378063
    register INTEGER    _i0;
    OBJREF              _o [2];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _i0 = ((*FE69476367(_a0))(&_mf, _a0)) - ((*FE69476367(_a1))(&_mf, _a1));
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69476367 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69476367
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = E69476354 (&_mf, EA15(_a0)->Eitem);
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69484559 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69484559
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_character_ref);
    E67125263 (&_mf, _o [0], E69484546 (&_mf, EA15(_a0)->Eitem));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void    ECR15 (obj)

ECA_character_ref  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST15 (d)

INTEGER d;

{
    ECA_character_ref  p;
    ECDESC  *cd = &ECD_character_ref, *ecd = &EECD_character_ref;

    cd->f1          = (INTEGER) 15;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_character_ref);
    cd->f12         = "character_ref";
    cd->f6          = false;
    cd->f13         = ECR15;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " c";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eitem)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "item";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_comparable;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_character_ref;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

