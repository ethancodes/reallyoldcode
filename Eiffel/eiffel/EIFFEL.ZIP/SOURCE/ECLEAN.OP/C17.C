/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H17.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_string;
extern  ECDESC        EECD_string;
ECDESC                ECD_environment;
ECDESC                EECD_environment;
/*------------------------------------------------------------------*/

extern  INTEGER       RTC5_arg_count ();
extern  OBJREF        RTC5E_arg_item ();
extern  OBJREF        RTC5E_program_name ();
extern  POINTER       E70066210 ();
extern  OBJREF        RTC5E_env_item ();
extern  void          RTC5E_env_put ();
/*------------------------------------------------------------------*/

OBJREF                E72122385 ();
OBJREF                E72146961 ();
void                  E72155153 ();
void                  E72179729 ();
/*------------------------------------------------------------------*/

INTEGER       E68788241 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68788241
    INTEGER  _res;


    ++RTMM_stop;
    _res = RTC5_arg_count ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E68804625 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR68804625
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC5E_arg_item (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E72106001 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72106001
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC5E_program_name ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E72122385 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72122385
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _o [0] = E72146961 (&_mf, _a0, E70066210 (&_mf, _a1));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E72146961 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR72146961
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC5E_env_item (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E72155153 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;

{
#ifndef EDCR72155153
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    E72179729 (&_mf, _a0, E70066210 (&_mf, _a1), E70066210 (&_mf, _a2));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72179729 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR72179729


    ++RTMM_stop;
    RTC5E_env_put (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void    ECR17 (obj)

ECA_environment  *obj;

{
}
/*------------------------------------------------------------------*/

void    ST17 (d)

INTEGER d;

{
    ECA_environment  p;
    ECDESC  *cd = &ECD_environment, *ecd = &EECD_environment;

    cd->f1          = (INTEGER) 17;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_environment);
    cd->f12         = "environment";
    cd->f6          = false;
    cd->f13         = ECR17;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ";
    (cd->f21)       = (INTEGER *) 0;
    (cd->f22)       = (char **) 0;
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_environment;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

