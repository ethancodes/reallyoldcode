/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H10.h"
#include             "H23.h"
#include             "H34.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_basic_io;
extern  ECDESC        EECD_basic_io;
extern  ECDESC        ECD_environment;
extern  ECDESC        EECD_environment;
extern  ECDESC        ECD_file_system;
extern  ECDESC        EECD_file_system;
extern  ECDESC        ECD_string;
extern  ECDESC        EECD_string;
ECDESC                ECD_eclean;
ECDESC                EECD_eclean;
/*------------------------------------------------------------------*/

extern  BOOLEAN       *VE68993067 ();
/*------------------------------------------------------------------*/

extern  void          E67125269 ();
extern  BOOLEAN       E68624405 ();
extern  void          E68640780 ();
extern  INTEGER       E68788241 ();
extern  OBJREF        E68804625 ();
extern  OBJREF        E68796440 ();
extern  void          E68812834 ();
extern  BOOLEAN       E68821026 ();
extern  OBJREF        E68976661 ();
extern  OBJREF        E68984853 ();
extern  OBJREF        E68943923 ();
extern  OBJREF        E69001267 ();
extern  OBJREF        E69017634 ();
extern  void          E69058581 ();
extern  void          E69099563 ();
extern  OBJREF        E69107733 ();
extern  BOOLEAN       E69115925 ();
extern  void          E69124117 ();
extern  OBJREF        E69189653 ();
extern  void          E69197858 ();
extern  BOOLEAN       E69230613 ();
extern  void          E69238796 ();
extern  void          E69263372 ();
extern  CHARACTER     E69271564 ();
extern  void          E69296149 ();
/*------------------------------------------------------------------*/

void                  E67125258 ();
void                  E68657162 ();
void                  E68673546 ();
void                  E68689930 ();
void                  E69042186 ();
void                  E69296138 ();
/*------------------------------------------------------------------*/

void          E67125258 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR67125258
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    EA10(_a0)->Eio = RTMM_create (&ECD_basic_io);
    EA10(_a0)->Efs = RTMM_create (&ECD_file_system);
    E67125269 (&_mf, EA10(_a0)->Efs);
    EA10(_a0)->Eenv = RTMM_create (&ECD_environment);
    if (!E68624405 (&_mf, EA10(_a0)->Efs, _o [0] = ELS8378))
    {
       E68640780 (&_mf, EA10(_a0)->Eio, _o [0] = ELS9095);
    }
    else
    {
       E68657162 (&_mf, _a0);
       if (EA10(_a0)->Eask_for_help)
       {
          E68673546 (&_mf, _a0);
       }
       else
       {
          E68640780 (&_mf, EA10(_a0)->Eio, _o [0] = ELS9096);
          E68689930 (&_mf, _a0);
       }
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          eclean_make (_a0)

OBJREF        _a0;

{
    RTF    _df;

    E67125258 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void          E68657162 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68657162
    register INTEGER    _i0;
    OBJREF              _o [2];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    EA10(_a0)->Econfirm = true;
    _i0 = ((INTEGER) 1);
    while (_i0 <= E68788241 (&_mf, EA10(_a0)->Eenv))
    {
       _o [0] = E68796440 (&_mf, _a0, _o [1] = E68804625 (&_mf, EA10(_a0)->Eenv, _i0));
       E68812834 (&_mf, _o [0]);
       if (E68821026 (&_mf, _o [0], _o [1] = ELS8402))
       {
          EA10(_a0)->Erecursively = true;
       }
       if (E68821026 (&_mf, _o [0], _o [1] = ELS8403))
       {
          EA10(_a0)->Elist_only = true;
       }
       if (E68821026 (&_mf, _o [0], _o [1] = ELS8404))
       {
          EA10(_a0)->Eask_for_help = true;
       }
       if (E68821026 (&_mf, _o [0], _o [1] = ELS8405))
       {
          EA10(_a0)->Econfirm = false;
       }
       _i0 += ((INTEGER) 1);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          eclean_analyze_commandline (_a0)

OBJREF        _a0;

{
    RTF    _df;

    E68657162 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void          E68673546 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68673546
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    E68640780 (&_mf, EA10(_a0)->Eio, _o [0] = ELS9097);
    E68640780 (&_mf, EA10(_a0)->Eio, _o [0] = ELS9098);
    E68640780 (&_mf, EA10(_a0)->Eio, _o [0] = ELS9099);
    E68640780 (&_mf, EA10(_a0)->Eio, _o [0] = ELS9100);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          eclean_help (_a0)

OBJREF        _a0;

{
    RTF    _df;

    E68673546 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void          E68689930 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68689930
    register INTEGER    _i0;
    OBJREF              _o [7];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = _o [1] = _o [2] = _o [3] = _o [4] = _o [5] = VOIDREF;
    _o [6] = VOIDREF;

    RTF_sl(7, _o, _cf);
    _o [4] = E68976661 (&_mf, EA10(_a0)->Efs);
    _o [1] = E68984853 (&_mf, EA10(_a0)->Efs, _o [5] = ELS8378);
    _o [2] = E68943923 (&_mf, _o [1]);
    while (!(*VE68993067(_o [2])))
    {
       _o [3] = EA23(E69001267 (&_mf, _o [1], _o [2]))->Ename;
       _i0 = EA34(_o [3])->Ecount;
       if (_i0 > ((INTEGER) 4) && E68821026 (&_mf, _o [5] = E69017634 (&_mf, _o [3], _i0 - ((INTEGER) 3), _i0), _o [6] = ELS8427))
       {
          E69042186 (&_mf, _a0, _o [5] = E69017634 (&_mf, _o [3], ((INTEGER) 1), _i0 - ((INTEGER) 4)));
       }
       if (E68821026 (&_mf, _o [3], _o [5] = ELS8429))
       {
          E69058581 (&_mf, EA10(_a0)->Efs, _o [3]);
       }
       if (E68821026 (&_mf, _o [3], _o [5] = ELS8431))
       {
          E69058581 (&_mf, EA10(_a0)->Efs, _o [3]);
       }
       if (E68821026 (&_mf, _o [3], _o [5] = ELS8432))
       {
          E69058581 (&_mf, EA10(_a0)->Efs, _o [3]);
       }
       if (E68821026 (&_mf, _o [3], _o [5] = ELS8433))
       {
          E69058581 (&_mf, EA10(_a0)->Efs, _o [3]);
       }
       if (E68821026 (&_mf, _o [3], _o [5] = ELS8434))
       {
          E69058581 (&_mf, EA10(_a0)->Efs, _o [3]);
       }
       E69099563 (&_mf, _o [2]);
    }
    if (EA10(_a0)->Erecursively)
    {
       _o [0] = E69107733 (&_mf, EA10(_a0)->Efs, _o [5] = ELS8378);
       _o [2] = E68943923 (&_mf, _o [0]);
       while (!(*VE68993067(_o [2])))
       {
          _o [3] = EA23(E69001267 (&_mf, _o [0], _o [2]))->Ename;
          if (E68624405 (&_mf, EA10(_a0)->Efs, _o [3]) && E69115925 (&_mf, EA10(_a0)->Efs, _o [3]))
          {
             E69124117 (&_mf, EA10(_a0)->Efs, _o [3]);
             E68689930 (&_mf, _a0);
             E69124117 (&_mf, EA10(_a0)->Efs, _o [4]);
          }
          E69099563 (&_mf, _o [2]);
       }
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          eclean_clean (_a0)

OBJREF        _a0;

{
    RTF    _df;

    E68689930 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void          E69042186 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69042186
    BOOLEAN             _b0, _b1;
    OBJREF              _o [5];
    RTF                 _mf;

    _b0 = _b1 = false;
    _o [0] = _o [1] = _o [2] = _o [3] = _o [4] = VOIDREF;

    RTF_sl(5, _o, _cf);
    _o [0] = E69189653 (&_mf, EA10(_a0)->Efs, _a1);
    _o [1] = E68796440 (&_mf, _a0, _a1);
    E69197858 (&_mf, _o [1], _o [4] = ELS8448);
    _o [2] = E68796440 (&_mf, _a0, _a1);
    E69197858 (&_mf, _o [2], _o [4] = ELS8449);
    _o [3] = E68796440 (&_mf, _a0, _a1);
    E69197858 (&_mf, _o [3], _o [4] = ELS8450);
    _b0 = (E69230613 (&_mf, EA10(_a0)->Efs, _o [1]) || E69230613 (&_mf, EA10(_a0)->Efs, _o [2])) || E69230613 (&_mf, EA10(_a0)->Efs, _o [3]);
    if (_b0)
    {
       if (EA10(_a0)->Elist_only)
       {
          E68640780 (&_mf, EA10(_a0)->Eio, _o [0]);
          E69238796 (&_mf, EA10(_a0)->Eio);
       }
       else
       {
          E68640780 (&_mf, EA10(_a0)->Eio, _o [4] = ELS8453);
          E68640780 (&_mf, EA10(_a0)->Eio, _o [0]);
          if (EA10(_a0)->Econfirm)
          {
             E68640780 (&_mf, EA10(_a0)->Eio, _o [4] = ELS8454);
             E69263372 (&_mf, EA10(_a0)->Eio);
             _b1 = E69271564 (&_mf, EA10(_a0)->Eio) == ((CHARACTER) 'Y') || E69271564 (&_mf, EA10(_a0)->Eio) == ((CHARACTER) 'y');
          }
          else
          {
             E69238796 (&_mf, EA10(_a0)->Eio);
             _b1 = true;
          }
          if (_b1)
          {
             E69296138 (&_mf, _a0, _o [1]);
             E69296138 (&_mf, _a0, _o [2]);
             E69296138 (&_mf, _a0, _o [3]);
          }
       }
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          eclean_remove_project (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    E69042186 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69296138 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69296138
    OBJREF              _o [4];
    RTF                 _mf;

    _o [0] = _o [1] = _o [2] = _o [3] = VOIDREF;

    RTF_sl(4, _o, _cf);
    if (E69230613 (&_mf, EA10(_a0)->Efs, _a1) && E69115925 (&_mf, EA10(_a0)->Efs, _a1))
    {
       E69124117 (&_mf, EA10(_a0)->Efs, _a1);
       _o [0] = E68984853 (&_mf, EA10(_a0)->Efs, _o [3] = ELS8378);
       _o [1] = E68943923 (&_mf, _o [0]);
       while (!(*VE68993067(_o [1])))
       {
          _o [2] = EA23(E69001267 (&_mf, _o [0], _o [1]))->Ename;
          E69058581 (&_mf, EA10(_a0)->Efs, _o [2]);
          E69099563 (&_mf, _o [1]);
       }
       E69124117 (&_mf, EA10(_a0)->Efs, _o [3] = ELS8461);
       E69296149 (&_mf, EA10(_a0)->Efs, _a1);
    }
    else
    {
       if (E69230613 (&_mf, EA10(_a0)->Efs, _a1))
       {
          E68640780 (&_mf, EA10(_a0)->Eio, _o [3] = ELS9101);
          E68640780 (&_mf, EA10(_a0)->Eio, _a1);
          E68640780 (&_mf, EA10(_a0)->Eio, _o [3] = ELS9102);
       }
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          eclean_remove_cluster (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    E69296138 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void    ECR10 (obj)

ECA_eclean  *obj;

{

    obj->Eenv = VOIDREF;
    obj->Efs = VOIDREF;
    obj->Eio = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST10 (d)

INTEGER d;

{
    ECA_eclean  p;
    ECDESC  *cd = &ECD_eclean, *ecd = &EECD_eclean;

    cd->f1          = (INTEGER) 10;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_eclean);
    cd->f12         = "eclean";
    cd->f6          = false;
    cd->f13         = ECR10;
    cd->f14         = E67125258;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " bbooobb";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 7) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eask_for_help)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Econfirm)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Eenv)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Efs)) - ((CHARACTER *) &p));
    (cd->f21) [4]   = (INTEGER) (((CHARACTER *) &(p.Eio)) - ((CHARACTER *) &p));
    (cd->f21) [5]   = (INTEGER) (((CHARACTER *) &(p.Elist_only)) - ((CHARACTER *) &p));
    (cd->f21) [6]   = (INTEGER) (((CHARACTER *) &(p.Erecursively)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 7) * sizeof (char *));
    (cd->f22) [0]   = (char *) "ask_for_help";
    (cd->f22) [1]   = (char *) "confirm";
    (cd->f22) [2]   = (char *) "env";
    (cd->f22) [3]   = (char *) "fs";
    (cd->f22) [4]   = (char *) "io";
    (cd->f22) [5]   = (char *) "list_only";
    (cd->f22) [6]   = (char *) "recursively";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 4) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Eenv)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) (((CHARACTER *) &(p.Efs)) - ((CHARACTER *) &p));
    (cd->f5) [2]    = (INTEGER) (((CHARACTER *) &(p.Eio)) - ((CHARACTER *) &p));
    (cd->f5) [3]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_eclean;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

