/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H23.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_real;
extern  ECDESC        EECD_real;
extern  ECDESC        ECD_comparable;
extern  ECDESC        EECD_comparable;
extern  ECDESC        ECD_file_system;
extern  ECDESC        EECD_file_system;
extern  ECDESC        ECD_string;
extern  ECDESC        EECD_string;
ECDESC                ECD_fsys_dat;
ECDESC                EECD_fsys_dat;
/*------------------------------------------------------------------*/

extern  BOOLEAN       E67977250 ();
extern  BOOLEAN       E71155733 ();
extern  REAL          E71360533 ();
extern  OBJREF        E71376917 ();
extern  INTEGER       E71442453 ();
extern  BOOLEAN       E69230613 ();
extern  REAL          E70959125 ();
extern  OBJREF        E70975509 ();
extern  INTEGER       E70869013 ();
/*------------------------------------------------------------------*/

void                  E67125271 ();
BOOLEAN               E67977239 ();
INTEGER               E68960279 ();
void                  E73146391 ();
REAL                  E73138199 ();
OBJREF                E73220119 ();
OBJREF                E73228311 ();
OBJREF                E73162775 ();
/*------------------------------------------------------------------*/

static  OBJREF        Eoonce [2];
static  BOOLEAN       Eonce [2];
/*------------------------------------------------------------------*/

void          E67125271 (_cf, _a0, _a1, _a2, _a3, _a4)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
OBJREF        _a2;
OBJREF        _a3;
BOOLEAN       _a4;

{
#ifndef EDCR67125271
/* LEAF */


    EA23(_a0)->Ename = _a1;
    EA23(_a0)->Epath = _a2;
    EA23(_a0)->Efilesys = _a3;
    EA23(_a0)->Eis_a_file = _a4;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E67977239 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67977239
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E67977250 (&_mf, EA23(_a0)->Epath, EA23(_a1)->Epath);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E68960279 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68960279
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    E73146391 (&_mf, _a0);
    _i0 = EA23(_a0)->Efcount;
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

REAL          E73138199 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73138199
    REAL                _r0;
    RTF                 _mf;

    _r0 = 0.0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    E73146391 (&_mf, _a0);
    _r0 = EA23(_a0)->Eftime;
    RTF_return;
    return _r0;
#endif
}
/*------------------------------------------------------------------*/

void          E73146391 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73146391
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (EA23(_a0)->Eis_a_file)
    {
       if (E71155733 (&_mf, EA23(_a0)->Efilesys, EA23(_a0)->Epath))
       {
          EA23(_a0)->Eftime = E71360533 (&_mf, EA23(_a0)->Efilesys, EA23(_a0)->Epath);
          EA23(_a0)->Efperm = E71376917 (&_mf, EA23(_a0)->Efilesys, EA23(_a0)->Epath);
          EA23(_a0)->Efcount = E71442453 (&_mf, EA23(_a0)->Efilesys, EA23(_a0)->Epath);
       }
       else
       {
          EA23(_a0)->Eftime = ((REAL) 0.0);
          EA23(_a0)->Efperm = E73220119 (&_mf, _a0);
          EA23(_a0)->Efcount = ((INTEGER) 0);
       }
    }
    else
    {
       if (E69230613 (&_mf, EA23(_a0)->Efilesys, EA23(_a0)->Epath))
       {
          EA23(_a0)->Eftime = E70959125 (&_mf, EA23(_a0)->Efilesys, EA23(_a0)->Epath);
          EA23(_a0)->Efperm = E70975509 (&_mf, EA23(_a0)->Efilesys, EA23(_a0)->Epath);
          EA23(_a0)->Efcount = E70869013 (&_mf, EA23(_a0)->Efilesys, EA23(_a0)->Epath);
       }
       else
       {
          EA23(_a0)->Eftime = ((REAL) 0.0);
          EA23(_a0)->Efperm = E73228311 (&_mf, _a0);
          EA23(_a0)->Efcount = ((INTEGER) 0);
       }
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73162775 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73162775
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    E73146391 (&_mf, _a0);
    _o [0] = EA23(_a0)->Efperm;
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73220119 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73220119
/* LEAF */

    if (Eonce [0])
        return Eoonce [0];
    Eonce [0] = true;

    Eoonce [0] = VOIDREF;  RTMM_protect ((OBJREF *) (Eoonce + 0), (INTEGER) 1);

    Eoonce [0] = ELS8940;
    return Eoonce [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E73228311 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73228311
/* LEAF */

    if (Eonce [1])
        return Eoonce [1];
    Eonce [1] = true;

    Eoonce [1] = VOIDREF;  RTMM_protect ((OBJREF *) (Eoonce + 1), (INTEGER) 1);

    Eoonce [1] = ELS8941;
    return Eoonce [1];
#endif
}
/*------------------------------------------------------------------*/

void    ECR23 (obj)

ECA_fsys_dat  *obj;

{

    obj->Efilesys = VOIDREF;
    obj->Efperm = VOIDREF;
    obj->Ename = VOIDREF;
    obj->Epath = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST23 (d)

INTEGER d;

{
    ECA_fsys_dat  p;
    ECDESC  *cd = &ECD_fsys_dat, *ecd = &EECD_fsys_dat;

    cd->f1          = (INTEGER) 23;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_fsys_dat);
    cd->f12         = "fsys_dat";
    cd->f6          = false;
    cd->f13         = ECR23;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ioorboo";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 7) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Efcount)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Efilesys)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Efperm)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Eftime)) - ((CHARACTER *) &p));
    (cd->f21) [4]   = (INTEGER) (((CHARACTER *) &(p.Eis_a_file)) - ((CHARACTER *) &p));
    (cd->f21) [5]   = (INTEGER) (((CHARACTER *) &(p.Ename)) - ((CHARACTER *) &p));
    (cd->f21) [6]   = (INTEGER) (((CHARACTER *) &(p.Epath)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 7) * sizeof (char *));
    (cd->f22) [0]   = (char *) "fcount";
    (cd->f22) [1]   = (char *) "filesys";
    (cd->f22) [2]   = (char *) "fperm";
    (cd->f22) [3]   = (char *) "ftime";
    (cd->f22) [4]   = (char *) "is_a_file";
    (cd->f22) [5]   = (char *) "name";
    (cd->f22) [6]   = (char *) "path";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 5) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Efilesys)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) (((CHARACTER *) &(p.Efperm)) - ((CHARACTER *) &p));
    (cd->f5) [2]    = (INTEGER) (((CHARACTER *) &(p.Ename)) - ((CHARACTER *) &p));
    (cd->f5) [3]    = (INTEGER) (((CHARACTER *) &(p.Epath)) - ((CHARACTER *) &p));
    (cd->f5) [4]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_comparable;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_fsys_dat;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

