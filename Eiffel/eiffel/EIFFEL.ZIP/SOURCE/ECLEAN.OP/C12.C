/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H12.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_character;
extern  ECDESC        EECD_character;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_real;
extern  ECDESC        EECD_real;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_string;
extern  ECDESC        EECD_string;
ECDESC                ECD_basic_io;
ECDESC                EECD_basic_io;
/*------------------------------------------------------------------*/

extern  POINTER       E70066210 ();
extern  void          RTC1_gchar ();
extern  CHARACTER     RTC1_lchar ();
extern  void          RTC1_pstring ();
extern  OBJREF        RTC1_lstring ();
extern  INTEGER       RTC1_lint ();
extern  REAL          RTC1_lreal ();
extern  BOOLEAN       RTC1_lbool ();
extern  void          RTC1_gstring ();
extern  void          RTC1_gint ();
extern  void          RTC1_greal ();
extern  void          RTC1_gbool ();
extern  void          RTC1_gnewline ();
extern  void          RTC1_pint ();
extern  void          RTC1_preal ();
extern  void          RTC1_pchar ();
extern  void          RTC1_pnewline ();
extern  BOOLEAN       RTC1_end_of_input ();
/*------------------------------------------------------------------*/

void                  E68640780 ();
void                  E70295564 ();
void                  E69238796 ();
void                  E72523788 ();
void                  E72433676 ();
void                  E72441868 ();
void                  E72450060 ();
void                  E72466444 ();
void                  E72474636 ();
void                  E72491020 ();
void                  E72507404 ();
void                  E72515596 ();
void                  E72548364 ();
void                  E72564748 ();
/*------------------------------------------------------------------*/

void          E68640780 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68640780
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    E70295564 (&_mf, _a0, E70066210 (&_mf, _a1), EA12(_a0)->Eoutput_device);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69238796 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69238796
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72523788 (&_mf, _a0, EA12(_a0)->Eoutput_device);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69263372 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69263372


    ++RTMM_stop;
    RTC1_gchar ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

CHARACTER     E69271564 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69271564
    CHARACTER  _res;


    ++RTMM_stop;
    _res = RTC1_lchar ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E70295564 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70295564


    ++RTMM_stop;
    RTC1_pstring (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E72212492 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72212492
    OBJREF  _res;


    ++RTMM_stop;
    _res = RTC1_lstring ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E72228876 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72228876
    INTEGER  _res;


    ++RTMM_stop;
    _res = RTC1_lint ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

REAL          E72245260 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72245260
    REAL  _res;


    ++RTMM_stop;
    _res = RTC1_lreal ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

REAL          E72261644 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72261644
    REAL  _res;


    ++RTMM_stop;
    _res = RTC1_lreal ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E72269836 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72269836
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC1_lbool ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E72294412 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72294412


    ++RTMM_stop;
    RTC1_gstring ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72310796 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72310796


    ++RTMM_stop;
    RTC1_gint ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72335372 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72335372


    ++RTMM_stop;
    RTC1_greal ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72359948 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72359948


    ++RTMM_stop;
    RTC1_greal ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72376332 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72376332


    ++RTMM_stop;
    RTC1_gbool ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72409100 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72409100


    ++RTMM_stop;
    RTC1_gnewline ();
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72433676 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR72433676
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72441868 (&_mf, _a0, _a1, EA12(_a0)->Eoutput_device);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72441868 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR72441868


    ++RTMM_stop;
    RTC1_pint (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72450060 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
REAL          _a1;

{
#ifndef EDCR72450060
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72466444 (&_mf, _a0, _a1, EA12(_a0)->Eoutput_device);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72466444 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
REAL          _a1;
INTEGER       _a2;

{
#ifndef EDCR72466444


    ++RTMM_stop;
    RTC1_preal (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72474636 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
REAL          _a1;

{
#ifndef EDCR72474636
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72466444 (&_mf, _a0, _a1, EA12(_a0)->Eoutput_device);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72491020 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
BOOLEAN       _a1;

{
#ifndef EDCR72491020
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    if (_a1)
    {
       E68640780 (&_mf, _a0, _o [0] = ELS8395);
    }
    else
    {
       E68640780 (&_mf, _a0, _o [0] = ELS8406);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72507404 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;

{
#ifndef EDCR72507404
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72515596 (&_mf, _a0, _a1, EA12(_a0)->Eoutput_device);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E72515596 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
#ifndef EDCR72515596


    ++RTMM_stop;
    RTC1_pchar (_a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E72523788 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR72523788


    ++RTMM_stop;
    RTC1_pnewline (_a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E72531980 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72531980
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC1_end_of_input ();
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

void          E72548364 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72548364
/* LEAF */


    EA12(_a0)->Eoutput_device = ((INTEGER) 0);
#endif
}
/*------------------------------------------------------------------*/

void          E72564748 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72564748
/* LEAF */


    EA12(_a0)->Eoutput_device = ((INTEGER) 1);
#endif
}
/*------------------------------------------------------------------*/

void    ECR12 (obj)

ECA_basic_io  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST12 (d)

INTEGER d;

{
    ECA_basic_io  p;
    ECDESC  *cd = &ECD_basic_io, *ecd = &EECD_basic_io;

    cd->f1          = (INTEGER) 12;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_basic_io);
    cd->f12         = "basic_io";
    cd->f6          = false;
    cd->f13         = ECR12;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " i";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Eoutput_device)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "output_device";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_basic_io;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

