/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H39.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_general;
extern  ECDESC        EECD_general;
extern  ECDESC        ECD_traversable;
extern  ECDESC        EECD_traversable;
extern  ECDESC        ECD_g;
extern  ECDESC        EECD_g;
ECDESC                ECD_collection;
ECDESC                EECD_collection;
/*------------------------------------------------------------------*/

extern  BOOLEAN       *VE72728615 ();
extern  INTEGER       *VE68960295 ();
extern  BOOLEAN       *VE72736807 ();
extern  BOOLEAN       *VE68993067 ();
extern  OBJREF        *VE72876071 ();
/*------------------------------------------------------------------*/

extern  BOOLEAN       (*FE68821016()) ();
/*------------------------------------------------------------------*/

extern  OBJREF        E68943923 ();
extern  OBJREF        E69001267 ();
extern  void          E72990763 ();
extern  void          E69099563 ();
extern  BOOLEAN       E72679475 ();
/*------------------------------------------------------------------*/

void                  E67125287 ();
BOOLEAN               E70025255 ();
void                  E72646695 ();
/*------------------------------------------------------------------*/

void          E67125287 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
BOOLEAN       _a1;

{
#ifndef EDCR67125287
/* LEAF */


    *VE72728615(_a0) = _a1;
    *VE68960295(_a0) = ((INTEGER) 0);
    *VE72736807(_a0) = false;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70025255 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70025255
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = (*VE68960295(_a0)) == ((INTEGER) 0);
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E72646695 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR72646695
    OBJREF              _o [3];
    RTF                 _mf;
    BOOLEAN *_vpt0;

    _o [0] = _o [1] = _o [2] = VOIDREF;

    RTF_sl(3, _o, _cf);
    _vpt0 = VE72736807(_a0);
    _o [0] = E68943923 (&_mf, _a0);
    while (!(*VE68993067(_o [0])))
    {
       if ((*FE68821016(_a1))(&_mf, _a1, _o [1] = E69001267 (&_mf, _a0, _o [0])))
       {
          E72990763 (&_mf, _o [0]);
       }
       else
       {
          E69099563 (&_mf, _o [0]);
       }
    }
    (*_vpt0) = E72679475 (&_mf, _a0, _o [0]);
    if ((*_vpt0))
    {
       *VE72876071(_a0) = E69001267 (&_mf, _a0, _o [0]);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void    ECR39 (obj)

ECA_collection  *obj;

{

    obj->Efound_item = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST39 (d)

INTEGER d;

{
    ECA_collection  p;
    ECDESC  *cd = &ECD_collection, *ecd = &EECD_collection;

    cd->f1          = (INTEGER) 39;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_collection);
    cd->f12         = "collection";
    cd->f6          = false;
    cd->f13         = ECR39;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ibobi";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 5) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecount)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Efound)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Efound_item)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Eis_unique)) - ((CHARACTER *) &p));
    (cd->f21) [4]   = (INTEGER) (((CHARACTER *) &(p.En_iter)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 5) * sizeof (char *));
    (cd->f22) [0]   = (char *) "count";
    (cd->f22) [1]   = (char *) "found";
    (cd->f22) [2]   = (char *) "found_item";
    (cd->f22) [3]   = (char *) "is_unique";
    (cd->f22) [4]   = (char *) "n_iter";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Efound_item)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_traversable;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_collection;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

