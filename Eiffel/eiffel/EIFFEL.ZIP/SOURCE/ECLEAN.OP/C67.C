/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H67.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_twoway_iter;
extern  ECDESC        EECD_twoway_iter;
extern  ECDESC        ECD_twoway_traversable;
extern  ECDESC        EECD_twoway_traversable;
ECDESC                ECD_twi_iter;
ECDESC                EECD_twi_iter;
/*------------------------------------------------------------------*/

void                  E73039939 ();
/*------------------------------------------------------------------*/

void          E73039939 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR73039939
/* LEAF */


    EA67(_a0)->Ecursor = _a1;
#endif
}
/*------------------------------------------------------------------*/

void    ECR67 (obj)

ECA_twi_iter  *obj;

{

    obj->Epartner = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST67 (d)

INTEGER d;

{
    ECA_twi_iter  p;
    ECDESC  *cd = &ECD_twi_iter, *ecd = &EECD_twi_iter;

    cd->f1          = (INTEGER) 67;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_twi_iter);
    cd->f12         = "twi_iter";
    cd->f6          = false;
    cd->f13         = ECR67;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " ibbo";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 4) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecursor)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Efinished)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Elogged_in)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Epartner)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 4) * sizeof (char *));
    (cd->f22) [0]   = (char *) "cursor";
    (cd->f22) [1]   = (char *) "finished";
    (cd->f22) [2]   = (char *) "logged_in";
    (cd->f22) [3]   = (char *) "partner";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Epartner)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_twoway_iter;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_twi_iter;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

