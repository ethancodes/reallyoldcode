/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H65.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_iterator;
extern  ECDESC        EECD_iterator;
extern  ECDESC        ECD_twoway_traversable;
extern  ECDESC        EECD_twoway_traversable;
ECDESC                ECD_twoway_iter;
ECDESC                EECD_twoway_iter;
/*------------------------------------------------------------------*/

extern  OBJREF        *VE73261121 ();
/*------------------------------------------------------------------*/

extern  void          E72654899 ();
extern  void          E73269291 ();
extern  void          E72671283 ();
extern  BOOLEAN       E72679467 ();
extern  void          E73293867 ();
/*------------------------------------------------------------------*/

void                  E72654913 ();
void                  E74244161 ();
/*------------------------------------------------------------------*/

void          E72654913 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR72654913
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72654899 (&_mf, *VE73261121(_a0), _a0);
    E73269291 (&_mf, _a0);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E74244161 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR74244161
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E72671283 (&_mf, *VE73261121(_a0), _a0);
    if (!E72679467 (&_mf, _a0))
    {
       E73293867 (&_mf, _a0);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void    ECR65 (obj)

ECA_twoway_iter  *obj;

{

    obj->Epartner = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST65 (d)

INTEGER d;

{
    ECA_twoway_iter  p;
    ECDESC  *cd = &ECD_twoway_iter, *ecd = &EECD_twoway_iter;

    cd->f1          = (INTEGER) 65;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_twoway_iter);
    cd->f12         = "twoway_iter";
    cd->f6          = false;
    cd->f13         = ECR65;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " bbo";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 3) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Efinished)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Elogged_in)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Epartner)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 3) * sizeof (char *));
    (cd->f22) [0]   = (char *) "finished";
    (cd->f22) [1]   = (char *) "logged_in";
    (cd->f22) [2]   = (char *) "partner";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Epartner)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_iterator;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_twoway_iter;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

