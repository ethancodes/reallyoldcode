/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "H51.h"
#include             "H64.h"
/*------------------------------------------------------------------*/

/*------------------------------------------------------------------*/

INTEGER       *VE74121280 (Current)

OBJREF    Current;

{
    register int    cnr;
    static   OBJREF lobj = (OBJREF) 0;
    static   INTEGER *lres;

    cnr = (int) (ECNR (Current));

    if (Current == lobj)
        return lres;

    if (cnr)
        lobj = Current;
    else
        RTC4_raise ((CHARACTER *) "traversable.n_iter", (CHARACTER *) "", VOID_CALL_TARGET, VOIDREF);

    if (cnr == 64)
        return (lres = &(EA64(Current)->En_iter));

    return (lres = &(EA51(Current)->En_iter));
}
/*------------------------------------------------------------------*/

