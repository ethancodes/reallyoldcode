/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H34.h"
#include             "H72.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_character;
extern  ECDESC        EECD_character;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_comparable;
extern  ECDESC        EECD_comparable;
extern  ECDESC        ECD_hashable;
extern  ECDESC        EECD_hashable;
extern  ECDESC        ECD__c_es3_spec;
extern  ECDESC        EECD__c_es3_spec;
ECDESC                ECD_string;
ECDESC                EECD_string;
/*------------------------------------------------------------------*/

extern  void          E67125320 ();
extern  void          E69984328 ();
extern  BOOLEAN       E68821064 ();
extern  CHARACTER     E69001288 ();
extern  POINTER       E70099016 ();
extern  void          E69795912 ();
extern  void          E69918792 ();
extern  void          E69877832 ();
extern  void          E69632072 ();
extern  void          E69673032 ();
extern  void          E69836872 ();
extern  void          RTC2_to_upper ();
extern  void          RTC2_to_lower ();
extern  INTEGER       RTC2_hash ();
extern  BOOLEAN       RTC2_less ();
extern  INTEGER       RTC2_compare ();
/*------------------------------------------------------------------*/

void                  E67125282 ();
void                  E69672994 ();
BOOLEAN               E67977250 ();
BOOLEAN               E70041634 ();
void                  E68812834 ();
void                  E70008866 ();
BOOLEAN               E68821026 ();
CHARACTER             E69001250 ();
OBJREF                E69017634 ();
void                  E69181474 ();
void                  E69197858 ();
INTEGER               E69378082 ();
INTEGER               E70049826 ();
INTEGER               E69386274 ();
INTEGER               E70033442 ();
void                  E69484578 ();
void                  E69992482 ();
void                  E69632034 ();
void                  E69640226 ();
void                  E69820450 ();
void                  E69836834 ();
void                  E69894178 ();
void                  E69951522 ();
void                  E69967906 ();
BOOLEAN               E70025250 ();
CHARACTER             E70058018 ();
POINTER               E70066210 ();
void                  E70107170 ();
/*------------------------------------------------------------------*/

void          E67125282 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA34(_a0)->Especial = RTMM_create (&ECD__c_es3_spec);
    E67125320 (&_mf, EA34(_a0)->Especial, ((INTEGER) 1) + _a1);
    EA34(_a0)->Ecount = _a1;
    E69672994 (&_mf, _a0, ((CHARACTER) ' '));
    RTF_return;
}
/*------------------------------------------------------------------*/

void          string_make (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E67125282 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

BOOLEAN       E67977250 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR67977250
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E70041634 (&_mf, _a0, EA72(EA34(_a0)->Especial)->Estore, EA72(EA34(_a1)->Especial)->Estore);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E68812834 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68812834
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69984328 (&_mf, EA34(_a0)->Especial);
    E70008866 (&_mf, _a0, EA72(EA34(_a0)->Especial)->Estore);
    EA34(_a0)->Eh_code = ((INTEGER) -1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E68821026 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68821026
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = EA34(_a0)->Ecount == EA34(_a1)->Ecount && E68821064 (&_mf, EA34(_a0)->Especial, EA34(_a1)->Especial);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

CHARACTER     E69001250 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69001250
    CHARACTER           _c0;
    RTF                 _mf;

    _c0 = '\0';

    RTF_sl(0, (OBJREF *) 0, _cf);
    _c0 = ((CHARACTER *)(EA72(EA34(_a0)->Especial)->Estore))[_a1 - ((INTEGER) 1)];
    RTF_return;
    return _c0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69017634 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69017634
    OBJREF              _o [2];
    RTF                 _mf;

    _o [0] = _o [1] = VOIDREF;

    RTF_sl(2, _o, _cf);
    _o [0] = RTMM_create (&ECD_string);
    E67125282 (&_mf, _o [0], ((INTEGER) 1) + (_a2 - _a1));
    E69795912 (&_mf, EA34(_o [0])->Especial, E70099016 (&_mf, EA34(_a0)->Especial, _a1 - ((INTEGER) 1), _a2 - ((INTEGER) 1)), ((INTEGER) 0));
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E69181474 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69181474
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69918792 (&_mf, EA34(_a0)->Especial, _a1, EA34(_a0)->Ecount, -((INTEGER) 1));
    E69877832 (&_mf, EA34(_a0)->Especial, EA34(_a0)->Ecount);
    EA34(_a0)->Ecount -= ((INTEGER) 1);
    EA34(_a0)->Eh_code = ((INTEGER) -1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69197858 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69197858
    register INTEGER    _i0;
    OBJREF              _o [1];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    if (EA34(_a1)->Ecount != ((INTEGER) 0))
    {
       _i0 = EA34(_a0)->Ecount + EA34(_a1)->Ecount;
       _o [0] = RTMM_create (&ECD__c_es3_spec);
       E67125320 (&_mf, _o [0], ((INTEGER) 1) + _i0);
       if (EA34(_a0)->Ecount != ((INTEGER) 0))
       {
          E69795912 (&_mf, _o [0], EA72(EA34(_a0)->Especial)->Estore, ((INTEGER) 0));
       }
       E69795912 (&_mf, _o [0], EA72(EA34(_a1)->Especial)->Estore, EA34(_a0)->Ecount);
       EA34(_a0)->Especial = _o [0];
       EA34(_a0)->Ecount = _i0;
       EA34(_a0)->Eh_code = ((INTEGER) -1);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69378082 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69378082
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = E70049826 (&_mf, _a0, EA72(EA34(_a0)->Especial)->Estore, EA72(EA34(_a1)->Especial)->Estore);
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E69386274 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69386274
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    if (EA34(_a0)->Eh_code == ((INTEGER) -1))
    {
       EA34(_a0)->Eh_code = E70033442 (&_mf, _a0, EA72(EA34(_a0)->Especial)->Estore);
    }
    _i0 = EA34(_a0)->Eh_code;
    RTF_return;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void          E69484578 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69484578
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69984328 (&_mf, EA34(_a0)->Especial);
    E69992482 (&_mf, _a0, EA72(EA34(_a0)->Especial)->Estore);
    EA34(_a0)->Eh_code = ((INTEGER) -1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69632034 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69632034
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (EA34(_a0)->Especial == (VOIDREF))
    {
       EA34(_a0)->Especial = RTMM_create (&ECD__c_es3_spec);
       E67125320 (&_mf, EA34(_a0)->Especial, ((INTEGER) 0));
    }
    E69632072 (&_mf, EA34(_a0)->Especial, EA34(_a1)->Especial);
    EA34(_a0)->Ecount = EA34(_a1)->Ecount;
    EA34(_a0)->Eh_code = ((INTEGER) -1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69640226 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69640226
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA34(_a0)->Especial = RTMM_create (&ECD__c_es3_spec);
    E67125320 (&_mf, EA34(_a0)->Especial, ((INTEGER) 0));
    E69632072 (&_mf, EA34(_a0)->Especial, EA34(_a1)->Especial);
    EA34(_a0)->Ecount = EA34(_a1)->Ecount;
    EA34(_a0)->Eh_code = ((INTEGER) -1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69672994 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;

{
#ifndef EDCR69672994
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69673032 (&_mf, EA34(_a0)->Especial, _a1, EA34(_a0)->Ecount);
    EA34(_a0)->Eh_code = ((INTEGER) -1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69820450 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69820450
    register INTEGER    _i0;
    OBJREF              _o [1];
    RTF                 _mf;

    _i0 = 0;
    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    if (EA34(_a1)->Ecount != ((INTEGER) 0))
    {
       _i0 = EA34(_a0)->Ecount + EA34(_a1)->Ecount;
       _o [0] = RTMM_create (&ECD__c_es3_spec);
       E67125320 (&_mf, _o [0], ((INTEGER) 1) + _i0);
       E69795912 (&_mf, _o [0], EA72(EA34(_a1)->Especial)->Estore, ((INTEGER) 0));
       if (EA34(_a0)->Ecount != ((INTEGER) 0))
       {
          E69795912 (&_mf, _o [0], EA72(EA34(_a0)->Especial)->Estore, EA34(_a1)->Ecount);
       }
       EA34(_a0)->Especial = _o [0];
       EA34(_a0)->Ecount = _i0;
       EA34(_a0)->Eh_code = ((INTEGER) -1);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69836834 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
#ifndef EDCR69836834
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    if (_a1 == '\0')
    {
       E69877832 (&_mf, EA34(_a0)->Especial, ((INTEGER) 1) + _a2);
       EA34(_a0)->Ecount = _a2;
    }
    ((CHARACTER *)(EA72(EA34(_a0)->Especial)->Estore))[_a2 - ((INTEGER) 1)] = _a1;
    EA34(_a0)->Eh_code = ((INTEGER) -1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69894178 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
#ifndef EDCR69894178
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69877832 (&_mf, EA34(_a0)->Especial, ((INTEGER) 2) + EA34(_a0)->Ecount);
    E69918792 (&_mf, EA34(_a0)->Especial, _a2, EA34(_a0)->Ecount, ((INTEGER) 1));
    EA34(_a0)->Ecount += ((INTEGER) 1);
    E69836834 (&_mf, _a0, _a1, ((INTEGER) 1) + _a2);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69951522 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;

{
#ifndef EDCR69951522
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69894178 (&_mf, _a0, _a1, EA34(_a0)->Ecount);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69967906 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;

{
#ifndef EDCR69967906
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69894178 (&_mf, _a0, _a1, ((INTEGER) 0));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69992482 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR69992482


    ++RTMM_stop;
    RTC2_to_upper (_a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          E70008866 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR70008866


    ++RTMM_stop;
    RTC2_to_lower (_a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70025250 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70025250
    BOOLEAN             _b0;
/* LEAF */

    _b0 = false;

    _b0 = EA34(_a0)->Ecount == ((INTEGER) 0);
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E70033442 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;

{
#ifndef EDCR70033442
    INTEGER  _res;


    ++RTMM_stop;
    _res = RTC2_hash (_a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70041634 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR70041634
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC2_less (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E70049826 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
POINTER       _a2;

{
#ifndef EDCR70049826
    INTEGER  _res;


    ++RTMM_stop;
    _res = RTC2_compare (_a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

CHARACTER     E70058018 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70058018
    CHARACTER           _c0;
    RTF                 _mf;

    _c0 = '\0';

    RTF_sl(0, (OBJREF *) 0, _cf);
    _c0 = ((CHARACTER *)(EA72(EA34(_a0)->Especial)->Estore))[_a1 - ((INTEGER) 1)];
    RTF_return;
    return _c0;
#endif
}
/*------------------------------------------------------------------*/

POINTER       E70066210 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
    POINTER             _p0;
/* LEAF */

    _p0 = (POINTER) 0;

    _p0 = EA72(EA34(_a0)->Especial)->Estore;
    return _p0;
}
/*------------------------------------------------------------------*/

POINTER       string_to_external (_a0)

OBJREF        _a0;

{
    RTF    _df;

    return E70066210 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void          E70107170 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
/* LEAF */


    EA34(_a0)->Especial = _a1;
    EA34(_a0)->Ecount = EA72(_a1)->Ecount - ((INTEGER) 1);
    EA34(_a0)->Eh_code = ((INTEGER) -1);
}
/*------------------------------------------------------------------*/

void          string_set_special (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    E70107170 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void    ECR34 (obj)

ECA_string  *obj;

{

    obj->Especial = VOIDREF;
}
/*------------------------------------------------------------------*/

void    ST34 (d)

INTEGER d;

{
    ECA_string  p;
    ECDESC  *cd = &ECD_string, *ecd = &EECD_string;

    cd->f1          = (INTEGER) 34;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_string);
    cd->f12         = "string";
    cd->f6          = false;
    cd->f13         = ECR34;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " iio";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 3) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecount)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Eh_code)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Especial)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 3) * sizeof (char *));
    (cd->f22) [0]   = (char *) "count";
    (cd->f22) [1]   = (char *) "h_code";
    (cd->f22) [2]   = (char *) "special";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Especial)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 4) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = &ECD_comparable;
    (cd->f8) [2]    = &ECD_hashable;
    (cd->f8) [3]    = (ECDESC *) 0;
    cd->f9          = &EECD_string;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

