/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H5.h"
#include             "H18.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_es3_spec;
extern  ECDESC        EECD_es3_spec;
extern  ECDESC        ECD_general;
extern  ECDESC        EECD_general;
ECDESC                ECD_array;
ECDESC                EECD_array;
/*------------------------------------------------------------------*/

extern  void          E67125266 ();
extern  POINTER       E70631442 ();
extern  BOOLEAN       E68821010 ();
extern  OBJREF        E69001234 ();
extern  void          E70500370 ();
extern  void          E69632018 ();
extern  void          E69836818 ();
extern  void          E70541330 ();
extern  void          E69918738 ();
extern  BOOLEAN       E70656018 ();
/*------------------------------------------------------------------*/

void                  E67125253 ();
BOOLEAN               E68820997 ();
INTEGER               E68960261 ();
OBJREF                E69001221 ();
void                  E69181445 ();
INTEGER               E73973765 ();
void                  E69918725 ();
void                  E69632005 ();
void                  E69836805 ();
void                  E69877765 ();
void                  E69894149 ();
BOOLEAN               E70025221 ();
OBJREF                E70057989 ();
POINTER               E70066181 ();
INTEGER               E70492165 ();
BOOLEAN               E70656005 ();
void                  E73949189 ();
void                  E73981957 ();
void                  E73990149 ();
void                  E74006533 ();
OBJREF                E74055685 ();
/*------------------------------------------------------------------*/

void          E67125253 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA5(_a0)->Especial = RTMM_create (&ECD_es3_spec);
    E67125266 (&_mf, EA5(_a0)->Especial, ((INTEGER) 1) + (_a2 - _a1));
    EA5(_a0)->Elower = _a1;
    EA5(_a0)->Estore = E70631442 (&_mf, EA5(_a0)->Especial, _a1);
    RTF_return;
}
/*------------------------------------------------------------------*/

void          array_make (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E67125253 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

BOOLEAN       E68820997 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68820997
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = EA5(_a0)->Elower == EA5(_a1)->Elower && E68821010 (&_mf, EA5(_a0)->Especial, EA5(_a1)->Especial);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E68960261 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68960261
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = EA18(EA5(_a0)->Especial)->Ecount;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E69001221 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69001221
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = ((OBJREF *)(EA18(EA5(_a0)->Especial)->Estore))[_a1 - EA5(_a0)->Elower];
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void          E69181445 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69181445
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    if (_a1 < E73973765 (&_mf, _a0))
    {
       E69918725 (&_mf, _a0, ((INTEGER) 1) + _a1, E73973765 (&_mf, _a0), -((INTEGER) 1));
    }
    else
    {
       _i0 = E68960261 (&_mf, _a0) - ((INTEGER) 1);
       E70500370 (&_mf, EA5(_a0)->Especial, _i0, _i0);
    }
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69632005 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69632005
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (EA5(_a0)->Especial == (VOIDREF))
    {
       EA5(_a0)->Especial = RTMM_create (&ECD_es3_spec);
       E67125266 (&_mf, EA5(_a0)->Especial, ((INTEGER) 0));
    }
    E69632018 (&_mf, EA5(_a0)->Especial, EA5(_a1)->Especial);
    EA5(_a0)->Elower = EA5(_a1)->Elower;
    EA5(_a0)->Estore = E70631442 (&_mf, EA5(_a0)->Especial, EA5(_a0)->Elower);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69836805 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;

{
#ifndef EDCR69836805
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    ((OBJREF *)(EA18(EA5(_a0)->Especial)->Estore))[_a2 - EA5(_a0)->Elower] = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69877765 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69877765
    register INTEGER    _i0;
    RTF                 _mf;

    _i0 = 0;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _i0 = ((INTEGER) 1) + (_a2 - _a1);
    E70541330 (&_mf, EA5(_a0)->Especial, _i0, EA5(_a0)->Elower - _a1);
    EA5(_a0)->Estore = E70631442 (&_mf, EA5(_a0)->Especial, _a1);
    EA5(_a0)->Elower = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69894149 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;

{
#ifndef EDCR69894149
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (_a2 < E73973765 (&_mf, _a0) - ((INTEGER) 1))
    {
       E69918725 (&_mf, _a0, ((INTEGER) 1) + _a2, E73973765 (&_mf, _a0) - ((INTEGER) 1), ((INTEGER) 1));
    }
    ((OBJREF *)(EA5(_a0)->Estore))[((INTEGER) 1) + _a2] = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E69918725 (_cf, _a0, _a1, _a2, _a3)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;
INTEGER       _a3;

{
#ifndef EDCR69918725
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69918738 (&_mf, EA5(_a0)->Especial, _a1 - EA5(_a0)->Elower, _a2 - EA5(_a0)->Elower, _a3);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70025221 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70025221
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E68960261 (&_mf, _a0) == ((INTEGER) 0);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E70057989 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70057989
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = ((OBJREF *)(EA18(EA5(_a0)->Especial)->Estore))[_a1 - EA5(_a0)->Elower];
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

POINTER       E70066181 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
    POINTER             _p0;
/* LEAF */

    _p0 = (POINTER) 0;

    _p0 = EA18(EA5(_a0)->Especial)->Estore;
    return _p0;
}
/*------------------------------------------------------------------*/

POINTER       array_to_external (_a0)

OBJREF        _a0;

{
    RTF    _df;

    return E70066181 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

INTEGER       E70492165 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70492165
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = EA18(EA5(_a0)->Especial)->Ecount;
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       E70656005 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70656005
    BOOLEAN             _b0;
    RTF                 _mf;

    _b0 = false;

    RTF_sl(0, (OBJREF *) 0, _cf);
    _b0 = E70656018 (&_mf, EA5(_a0)->Especial);
    RTF_return;
    return _b0;
#endif
}
/*------------------------------------------------------------------*/

void          E73949189 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR73949189
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA5(_a0)->Elower = _a1;
    EA5(_a0)->Estore = E70631442 (&_mf, EA5(_a0)->Especial, _a1);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

INTEGER       E73973765 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73973765
    register INTEGER    _i0;
/* LEAF */

    _i0 = 0;

    _i0 = (EA18(EA5(_a0)->Especial)->Ecount + EA5(_a0)->Elower) - ((INTEGER) 1);
    return _i0;
#endif
}
/*------------------------------------------------------------------*/

void          E73981957 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73981957
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E70500370 (&_mf, EA5(_a0)->Especial, ((INTEGER) 0), E68960261 (&_mf, _a0) - ((INTEGER) 1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E73990149 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR73990149
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69877765 (&_mf, _a0, EA5(_a0)->Elower, EA5(_a0)->Elower - ((INTEGER) 1));
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          E74006533 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;

{
#ifndef EDCR74006533
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    if (_a2 < EA5(_a0)->Elower)
    {
       E69877765 (&_mf, _a0, _a2, E73973765 (&_mf, _a0));
    }
    else
    {
       if (_a2 > E73973765 (&_mf, _a0))
       {
          E69877765 (&_mf, _a0, EA5(_a0)->Elower, _a2);
       }
    }
    ((OBJREF *)(EA5(_a0)->Estore))[_a2] = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

OBJREF        E74055685 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    EA5(_a0)->Estore = E70631442 (&_mf, EA5(_a0)->Especial, EA5(_a0)->Elower);
    _o [0] = EA5(_a0)->Especial;
    RTF_return;
    return _o [0];
}
/*------------------------------------------------------------------*/

OBJREF        array_ra_es3_spec (_a0)

OBJREF        _a0;

{
    RTF    _df;

    return E74055685 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void    ECR5 (obj)

ECA_array  *obj;

{

    obj->Especial = VOIDREF;
    obj->Estore = (POINTER) 0;
}
/*------------------------------------------------------------------*/

void    ST5 (d)

INTEGER d;

{
    ECA_array  p;
    ECDESC  *cd = &ECD_array, *ecd = &EECD_array;

    cd->f1          = (INTEGER) 5;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_array);
    cd->f12         = "array";
    cd->f6          = false;
    cd->f13         = ECR5;
    cd->f14         = RT_null;
    cd->f15         = E74055685;
    cd->f20         = (char *) " iop";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 3) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Elower)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Especial)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Estore)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 3) * sizeof (char *));
    (cd->f22) [0]   = (char *) "lower";
    (cd->f22) [1]   = (char *) "special";
    (cd->f22) [2]   = (char *) "store";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Especial)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_array;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

