/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H18.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_character;
extern  ECDESC        EECD_character;
extern  ECDESC        ECD_boolean;
extern  ECDESC        EECD_boolean;
extern  ECDESC        ECD_any;
extern  ECDESC        EECD_any;
extern  ECDESC        ECD_general;
extern  ECDESC        EECD_general;
extern  ECDESC        ECD_g;
extern  ECDESC        EECD_g;
ECDESC                ECD_es3_spec;
ECDESC                EECD_es3_spec;
/*------------------------------------------------------------------*/

extern  BOOLEAN       RTC0_is_equal ();
extern  void          RTC0_copy ();
extern  void          RTC0_fill_with ();
extern  void          RTC0_puts ();
extern  void          RTC0_resize ();
extern  void          RTC0_move ();
extern  void          RTC0_sv_lit ();
extern  POINTER       RTC0_gets ();
extern  void          RTC0_put ();
extern  void          RTC0_item ();
extern  void          RTC0_clear ();
extern  void          RTC0_resize_and_copy ();
extern  POINTER       RTC0_at ();
extern  BOOLEAN       RTC0_all_cleared ();
/*------------------------------------------------------------------*/

void                  E67125266 ();
void                  E69877778 ();
OBJREF                E69001234 ();
void                  E70279186 ();
void                  E69836818 ();
void                  E70270994 ();
/*------------------------------------------------------------------*/

void          E67125266 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR67125266
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    E69877778 (&_mf, _a0, _a1);
    EA18(_a0)->Ecount = _a1;
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_make (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E67125266 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

BOOLEAN       E68821010 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR68821010
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC0_is_equal (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       es3_spec_is_equal (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    return E68821010 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

OBJREF        E69001234 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69001234
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    E70279186 (&_mf, _a0, _a1);
    _o [0] = EA18(_a0)->Eexchg;
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

OBJREF        es3_spec_item (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    return E69001234 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69632018 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;

{
#ifndef EDCR69632018


    ++RTMM_stop;
    RTC0_copy (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_copy (_a0, _a1)

OBJREF        _a0;
OBJREF        _a1;

{
    RTF    _df;

    E69632018 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69672978 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
#ifndef EDCR69672978


    ++RTMM_stop;
    RTC0_fill_with (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_fill_with (_a0, _a1, _a2)

OBJREF        _a0;
CHARACTER     _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69672978 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69795858 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
POINTER       _a1;
INTEGER       _a2;

{
#ifndef EDCR69795858


    ++RTMM_stop;
    RTC0_puts (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_puts (_a0, _a1, _a2)

OBJREF        _a0;
POINTER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69795858 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69836818 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;

{
#ifndef EDCR69836818
    RTF                 _mf;


    RTF_sl(0, (OBJREF *) 0, _cf);
    EA18(_a0)->Eexchg = _a1;
    E70270994 (&_mf, _a0, _a2);
    RTF_return;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_put (_a0, _a1, _a2)

OBJREF        _a0;
OBJREF        _a1;
INTEGER       _a2;

{
    RTF    _df;

    E69836818 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E69877778 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR69877778


    ++RTMM_stop;
    RTC0_resize (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_resize (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E69877778 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E69918738 (_cf, _a0, _a1, _a2, _a3)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;
INTEGER       _a3;

{
#ifndef EDCR69918738


    ++RTMM_stop;
    RTC0_move (_a0, _a1, _a2, _a3);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_move (_a0, _a1, _a2, _a3)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;
INTEGER       _a3;

{
    RTF    _df;

    E69918738 (&_df,  _a0,  _a1,  _a2,  _a3);
}
/*------------------------------------------------------------------*/

void          E69984274 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR69984274


    ++RTMM_stop;
    RTC0_sv_lit (_a0);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_sv_lit (_a0)

OBJREF        _a0;

{
    RTF    _df;

    E69984274 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

POINTER       E70098962 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70098962
    POINTER  _res;


    ++RTMM_stop;
    _res = RTC0_gets (_a0, _a1, _a2);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       es3_spec_gets (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    return E70098962 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E70270994 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70270994


    ++RTMM_stop;
    RTC0_put (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_rt_put (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E70270994 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E70279186 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70279186


    ++RTMM_stop;
    RTC0_item (_a0, _a1);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_rt_item (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    E70279186 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

void          E70500370 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70500370


    ++RTMM_stop;
    RTC0_clear (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_clear (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E70500370 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

void          E70541330 (_cf, _a0, _a1, _a2)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
#ifndef EDCR70541330


    ++RTMM_stop;
    RTC0_resize_and_copy (_a0, _a1, _a2);
    --RTMM_stop;
#endif
}
/*------------------------------------------------------------------*/

void          es3_spec_resize_and_copy (_a0, _a1, _a2)

OBJREF        _a0;
INTEGER       _a1;
INTEGER       _a2;

{
    RTF    _df;

    E70541330 (&_df,  _a0,  _a1,  _a2);
}
/*------------------------------------------------------------------*/

POINTER       E70631442 (_cf, _a0, _a1)

RTF           *_cf;
OBJREF        _a0;
INTEGER       _a1;

{
#ifndef EDCR70631442
    POINTER  _res;


    ++RTMM_stop;
    _res = RTC0_at (_a0, _a1);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

POINTER       es3_spec_at (_a0, _a1)

OBJREF        _a0;
INTEGER       _a1;

{
    RTF    _df;

    return E70631442 (&_df,  _a0,  _a1);
}
/*------------------------------------------------------------------*/

BOOLEAN       E70656018 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR70656018
    BOOLEAN  _res;


    ++RTMM_stop;
    _res = RTC0_all_cleared (_a0);
    --RTMM_stop;
    return _res;
#endif
}
/*------------------------------------------------------------------*/

BOOLEAN       es3_spec_all_cleared (_a0)

OBJREF        _a0;

{
    RTF    _df;

    return E70656018 (&_df,  _a0);
}
/*------------------------------------------------------------------*/

void    ECR18 (obj)

ECA_es3_spec  *obj;

{

    obj->Eexchg = VOIDREF;
    obj->Estore = (POINTER) 0;
}
/*------------------------------------------------------------------*/

void    ST18 (d)

INTEGER d;

{
    ECA_es3_spec  p;
    ECDESC  *cd = &ECD_es3_spec, *ecd = &EECD_es3_spec;

    cd->f1          = (INTEGER) 18;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_es3_spec);
    cd->f12         = "es3_spec";
    cd->f6          = false;
    cd->f13         = ECR18;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " iobp";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 4) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.Ecount)) - ((CHARACTER *) &p));
    (cd->f21) [1]   = (INTEGER) (((CHARACTER *) &(p.Eexchg)) - ((CHARACTER *) &p));
    (cd->f21) [2]   = (INTEGER) (((CHARACTER *) &(p.Elit)) - ((CHARACTER *) &p));
    (cd->f21) [3]   = (INTEGER) (((CHARACTER *) &(p.Estore)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 4) * sizeof (char *));
    (cd->f22) [0]   = (char *) "count";
    (cd->f22) [1]   = (char *) "exchg";
    (cd->f22) [2]   = (char *) "lit";
    (cd->f22) [3]   = (char *) "store";
    cd->f5          = (INTEGER *) OS_alloc (((INTEGER) 2) * sizeof (INTEGER));
    (cd->f5) [0]    = (INTEGER) (((CHARACTER *) &(p.Eexchg)) - ((CHARACTER *) &p));
    (cd->f5) [1]    = (INTEGER) -1;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_any;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_es3_spec;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

