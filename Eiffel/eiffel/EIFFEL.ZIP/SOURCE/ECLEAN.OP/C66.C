/*------------------------------------------------------------------*/
/* Eiffel/S Release 1.2                                             */
/*------------------------------------------------------------------*/

#include             "eiffel.h"
#include             "els.h"
#include             "edcr.h"
#include             "H66.h"
/*------------------------------------------------------------------*/

extern  ECDESC        ECD_integer;
extern  ECDESC        EECD_integer;
extern  ECDESC        ECD_traversable;
extern  ECDESC        EECD_traversable;
extern  ECDESC        ECD_twoway_iter;
extern  ECDESC        EECD_twoway_iter;
ECDESC                ECD_twoway_traversable;
ECDESC                EECD_twoway_traversable;
/*------------------------------------------------------------------*/

extern  void          E67125291 ();
extern  void          E72826944 ();
/*------------------------------------------------------------------*/

OBJREF                E68943938 ();
/*------------------------------------------------------------------*/

OBJREF        E68943938 (_cf, _a0)

RTF           *_cf;
OBJREF        _a0;

{
#ifndef EDCR68943938
    OBJREF              _o [1];
    RTF                 _mf;

    _o [0] = VOIDREF;

    RTF_sl(1, _o, _cf);
    _o [0] = RTMM_create (&ECD_twoway_iter);
    E67125291 (&_mf, _o [0], _a0);
    E72826944 (&_mf, _a0, _o [0]);
    RTF_return;
    return _o [0];
#endif
}
/*------------------------------------------------------------------*/

void    ECR66 (obj)

ECA_twoway_traversable  *obj;

{

}
/*------------------------------------------------------------------*/

void    ST66 (d)

INTEGER d;

{
    ECA_twoway_traversable  p;
    ECDESC  *cd = &ECD_twoway_traversable, *ecd = &EECD_twoway_traversable;

    cd->f1          = (INTEGER) 66;
    cd->f2          = d;
    cd->f3          = sizeof (ECA_twoway_traversable);
    cd->f12         = "twoway_traversable";
    cd->f6          = false;
    cd->f13         = ECR66;
    cd->f14         = RT_null;
    cd->f15         = (OBJREF (*)()) 0;
    cd->f20         = (char *) " i";
    cd->f21         = (INTEGER *) OS_alloc (((INTEGER) 1) * sizeof (INTEGER));
    (cd->f21) [0]   = (INTEGER) (((CHARACTER *) &(p.En_iter)) - ((CHARACTER *) &p));
    cd->f22         = (char **) OS_alloc (((INTEGER) 1) * sizeof (char *));
    (cd->f22) [0]   = (char *) "n_iter";
    (cd->f5)        = (INTEGER *) 0;
    cd->f8          = (ECDESC **) OS_alloc (((INTEGER) 2) * sizeof (ECDESC *));
    (cd->f8) [0]    = &ECD_traversable;
    (cd->f8) [1]    = (ECDESC *) 0;
    cd->f9          = &EECD_twoway_traversable;
    cd->f10         = (char **) 0;
    cd->f11         = (BOOLEAN **) 0;
    OS_memcpy ((CHARACTER *) ecd, (CHARACTER *) cd, (INTEGER) sizeof (ECDESC));

    ecd->f6         = true;
    RTMM_notify (cd, ecd);
}
/*------------------------------------------------------------------*/

