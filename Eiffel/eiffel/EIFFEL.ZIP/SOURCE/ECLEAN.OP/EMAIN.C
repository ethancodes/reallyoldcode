#include           "eiffel.h"
/*------------------------------------------------------------------*/

extern   void      ST24 ();
extern   void      ST32 ();
extern   void      ST11 ();
extern   void      ST64 ();
extern   void      ST31 ();
extern   void      ST66 ();
extern   void      ST43 ();
extern   void      ST39 ();
extern   void      ST29 ();
extern   void      ST25 ();
extern   void      ST16 ();
extern   void      ST65 ();
extern   void      ST59 ();
extern   void      ST33 ();
extern   void      ST26 ();
extern   void      ST15 ();
extern   void      ST14 ();
extern   void      ST67 ();
extern   void      ST51 ();
extern   void      ST34 ();
extern   void      ST23 ();
extern   void      ST21 ();
extern   void      ST72 ();
extern   void      ST73 ();
extern   void      ST18 ();
extern   void      ST17 ();
extern   void      ST13 ();
extern   void      ST12 ();
extern   void      ST10 ();
extern   void      ST8 ();
extern   void      ST6 ();
extern   void      ST5 ();
extern   void      ST4 ();
extern   void      ST3 ();
extern   void      ST2 ();
extern   void      ST1 ();
extern   void      E67125258 ();
extern   ECDESC    ECD_eclean;
extern   INTEGER   RT_exit_code;
/*------------------------------------------------------------------*/

static   void      start ();
/*------------------------------------------------------------------*/

void eiffel_start (argc, argv, envp)

int     argc;
char    **argv;
char    **envp;

{

    RT_start (argc, argv);
}
/*------------------------------------------------------------------*/

int  eiffel_run ()

{
    int     *_env;
    OBJREF  _a0;
    RTF     _mf;

    _env = RTC4_push ();
    _a0  = VOIDREF;
    RTF_sl(1, &_a0, (&_mf));
    RTF_sn("main");
    RTF_sc;
 
    if (setjmp (_env))
        goto fail;

    start ();
    RTMM_run ();

    _a0 = RTMM_create (&ECD_eclean);
    RTMM_set_root (&_mf);
    E67125258 (&_mf, _a0);

#ifdef EPROFILE
    _eprof_end ();
#endif
    RT_end ((INTEGER) 0);
    return ((int) RT_exit_code);

fail :
#ifdef EPROFILE
    _eprof_end ();
#endif
    RT_end ((INTEGER) -1);
    return (-1);
}
/*------------------------------------------------------------------*/

static  void  start ()

{
    ST24 ((INTEGER) 6);
    ST32 ((INTEGER) 5);
    ST11 ((INTEGER) 4);
    ST64 ((INTEGER) 3);
    ST31 ((INTEGER) 3);
    ST66 ((INTEGER) 2);
    ST43 ((INTEGER) 2);
    ST39 ((INTEGER) 2);
    ST29 ((INTEGER) 2);
    ST25 ((INTEGER) 2);
    ST16 ((INTEGER) 2);
    ST65 ((INTEGER) 1);
    ST59 ((INTEGER) 1);
    ST33 ((INTEGER) 1);
    ST26 ((INTEGER) 1);
    ST15 ((INTEGER) 1);
    ST14 ((INTEGER) 1);
    ST67 ((INTEGER) 0);
    ST51 ((INTEGER) 0);
    ST34 ((INTEGER) 0);
    ST23 ((INTEGER) 0);
    ST21 ((INTEGER) 0);
    ST72 ((INTEGER) 0);
    ST73 ((INTEGER) 0);
    ST18 ((INTEGER) 0);
    ST17 ((INTEGER) 0);
    ST13 ((INTEGER) 0);
    ST12 ((INTEGER) 0);
    ST10 ((INTEGER) 0);
    ST8 ((INTEGER) 0);
    ST6 ((INTEGER) 0);
    ST5 ((INTEGER) 0);
    ST4 ((INTEGER) 0);
    ST3 ((INTEGER) 0);
    ST2 ((INTEGER) 0);
    ST1 ((INTEGER) 0);
}
/*------------------------------------------------------------------*/

